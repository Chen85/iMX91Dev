// ===============================================================================
// FILE NAME: utilDataMgrSourceTable.h
// DESCRIPTION:
//
//
// Modification History
// --------------------
// 2021/12/20, Larry Create
// --------------------
// ===============================================================================


#ifndef _UTIL_DATAMGRSOURCETABLE_
#define _UTIL_DATAMGRSOURCETABLE_

#include "utilDataMgrAPI.h"
#include "CustomDef.h"

typedef struct
{
    sPARA_FORMAT sCommon[eSCM_NUMBER];

    sPARA_FORMAT sHSG_Cinema[eHSG_NUMBER];
    sPARA_FORMAT sHSG_Bright[eHSG_NUMBER];
    sPARA_FORMAT sHSG_Enhanced[eHSG_NUMBER];
    sPARA_FORMAT sHSG_REC709[eHSG_NUMBER];
    sPARA_FORMAT sHSG_DICOMSIM[eHSG_NUMBER];
    sPARA_FORMAT sHSG_Blending[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER[eHSG_NUMBER];
    sPARA_FORMAT sHSG_HDR[eHSG_NUMBER];
    sPARA_FORMAT sHSG_3D[eHSG_NUMBER];
    sPARA_FORMAT sHSG_2D_High_Speed[eHSG_NUMBER];

    sPARA_FORMAT sColor_Cinema[eSCR_NUMBER];
    sPARA_FORMAT sColor_Bright[eSCR_NUMBER];
    sPARA_FORMAT sColor_Enhanced[eSCR_NUMBER];
    sPARA_FORMAT sColor_REC709[eSCR_NUMBER];
    sPARA_FORMAT sColor_DICOMSIM[eSCR_NUMBER];
    sPARA_FORMAT sColor_Blending[eSCR_NUMBER];
    sPARA_FORMAT sColor_USER[eSCR_NUMBER];
    sPARA_FORMAT sColor_HDR[eSCR_NUMBER];
    sPARA_FORMAT sColor_3D[eSCR_NUMBER];
    sPARA_FORMAT sColor_2D_High_Speed[eSCR_NUMBER];

    sPARA_FORMAT sHSG_USER_Cinema[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_Bright[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_Enhanced[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_REC709[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_DICOMSIM[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_Blending[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_USER[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_HDR[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_3D[eHSG_NUMBER];
    sPARA_FORMAT sHSG_USER_2D_High_Speed[eHSG_NUMBER];

    sPARA_FORMAT sColor_User_Cinema[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_Bright[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_Enhanced[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_REC709[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_DICOMSIM[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_Blending[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_USER[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_HDR[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_3D[eSCR_NUMBER];
    sPARA_FORMAT sColor_User_2D_High_Speed[eSCR_NUMBER];

}sSOURCE_DATA_TABLE;

typedef struct
{
    sPARA_FORMAT sPresetMode[eWAP_LD_SEG_NUMBERS];
}sWAP_DATA_TABLE;

typedef struct
{
    sSOURCE_DATA_TABLE *p_sSourceData;
    sWAP_DATA_TABLE *p_sWAP_RatioData;
    sWAP_DATA_TABLE *p_sWAP_OffsetData;
    sWAP_DATA_TABLE *p_sWAP_PWMData;
}sSOURCE_PARA_TABLE;

const static UINT16 m_cSourceTableMtached[eSOURCE_TYPE_NUMBER][eGUI_SOURCE_ID_NUMBER][eGUI_PICTURE_SETTINGS_NUMBER] =
{
    //eSOURCE_TYPE_COLOR
    {
					  //eIFC_VIDEO,		                 eIFC_BRIGHT,			          eIFC_ENHANCED,		             eIFC_REC709,		              eIFC_DICOMSIM,		             eIFC_BLENDING,		                 eIFC_HDR,		               eIFC_3D,		                eIFC_2DHIGHSPEED,                       eIFC_USER
	    /*HDMI1   */  {eDATA_NODE_HDMI1_COLOR_CINEMA,    eDATA_NODE_HDMI1_COLOR_BRIGHT,   eDATA_NODE_HDMI1_COLOR_ENHANCED,   eDATA_NODE_HDMI1_COLOR_REC709,   eDATA_NODE_HDMI1_COLOR_DICOMSIM,   eDATA_NODE_HDMI1_COLOR_BLENDING,    eDATA_NODE_HDMI1_COLOR_HDR,   eDATA_NODE_HDMI1_COLOR_3D,   eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED,   eDATA_NODE_HDMI1_COLOR_USER},
	    /*HDMI2   */  {eDATA_NODE_HDMI2_COLOR_CINEMA,    eDATA_NODE_HDMI2_COLOR_BRIGHT,   eDATA_NODE_HDMI2_COLOR_ENHANCED,   eDATA_NODE_HDMI2_COLOR_REC709,   eDATA_NODE_HDMI2_COLOR_DICOMSIM,   eDATA_NODE_HDMI2_COLOR_BLENDING,    eDATA_NODE_HDMI2_COLOR_HDR,   eDATA_NODE_HDMI2_COLOR_3D,   eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED,   eDATA_NODE_HDMI2_COLOR_USER},
	    /*DP      */  {eDATA_NODE_DP_COLOR_CINEMA,       eDATA_NODE_DP_COLOR_BRIGHT,      eDATA_NODE_DP_COLOR_ENHANCED,      eDATA_NODE_DP_COLOR_REC709,      eDATA_NODE_DP_COLOR_DICOMSIM,      eDATA_NODE_DP_COLOR_BLENDING,       eDATA_NODE_DP_COLOR_HDR,      eDATA_NODE_DP_COLOR_3D,      eDATA_NODE_DP_COLOR_2D_HIGH_SPEED,      eDATA_NODE_DP_COLOR_USER},
	    /*3GSDI   */  {eDATA_NODE_3GSDI_COLOR_CINEMA,    eDATA_NODE_3GSDI_COLOR_BRIGHT,   eDATA_NODE_3GSDI_COLOR_ENHANCED,   eDATA_NODE_3GSDI_COLOR_REC709,   eDATA_NODE_3GSDI_COLOR_DICOMSIM,   eDATA_NODE_3GSDI_COLOR_BLENDING,    eDATA_NODE_3GSDI_COLOR_HDR,   eDATA_NODE_3GSDI_COLOR_3D,   eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED,   eDATA_NODE_3GSDI_COLOR_USER},
	    /*HDBASET */  {eDATA_NODE_HDBASET_COLOR_CINEMA,  eDATA_NODE_HDBASET_COLOR_BRIGHT, eDATA_NODE_HDBASET_COLOR_ENHANCED, eDATA_NODE_HDBASET_COLOR_REC709, eDATA_NODE_HDBASET_COLOR_DICOMSIM, eDATA_NODE_HDBASET_COLOR_BLENDING,  eDATA_NODE_HDBASET_COLOR_HDR, eDATA_NODE_HDBASET_COLOR_3D, eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED, eDATA_NODE_HDBASET_COLOR_USER},
    },
    //eSOURCE_TYPE_HSG
    {
					  //eIFC_VIDEO,		                eIFC_BRIGHT,			          eIFC_ENHANCED,		            eIFC_REC709,		              eIFC_DICOMSIM,		             eIFC_BLENDING,		                 eIFC_HDR,		               eIFC_3D,		                eIFC_2DHIGHSPEED,	                   eIFC_USER
	    /*HDMI1   */  {eDATA_NODE_HDMI1_HSG_CINEMA,     eDATA_NODE_HDMI1_HSG_BRIGHT,      eDATA_NODE_HDMI1_HSG_ENHANCED,    eDATA_NODE_HDMI1_HSG_REC709,	  eDATA_NODE_HDMI1_HSG_DICOMSIM ,    eDATA_NODE_HDMI1_HSG_BLENDING,      eDATA_NODE_HDMI1_HSG_HDR,     eDATA_NODE_HDMI1_HSG_3D,     eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED,    eDATA_NODE_HDMI1_HSG_USER},
	    /*HDMI2   */  {eDATA_NODE_HDMI2_HSG_CINEMA,     eDATA_NODE_HDMI2_HSG_BRIGHT,      eDATA_NODE_HDMI2_HSG_ENHANCED,    eDATA_NODE_HDMI2_HSG_REC709,      eDATA_NODE_HDMI2_HSG_DICOMSIM ,    eDATA_NODE_HDMI2_HSG_BLENDING,      eDATA_NODE_HDMI2_HSG_HDR,     eDATA_NODE_HDMI2_HSG_3D,     eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED,    eDATA_NODE_HDMI2_HSG_USER},
	    /*DP      */  {eDATA_NODE_DP_HSG_CINEMA,        eDATA_NODE_DP_HSG_BRIGHT,         eDATA_NODE_DP_HSG_ENHANCED,       eDATA_NODE_DP_HSG_REC709,         eDATA_NODE_DP_HSG_DICOMSIM ,       eDATA_NODE_DP_HSG_BLENDING,         eDATA_NODE_DP_HSG_HDR,        eDATA_NODE_DP_HSG_3D,        eDATA_NODE_DP_HSG_2D_HIGH_SPEED,       eDATA_NODE_DP_HSG_USER},
	    /*3GSDI   */  {eDATA_NODE_3GSDI_HSG_CINEMA,     eDATA_NODE_3GSDI_HSG_BRIGHT,      eDATA_NODE_3GSDI_HSG_ENHANCED,    eDATA_NODE_3GSDI_HSG_REC709,      eDATA_NODE_3GSDI_HSG_DICOMSIM ,    eDATA_NODE_3GSDI_HSG_BLENDING,      eDATA_NODE_3GSDI_HSG_HDR,     eDATA_NODE_3GSDI_HSG_3D,     eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED,    eDATA_NODE_3GSDI_HSG_USER},
	    /*HDBASET */  {eDATA_NODE_HDBASET_HSG_CINEMA,   eDATA_NODE_HDBASET_HSG_BRIGHT,    eDATA_NODE_HDBASET_HSG_ENHANCED,  eDATA_NODE_HDBASET_HSG_REC709,    eDATA_NODE_HDBASET_HSG_DICOMSIM ,  eDATA_NODE_HDBASET_HSG_BLENDING,    eDATA_NODE_HDBASET_HSG_HDR,   eDATA_NODE_HDBASET_HSG_3D,   eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED,  eDATA_NODE_HDBASET_HSG_USER},
    }
};

const static UINT16 m_cSourceTableUserModeMtached[eSOURCE_TYPE_NUMBER][eGUI_SOURCE_ID_NUMBER][eGUI_PRE_USERS_NUMBER] =	//G100_Doulas_0066 Modify
{
    //eSOURCE_TYPE_COLOR
    {
                      //eIFC_VIDEO,		                     eIFC_BRIGHT,			                   eIFC_ENHANCED,		                   eIFC_REC709,		                     eIFC_DICOMSIM,		                     eIFC_BLENDING,		                     eIFC_HDR,		                    eIFC_3D,                          eIFC_2DHIGHSPEED,
	    /*HDMI1   */  {eDATA_NODE_HDMI1_COLOR_USER_CINEMA,	 eDATA_NODE_HDMI1_COLOR_USER_BRIGHT,       eDATA_NODE_HDMI1_COLOR_USER_ENHANCED,   eDATA_NODE_HDMI1_COLOR_USER_REC709,   eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM,   eDATA_NODE_HDMI1_COLOR_USER_BLENDING,   eDATA_NODE_HDMI1_COLOR_USER_HDR,   eDATA_NODE_HDMI1_COLOR_USER_3D,   eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED  },
	    /*HDMI2   */  {eDATA_NODE_HDMI2_COLOR_USER_CINEMA,   eDATA_NODE_HDMI2_COLOR_USER_BRIGHT,   	   eDATA_NODE_HDMI2_COLOR_USER_ENHANCED,   eDATA_NODE_HDMI2_COLOR_USER_REC709,   eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM,   eDATA_NODE_HDMI2_COLOR_USER_BLENDING,   eDATA_NODE_HDMI2_COLOR_USER_HDR,   eDATA_NODE_HDMI2_COLOR_USER_3D,   eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED  },
        /*DP      */  {eDATA_NODE_DP_COLOR_USER_CINEMA,      eDATA_NODE_DP_COLOR_USER_BRIGHT,          eDATA_NODE_DP_COLOR_USER_ENHANCED,      eDATA_NODE_DP_COLOR_USER_REC709,      eDATA_NODE_DP_COLOR_USER_DICOMSIM,      eDATA_NODE_DP_COLOR_USER_BLENDING,      eDATA_NODE_DP_COLOR_USER_HDR,      eDATA_NODE_DP_COLOR_USER_3D,      eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED     },
        /*3GSDI   */  {eDATA_NODE_3GSDI_COLOR_USER_CINEMA,   eDATA_NODE_3GSDI_COLOR_USER_BRIGHT,   	   eDATA_NODE_3GSDI_COLOR_USER_ENHANCED,   eDATA_NODE_3GSDI_COLOR_USER_REC709,   eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM,   eDATA_NODE_3GSDI_COLOR_USER_BLENDING,   eDATA_NODE_3GSDI_COLOR_USER_HDR,   eDATA_NODE_3GSDI_COLOR_USER_3D,   eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED  },
	    /*HDBASET */  {eDATA_NODE_HDBASET_COLOR_USER_CINEMA, eDATA_NODE_HDBASET_COLOR_USER_BRIGHT, 	   eDATA_NODE_HDBASET_COLOR_USER_ENHANCED, eDATA_NODE_HDBASET_COLOR_USER_REC709, eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM, eDATA_NODE_HDBASET_COLOR_USER_BLENDING, eDATA_NODE_HDBASET_COLOR_USER_HDR, eDATA_NODE_HDBASET_COLOR_USER_3D, eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED},
    },
    //eSOURCE_TYPE_HSG
	{
				      //eIFC_VIDEO,		                     eIFC_BRIGHT,			                    eIFC_ENHANCED,		                    eIFC_REC709,		                  eIFC_DICOMSIM,		                 eIFC_BLENDING,		                      eIFC_HDR,		                     eIFC_3D,                         eIFC_2DHIGHSPEED,
	    /*HDMI1   */  {eDATA_NODE_HDMI1_HSG_USER_CINEMA,     eDATA_NODE_HDMI1_HSG_USER_BRIGHT,		    eDATA_NODE_HDMI1_HSG_USER_ENHANCED,    	eDATA_NODE_HDMI1_HSG_USER_REC709,     eDATA_NODE_HDMI1_HSG_USER_DICOMSIM,    eDATA_NODE_HDMI1_HSG_USER_BLENDING,	  eDATA_NODE_HDMI1_HSG_USER_HDR,     eDATA_NODE_HDMI1_HSG_USER_3D,    eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED  },
	    /*HDMI2   */  {eDATA_NODE_HDMI2_HSG_USER_CINEMA,     eDATA_NODE_HDMI2_HSG_USER_BRIGHT,      	eDATA_NODE_HDMI2_HSG_USER_ENHANCED,    	eDATA_NODE_HDMI2_HSG_USER_REC709,     eDATA_NODE_HDMI2_HSG_USER_DICOMSIM,    eDATA_NODE_HDMI2_HSG_USER_BLENDING,      eDATA_NODE_HDMI2_HSG_USER_HDR,     eDATA_NODE_HDMI2_HSG_USER_3D,    eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED  },
	    /*DP      */  {eDATA_NODE_DP_HSG_USER_CINEMA,        eDATA_NODE_DP_HSG_USER_BRIGHT,       	    eDATA_NODE_DP_HSG_USER_ENHANCED,     	eDATA_NODE_DP_HSG_USER_REC709,        eDATA_NODE_DP_HSG_USER_DICOMSIM,       eDATA_NODE_DP_HSG_USER_BLENDING,         eDATA_NODE_DP_HSG_USER_HDR,        eDATA_NODE_DP_HSG_USER_3D,       eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED     },
	    /*3GSDI   */  {eDATA_NODE_3GSDI_HSG_USER_CINEMA,     eDATA_NODE_3GSDI_HSG_USER_BRIGHT,      	eDATA_NODE_3GSDI_HSG_USER_ENHANCED,    	eDATA_NODE_3GSDI_HSG_USER_REC709,     eDATA_NODE_3GSDI_HSG_USER_DICOMSIM,    eDATA_NODE_3GSDI_HSG_USER_BLENDING,      eDATA_NODE_3GSDI_HSG_USER_HDR,     eDATA_NODE_3GSDI_HSG_USER_3D,    eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED  },
	    /*HDBASET */  {eDATA_NODE_HDBASET_HSG_USER_CINEMA,   eDATA_NODE_HDBASET_HSG_USER_BRIGHT,    	eDATA_NODE_HDBASET_HSG_USER_ENHANCED,  	eDATA_NODE_HDBASET_HSG_USER_REC709,   eDATA_NODE_HDBASET_HSG_USER_DICOMSIM,  eDATA_NODE_HDBASET_HSG_USER_BLENDING,    eDATA_NODE_HDBASET_HSG_USER_HDR,   eDATA_NODE_HDBASET_HSG_USER_3D,  eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED},
    }
};

const static UINT16 m_cSourceTableCommon[] =
{
    /*HDMI 1*/ 	eDATA_NODE_HDMI1_COMMON,
    /*HDMI 2*/ 	eDATA_NODE_HDMI2_COMMON,
    ///*DVI   */ 	eDATA_NODE_DVID_COMMON,
    /*DVI   */ 	eDATA_NODE_DP_COMMON,
    /*3G-SDI*/ 	eDATA_NODE_3GSDI_COMMON,
    /*HDBT  */ 	eDATA_NODE_HDBASET_COMMON,
};

VERIFY_SIZE_OF(m_cSourceTableCommon, sizeof(m_cSourceTableCommon[0])*eGUI_SOURCE_ID_NUMBER);

const static UINT16 m_cWAP_Table[eIFC_WAP_NUMBER][eWAP_PARA_NUMBERS] =
{
    //RATIO, OFFSET, PWM
    ///* eIFC_WAP_PRESENTATION*/ {eDATA_NODE_WAP_PRESENTATION_RATIO,  eDATA_NODE_WAP_PRESENTATION_OFFSET,  eDATA_NODE_WAP_PRESENTATION_PWM },
    /* eIFC_WAP_CINEMA      */ {eDATA_NODE_WAP_CINEMA_RATIO,        eDATA_NODE_WAP_CINEMA_OFFSET,        eDATA_NODE_WAP_CINEMA_PWM       },
    /* eIFC_WAP_BRIGHT      */ {eDATA_NODE_WAP_BRIGHT_RATIO,        eDATA_NODE_WAP_BRIGHT_OFFSET,        eDATA_NODE_WAP_BRIGHT_PWM       },
    /* eIFC_WAP_ENHANCED    */ {eDATA_NODE_WAP_ENHANCED_RATIO,      eDATA_NODE_WAP_ENHANCED_OFFSET,      eDATA_NODE_WAP_ENHANCED_PWM     },
    /* eIFC_WAP_REC709      */ {eDATA_NODE_WAP_REC709_RATIO,        eDATA_NODE_WAP_REC709_OFFSET,        eDATA_NODE_WAP_REC709_PWM       },
    ///* eIFC_WAP_sRGB        */ {eDATA_NODE_WAP_SRGB_RATIO,          eDATA_NODE_WAP_SRGB_OFFSET,          eDATA_NODE_WAP_SRGB_PWM         },
    /* eIFC_WAP_DICOMSIM    */ {eDATA_NODE_WAP_DICOM_RATIO,         eDATA_NODE_WAP_DICOM_OFFSET,         eDATA_NODE_WAP_DICOM_PWM        },
    /* eIFC_WAP_BLENDING    */ {eDATA_NODE_WAP_BLENDING_RATIO,      eDATA_NODE_WAP_BLENDING_OFFSET,      eDATA_NODE_WAP_BLENDING_PWM     },
    /* eIFC_WAP_HDR         */ {eDATA_NODE_WAP_HDR_RATIO,           eDATA_NODE_WAP_HDR_OFFSET,           eDATA_NODE_WAP_HDR_PWM          },
    /* eIFC_WAP_3D          */ {eDATA_NODE_WAP_3D_RATIO,            eDATA_NODE_WAP_3D_OFFSET,            eDATA_NODE_WAP_3D_PWM           },
    /* eIFC_WAP_2DHIGHSPEED */ {eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO, eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET, eDATA_NODE_WAP_2D_HIGH_SPEED_PWM},
    /* eIFC_WAP_USER        */ {eDATA_NODE_WAP_USER_RATIO,          eDATA_NODE_WAP_USER_OFFSET,          eDATA_NODE_WAP_USER_PWM         },  //A70LK_Simon_0001
    ///* eIFC_WAP_SUPER_RED   */ {eDATA_NODE_WAP_SUPER_RED_RATIO,     eDATA_NODE_WAP_SUPER_RED_OFFSET,     eDATA_NODE_WAP_SUPER_RED_PWM    },
    ///* eIFC_WAP_SUPERBRIGHT */ {eDATA_NODE_WAP_SUPER_BRIGHT_RATIO,  eDATA_NODE_WAP_SUPER_BRIGHT_OFFSET,  eDATA_NODE_WAP_SUPER_BRIGHT_PWM },
};

#define MNT_CONFIG_SCALER_SOURCE(x)	CONF_SCALER_SOURCE_PATH#x
#define MNT_CONFIG_SCALER_WAP(x) 	CONF_SCALER_WAP_PATH#x

static sDATA_NODE_CTRL m_sSourceDataNodeCtrl[] =
{
    {eDATA_NODE_HDMI1_COMMON,                     MNT_CONFIG_SCALER_SOURCE(/HDMI1_Common.conf),                      0, 0},    //8
    {eDATA_NODE_HDMI1_HSG_CINEMA,                 MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_BRIGHT,                 MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_ENHANCED,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_REC709,                 MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_DICOMSIM,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_BLENDING,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_USER,                   MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_HDMI1_HSG_HDR,                    MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_HDMI1_HSG_3D,                     MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_CINEMA,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_BRIGHT,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_Bright.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_ENHANCED,             MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_REC709,               MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_REC709.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_DICOMSIM,             MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_BLENDING,             MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_Blending.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER,                 MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_USER.conf),                  0, 0},
    {eDATA_NODE_HDMI1_COLOR_HDR,                  MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_HDMI1_COLOR_3D,                   MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_3D.conf),                    0, 0},
    {eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_2D_High_Speed.conf),         0, 0},

    {eDATA_NODE_HDMI2_COMMON,                     MNT_CONFIG_SCALER_SOURCE(/HDMI2_Common.conf),                      0, 0}, //29
    {eDATA_NODE_HDMI2_HSG_CINEMA,                 MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_BRIGHT,                 MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_ENHANCED,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_REC709,                 MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_DICOMSIM,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_BLENDING,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_USER,                   MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_HDMI2_HSG_HDR,                    MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_HDMI2_HSG_3D,                     MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_CINEMA,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_BRIGHT,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_Bright.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_ENHANCED,             MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_REC709,               MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_REC709.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_DICOMSIM,             MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_BLENDING,             MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_Blending.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER,                 MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_USER.conf),                  0, 0},
    {eDATA_NODE_HDMI2_COLOR_HDR,                  MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_HDMI2_COLOR_3D,                   MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_3D.conf),                    0, 0},
    {eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_2D_High_Speed.conf),         0, 0},

#if 0
    {eDATA_NODE_DVID_COMMON,                      MNT_CONFIG_SCALER_SOURCE(/DVID_Common.conf),                       0, 0}, //50
    {eDATA_NODE_DVID_HSG_CINEMA,                  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_Cinema.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_BRIGHT,                  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_Bright.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_ENHANCED,                MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_Enhanced.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_REC709,                  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_REC709.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_DICOMSIM,                MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_DICOMSIM.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_BLENDING,                MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_Blending.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_USER,                    MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER.conf),                     0, 0},
    {eDATA_NODE_DVID_HSG_HDR,                     MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_HDR.conf),                      0, 0},
    {eDATA_NODE_DVID_HSG_3D,                      MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_3D.conf),                       0, 0},
    {eDATA_NODE_DVID_HSG_2D_HIGH_SPEED,           MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_2D_High_Speed.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_CINEMA,                MNT_CONFIG_SCALER_SOURCE(/DVID_Color_Cinema.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_BRIGHT,                MNT_CONFIG_SCALER_SOURCE(/DVID_Color_Bright.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_ENHANCED,              MNT_CONFIG_SCALER_SOURCE(/DVID_Color_Enhanced.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_REC709,                MNT_CONFIG_SCALER_SOURCE(/DVID_Color_REC709.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_DICOMSIM,              MNT_CONFIG_SCALER_SOURCE(/DVID_Color_DICOMSIM.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_BLENDING,              MNT_CONFIG_SCALER_SOURCE(/DVID_Color_Blending.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_USER,                  MNT_CONFIG_SCALER_SOURCE(/DVID_Color_USER.conf),                   0, 0},
    {eDATA_NODE_DVID_COLOR_HDR,                   MNT_CONFIG_SCALER_SOURCE(/DVID_Color_HDR.conf),                    0, 0},
    {eDATA_NODE_DVID_COLOR_3D,                    MNT_CONFIG_SCALER_SOURCE(/DVID_Color_3D.conf),                     0, 0},
    {eDATA_NODE_DVID_COLOR_2D_HIGH_SPEED,         MNT_CONFIG_SCALER_SOURCE(/DVID_Color_2D_High_Speed.conf),          0, 0},
#endif /* 0 */

    {eDATA_NODE_DP_COMMON,                        MNT_CONFIG_SCALER_SOURCE(/DP_Common.conf),                         0, 0}, //50
    {eDATA_NODE_DP_HSG_CINEMA,                    MNT_CONFIG_SCALER_SOURCE(/DP_HSG_Cinema.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_BRIGHT,                    MNT_CONFIG_SCALER_SOURCE(/DP_HSG_Bright.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_ENHANCED,                  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_Enhanced.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_REC709,                    MNT_CONFIG_SCALER_SOURCE(/DP_HSG_REC709.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_DICOMSIM,                  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_DICOMSIM.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_BLENDING,                  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_Blending.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_USER,                      MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER.conf),                       0, 0},
    {eDATA_NODE_DP_HSG_HDR,                       MNT_CONFIG_SCALER_SOURCE(/DP_HSG_HDR.conf),                        0, 0},
    {eDATA_NODE_DP_HSG_3D,                        MNT_CONFIG_SCALER_SOURCE(/DP_HSG_3D.conf),                         0, 0},
    {eDATA_NODE_DP_HSG_2D_HIGH_SPEED,             MNT_CONFIG_SCALER_SOURCE(/DP_HSG_2D_High_Speed.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_CINEMA,                  MNT_CONFIG_SCALER_SOURCE(/DP_Color_Cinema.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_BRIGHT,                  MNT_CONFIG_SCALER_SOURCE(/DP_Color_Bright.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_ENHANCED,                MNT_CONFIG_SCALER_SOURCE(/DP_Color_Enhanced.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_REC709,                  MNT_CONFIG_SCALER_SOURCE(/DP_Color_REC709.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_DICOMSIM,                MNT_CONFIG_SCALER_SOURCE(/DP_Color_DICOMSIM.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_BLENDING,                MNT_CONFIG_SCALER_SOURCE(/DP_Color_Blending.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_USER,                    MNT_CONFIG_SCALER_SOURCE(/DP_Color_USER.conf),                     0, 0},
    {eDATA_NODE_DP_COLOR_HDR,                     MNT_CONFIG_SCALER_SOURCE(/DP_Color_HDR.conf),                      0, 0},
    {eDATA_NODE_DP_COLOR_3D,                      MNT_CONFIG_SCALER_SOURCE(/DP_Color_3D.conf),                       0, 0},
    {eDATA_NODE_DP_COLOR_2D_HIGH_SPEED,           MNT_CONFIG_SCALER_SOURCE(/DP_Color_2D_High_Speed.conf),            0, 0},

    {eDATA_NODE_3GSDI_COMMON,                     MNT_CONFIG_SCALER_SOURCE(/3GSDI_Common.conf),                      0, 0}, //71
    {eDATA_NODE_3GSDI_HSG_CINEMA,                 MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_BRIGHT,                 MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_ENHANCED,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_REC709,                 MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_DICOMSIM,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_BLENDING,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_USER,                   MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_3GSDI_HSG_HDR,                    MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_3GSDI_HSG_3D,                     MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_CINEMA,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_BRIGHT,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_Bright.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_ENHANCED,             MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_REC709,               MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_REC709.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_DICOMSIM,             MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_BLENDING,             MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_Blending.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER,                 MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_USER.conf),                  0, 0},
    {eDATA_NODE_3GSDI_COLOR_HDR,                  MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_3GSDI_COLOR_3D,                   MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_3D.conf),                    0, 0},
    {eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_2D_High_Speed.conf),         0, 0},

    {eDATA_NODE_HDBASET_COMMON,                   MNT_CONFIG_SCALER_SOURCE(/HDBASET_Common.conf),                    0, 0}, //92
    {eDATA_NODE_HDBASET_HSG_CINEMA,               MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_Cinema.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_BRIGHT,               MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_Bright.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_ENHANCED,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_REC709,               MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_REC709.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_DICOMSIM,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_BLENDING,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_Blending.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_USER,                 MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER.conf),                  0, 0},
    {eDATA_NODE_HDBASET_HSG_HDR,                  MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_HDR.conf),                   0, 0},
    {eDATA_NODE_HDBASET_HSG_3D,                   MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_3D.conf),                    0, 0},
    {eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_2D_High_Speed.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_CINEMA,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_Cinema.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_BRIGHT,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_Bright.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_ENHANCED,           MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_Enhanced.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_REC709,             MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_REC709.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_DICOMSIM,           MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_BLENDING,           MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_Blending.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER,               MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_USER.conf),                0, 0},
    {eDATA_NODE_HDBASET_COLOR_HDR,                MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_HDR.conf),                 0, 0},
    {eDATA_NODE_HDBASET_COLOR_3D,                 MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_3D.conf),                  0, 0},
    {eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED,      MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_2D_High_Speed.conf),       0, 0},

    {eDATA_NODE_WAP_CALIBRATION_TAG,              MNT_CONFIG_SCALER_WAP(/WAP_Calibration_Tag.conf),                  0, 0}, // 113
    {eDATA_NODE_WAP_CINEMA_RATIO,                 MNT_CONFIG_SCALER_WAP(/WAP_Ratio_Cinema.conf),                     0, 0},
    {eDATA_NODE_WAP_BRIGHT_RATIO,                 MNT_CONFIG_SCALER_WAP(/WAP_Ratio_Bright.conf),                     0, 0},
    {eDATA_NODE_WAP_ENHANCED_RATIO,               MNT_CONFIG_SCALER_WAP(/WAP_Ratio_Enhanced.conf),                   0, 0},
    {eDATA_NODE_WAP_REC709_RATIO,                 MNT_CONFIG_SCALER_WAP(/WAP_Ratio_REC709.conf),                     0, 0},
    {eDATA_NODE_WAP_DICOM_RATIO,                  MNT_CONFIG_SCALER_WAP(/WAP_Ratio_DICOM.conf),                      0, 0},
    {eDATA_NODE_WAP_BLENDING_RATIO,               MNT_CONFIG_SCALER_WAP(/WAP_Ratio_Blending.conf),                   0, 0},
    {eDATA_NODE_WAP_USER_RATIO,                   MNT_CONFIG_SCALER_WAP(/WAP_Ratio_USER.conf),                       0, 0},
    {eDATA_NODE_WAP_HDR_RATIO,                    MNT_CONFIG_SCALER_WAP(/WAP_Ratio_HDR.conf),                        0, 0},
    {eDATA_NODE_WAP_3D_RATIO,                     MNT_CONFIG_SCALER_WAP(/WAP_Ratio_3D.conf),                         0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO,          MNT_CONFIG_SCALER_WAP(/WAP_Ratio_2DHSP.conf),                      0, 0},

    {eDATA_NODE_WAP_CINEMA_OFFSET,                MNT_CONFIG_SCALER_WAP(/WAP_Offset_Cinema.conf),                    0, 0}, //124
    {eDATA_NODE_WAP_BRIGHT_OFFSET,                MNT_CONFIG_SCALER_WAP(/WAP_Offset_Bright.conf),                    0, 0},
    {eDATA_NODE_WAP_ENHANCED_OFFSET,              MNT_CONFIG_SCALER_WAP(/WAP_Offset_Enhanced.conf),                  0, 0},
    {eDATA_NODE_WAP_REC709_OFFSET,                MNT_CONFIG_SCALER_WAP(/WAP_Offset_REC709.conf),                    0, 0},
    {eDATA_NODE_WAP_DICOM_OFFSET,                 MNT_CONFIG_SCALER_WAP(/WAP_Offset_DICOM.conf),                     0, 0},
    {eDATA_NODE_WAP_BLENDING_OFFSET,              MNT_CONFIG_SCALER_WAP(/WAP_Offset_Blending.conf),                  0, 0},
    {eDATA_NODE_WAP_USER_OFFSET,                  MNT_CONFIG_SCALER_WAP(/WAP_Offset_USER.conf),                      0, 0},
    {eDATA_NODE_WAP_HDR_OFFSET,                   MNT_CONFIG_SCALER_WAP(/WAP_Offset_HDR.conf),                       0, 0},
    {eDATA_NODE_WAP_3D_OFFSET,                    MNT_CONFIG_SCALER_WAP(/WAP_Offset_3D.conf),                        0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET,         MNT_CONFIG_SCALER_WAP(/WAP_Offset_2DHSP.conf),                     0, 0},

    {eDATA_NODE_WAP_CINEMA_PWM,                   MNT_CONFIG_SCALER_WAP(/WAP_PWM_Cinema.conf),                       0, 0}, //134
    {eDATA_NODE_WAP_BRIGHT_PWM,                   MNT_CONFIG_SCALER_WAP(/WAP_PWM_Bright.conf),                       0, 0},
    {eDATA_NODE_WAP_ENHANCED_PWM,                 MNT_CONFIG_SCALER_WAP(/WAP_PWM_Enhanced.conf),                     0, 0},
    {eDATA_NODE_WAP_REC709_PWM,                   MNT_CONFIG_SCALER_WAP(/WAP_PWM_REC709.conf),                       0, 0},
    {eDATA_NODE_WAP_DICOM_PWM,                    MNT_CONFIG_SCALER_WAP(/WAP_PWM_DICOM.conf),                        0, 0},
    {eDATA_NODE_WAP_BLENDING_PWM,                 MNT_CONFIG_SCALER_WAP(/WAP_PWM_Blending.conf),                     0, 0},
    {eDATA_NODE_WAP_USER_PWM,                     MNT_CONFIG_SCALER_WAP(/WAP_PWM_USER.conf),                         0, 0},
    {eDATA_NODE_WAP_HDR_PWM,                      MNT_CONFIG_SCALER_WAP(/WAP_PWM_HDR.conf),                          0, 0},
    {eDATA_NODE_WAP_3D_PWM,                       MNT_CONFIG_SCALER_WAP(/WAP_PWM_3D.conf),                           0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_PWM,            MNT_CONFIG_SCALER_WAP(/WAP_PWM_2DHSP.conf),                        0, 0},

    {eDATA_NODE_HDMI1_COLOR_USER_CINEMA,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_Cinema.conf),           0, 0}, // 144
    {eDATA_NODE_HDMI1_COLOR_USER_BRIGHT,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_ENHANCED,        MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_REC709,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM,        MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_BLENDING,        MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_HDR,             MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_3D,              MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_SCALER_SOURCE(/HDMI1_Color_User_2D_High_Speed.conf),    0, 0},

    {eDATA_NODE_HDMI2_COLOR_USER_CINEMA,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_Cinema.conf),           0, 0}, //154
    {eDATA_NODE_HDMI2_COLOR_USER_BRIGHT,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_ENHANCED,        MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_REC709,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM,        MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_BLENDING,        MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_HDR,             MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_3D,              MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_SCALER_SOURCE(/HDMI2_Color_User_2D_High_Speed.conf),    0, 0},

#if 0
    {eDATA_NODE_DVID_COLOR_USER_CINEMA,           MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_Cinema.conf),            0, 0}, //164
    {eDATA_NODE_DVID_COLOR_USER_BRIGHT,           MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_Bright.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_USER_ENHANCED,         MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_Enhanced.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_REC709,           MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_REC709.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_USER_DICOMSIM,         MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_DICOMSIM.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_BLENDING,         MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_Blending.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_HDR,              MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_HDR.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_USER_3D,               MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_3D.conf),                0, 0},
    {eDATA_NODE_DVID_COLOR_USER_2D_HIGH_SPEED,    MNT_CONFIG_SCALER_SOURCE(/DVID_Color_User_2D_High_Speed.conf),     0, 0},
#endif /* 0 */

    {eDATA_NODE_DP_COLOR_USER_CINEMA,             MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_Cinema.conf),              0, 0}, //164
    {eDATA_NODE_DP_COLOR_USER_BRIGHT,             MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_Bright.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_USER_ENHANCED,           MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_Enhanced.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_REC709,             MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_REC709.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_USER_DICOMSIM,           MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_BLENDING,           MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_Blending.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_HDR,                MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_HDR.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_USER_3D,                 MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_3D.conf),                  0, 0},
    {eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED,      MNT_CONFIG_SCALER_SOURCE(/DP_Color_User_2D_High_Speed.conf),       0, 0},

    {eDATA_NODE_3GSDI_COLOR_USER_CINEMA,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_Cinema.conf),           0, 0}, //174
    {eDATA_NODE_3GSDI_COLOR_USER_BRIGHT,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_ENHANCED,        MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_REC709,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM,        MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_BLENDING,        MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_HDR,             MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_3D,              MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_SCALER_SOURCE(/3GSDI_Color_User_2D_High_Speed.conf),    0, 0},

    {eDATA_NODE_HDBASET_COLOR_USER_CINEMA,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_Cinema.conf),         0, 0}, //184
    {eDATA_NODE_HDBASET_COLOR_USER_BRIGHT,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_Bright.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_ENHANCED,      MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_Enhanced.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_REC709,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_REC709.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM,      MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_DICOMSIM.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_BLENDING,      MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_Blending.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_HDR,           MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_HDR.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_3D,            MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_3D.conf),             0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED, MNT_CONFIG_SCALER_SOURCE(/HDBASET_Color_User_2D_High_Speed.conf),  0, 0},

    {eDATA_NODE_HDMI1_HSG_USER_CINEMA,            MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_Cinema.conf),             0, 0}, //194
    {eDATA_NODE_HDMI1_HSG_USER_BRIGHT,         	  MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_ENHANCED,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_REC709,		      MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_REC709.conf),			 0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_DICOMSIM,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_BLENDING,          MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_HDR,			  	  MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_HDR.conf), 		 	     0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_3D,                MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_SCALER_SOURCE(/HDMI1_HSG_USER_2D_High_Speed.conf),      0, 0},

    {eDATA_NODE_HDMI2_HSG_USER_CINEMA,		      MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_Cinema.conf),	         0, 0}, //204
    {eDATA_NODE_HDMI2_HSG_USER_BRIGHT,            MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_ENHANCED,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_REC709,		      MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_REC709.conf),			 0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_DICOMSIM,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_BLENDING,          MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_HDR,				  MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_HDR.conf), 		 	     0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_3D,                MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_SCALER_SOURCE(/HDMI2_HSG_USER_2D_High_Speed.conf),      0, 0},

#if 0
	{eDATA_NODE_DVID_HSG_USER_CINEMA,			  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_Cinema.conf),			     0, 0}, //214
    {eDATA_NODE_DVID_HSG_USER_BRIGHT,             MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_Bright.conf),              0, 0},
    {eDATA_NODE_DVID_HSG_USER_ENHANCED,       	  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_Enhanced.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_REC709,		      MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_REC709.conf),			     0, 0},
    {eDATA_NODE_DVID_HSG_USER_DICOMSIM,           MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_BLENDING,           MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_Blending.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_HDR,			      MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_HDR.conf), 		 	     0, 0},
    {eDATA_NODE_DVID_HSG_USER_3D,             	  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_3D.conf),                  0, 0},
    {eDATA_NODE_DVID_HSG_USER_2D_HIGH_SPEED,  	  MNT_CONFIG_SCALER_SOURCE(/DVID_HSG_USER_2D_High_Speed.conf),       0, 0},
#endif /* 0 */

	{eDATA_NODE_DP_HSG_USER_CINEMA,			      MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_Cinema.conf),			     0, 0}, //214
    {eDATA_NODE_DP_HSG_USER_BRIGHT,               MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_Bright.conf),                0, 0},
    {eDATA_NODE_DP_HSG_USER_ENHANCED,       	  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_Enhanced.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_REC709,		          MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_REC709.conf),			     0, 0},
    {eDATA_NODE_DP_HSG_USER_DICOMSIM,             MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_BLENDING,             MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_Blending.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_HDR,			      MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_HDR.conf), 		 	         0, 0},
    {eDATA_NODE_DP_HSG_USER_3D,             	  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_3D.conf),                    0, 0},
    {eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED,  	  MNT_CONFIG_SCALER_SOURCE(/DP_HSG_USER_2D_High_Speed.conf),         0, 0},

	{eDATA_NODE_3GSDI_HSG_USER_CINEMA,			  MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_Cinema.conf),			 0, 0}, //224
    {eDATA_NODE_3GSDI_HSG_USER_BRIGHT,            MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_ENHANCED,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_REC709,		      MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_REC709.conf),			 0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_DICOMSIM,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_BLENDING,          MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_HDR,			      MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_HDR.conf), 		 	     0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_3D,                MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_SCALER_SOURCE(/3GSDI_HSG_USER_2D_High_Speed.conf),      0, 0},

	{eDATA_NODE_HDBASET_HSG_USER_CINEMA,		  MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_Cinema.conf), 		     0, 0}, //234
    {eDATA_NODE_HDBASET_HSG_USER_BRIGHT,          MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_Bright.conf),           0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_ENHANCED,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_REC709,		  MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_REC709.conf),			 0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_DICOMSIM,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_BLENDING,        MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_Blending.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_HDR,			  MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_HDR.conf), 		 	 0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_3D,              MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_3D.conf),               0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED,   MNT_CONFIG_SCALER_SOURCE(/HDBASET_HSG_USER_2D_High_Speed.conf),    0, 0},
};

#define SOURCE_DATA_NODE_NUMBER sizeof(m_sSourceDataNodeCtrl)/sizeof(m_sSourceDataNodeCtrl[0])


#ifdef CONF_BACKUP
#define MNT_CONFIG_BAK_SOURCE(x)	CONF_BAK_SOURCE_PATH#x
#define MNT_CONFIG_BAK_WAP(x) 	    CONF_BAK_WAP_PATH#x

static sDATA_NODE_CTRL m_sSourceDataNodeBakCtrl[] =
{
    {eDATA_NODE_HDMI1_COMMON,                     MNT_CONFIG_BAK_SOURCE(/HDMI1_Common.conf),                      0, 0},    //8
    {eDATA_NODE_HDMI1_HSG_CINEMA,                 MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_BRIGHT,                 MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_ENHANCED,               MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_REC709,                 MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_HDMI1_HSG_DICOMSIM,               MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_BLENDING,               MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_HDMI1_HSG_USER,                   MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_HDMI1_HSG_HDR,                    MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_HDMI1_HSG_3D,                     MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED,          MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_CINEMA,               MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_BRIGHT,               MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_Bright.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_ENHANCED,             MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_REC709,               MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_REC709.conf),                0, 0},
    {eDATA_NODE_HDMI1_COLOR_DICOMSIM,             MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_BLENDING,             MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_Blending.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER,                 MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_USER.conf),                  0, 0},
    {eDATA_NODE_HDMI1_COLOR_HDR,                  MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_HDMI1_COLOR_3D,                   MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_3D.conf),                    0, 0},
    {eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_2D_High_Speed.conf),         0, 0},

    {eDATA_NODE_HDMI2_COMMON,                     MNT_CONFIG_BAK_SOURCE(/HDMI2_Common.conf),                      0, 0}, //29
    {eDATA_NODE_HDMI2_HSG_CINEMA,                 MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_BRIGHT,                 MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_ENHANCED,               MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_REC709,                 MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_HDMI2_HSG_DICOMSIM,               MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_BLENDING,               MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_HDMI2_HSG_USER,                   MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_HDMI2_HSG_HDR,                    MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_HDMI2_HSG_3D,                     MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED,          MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_CINEMA,               MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_BRIGHT,               MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_Bright.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_ENHANCED,             MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_REC709,               MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_REC709.conf),                0, 0},
    {eDATA_NODE_HDMI2_COLOR_DICOMSIM,             MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_BLENDING,             MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_Blending.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER,                 MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_USER.conf),                  0, 0},
    {eDATA_NODE_HDMI2_COLOR_HDR,                  MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_HDMI2_COLOR_3D,                   MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_3D.conf),                    0, 0},
    {eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_2D_High_Speed.conf),         0, 0},

#if 0
    {eDATA_NODE_DVID_COMMON,                      MNT_CONFIG_BAK_SOURCE(/DVID_Common.conf),                       0, 0}, //50
    {eDATA_NODE_DVID_HSG_CINEMA,                  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_Cinema.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_BRIGHT,                  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_Bright.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_ENHANCED,                MNT_CONFIG_BAK_SOURCE(/DVID_HSG_Enhanced.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_REC709,                  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_REC709.conf),                   0, 0},
    {eDATA_NODE_DVID_HSG_DICOMSIM,                MNT_CONFIG_BAK_SOURCE(/DVID_HSG_DICOMSIM.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_BLENDING,                MNT_CONFIG_BAK_SOURCE(/DVID_HSG_Blending.conf),                 0, 0},
    {eDATA_NODE_DVID_HSG_USER,                    MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER.conf),                     0, 0},
    {eDATA_NODE_DVID_HSG_HDR,                     MNT_CONFIG_BAK_SOURCE(/DVID_HSG_HDR.conf),                      0, 0},
    {eDATA_NODE_DVID_HSG_3D,                      MNT_CONFIG_BAK_SOURCE(/DVID_HSG_3D.conf),                       0, 0},
    {eDATA_NODE_DVID_HSG_2D_HIGH_SPEED,           MNT_CONFIG_BAK_SOURCE(/DVID_HSG_2D_High_Speed.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_CINEMA,                MNT_CONFIG_BAK_SOURCE(/DVID_Color_Cinema.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_BRIGHT,                MNT_CONFIG_BAK_SOURCE(/DVID_Color_Bright.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_ENHANCED,              MNT_CONFIG_BAK_SOURCE(/DVID_Color_Enhanced.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_REC709,                MNT_CONFIG_BAK_SOURCE(/DVID_Color_REC709.conf),                 0, 0},
    {eDATA_NODE_DVID_COLOR_DICOMSIM,              MNT_CONFIG_BAK_SOURCE(/DVID_Color_DICOMSIM.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_BLENDING,              MNT_CONFIG_BAK_SOURCE(/DVID_Color_Blending.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_USER,                  MNT_CONFIG_BAK_SOURCE(/DVID_Color_USER.conf),                   0, 0},
    {eDATA_NODE_DVID_COLOR_HDR,                   MNT_CONFIG_BAK_SOURCE(/DVID_Color_HDR.conf),                    0, 0},
    {eDATA_NODE_DVID_COLOR_3D,                    MNT_CONFIG_BAK_SOURCE(/DVID_Color_3D.conf),                     0, 0},
    {eDATA_NODE_DVID_COLOR_2D_HIGH_SPEED,         MNT_CONFIG_BAK_SOURCE(/DVID_Color_2D_High_Speed.conf),          0, 0},
#endif /* 0 */

    {eDATA_NODE_DP_COMMON,                        MNT_CONFIG_BAK_SOURCE(/DP_Common.conf),                         0, 0}, //50
    {eDATA_NODE_DP_HSG_CINEMA,                    MNT_CONFIG_BAK_SOURCE(/DP_HSG_Cinema.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_BRIGHT,                    MNT_CONFIG_BAK_SOURCE(/DP_HSG_Bright.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_ENHANCED,                  MNT_CONFIG_BAK_SOURCE(/DP_HSG_Enhanced.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_REC709,                    MNT_CONFIG_BAK_SOURCE(/DP_HSG_REC709.conf),                     0, 0},
    {eDATA_NODE_DP_HSG_DICOMSIM,                  MNT_CONFIG_BAK_SOURCE(/DP_HSG_DICOMSIM.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_BLENDING,                  MNT_CONFIG_BAK_SOURCE(/DP_HSG_Blending.conf),                   0, 0},
    {eDATA_NODE_DP_HSG_USER,                      MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER.conf),                       0, 0},
    {eDATA_NODE_DP_HSG_HDR,                       MNT_CONFIG_BAK_SOURCE(/DP_HSG_HDR.conf),                        0, 0},
    {eDATA_NODE_DP_HSG_3D,                        MNT_CONFIG_BAK_SOURCE(/DP_HSG_3D.conf),                         0, 0},
    {eDATA_NODE_DP_HSG_2D_HIGH_SPEED,             MNT_CONFIG_BAK_SOURCE(/DP_HSG_2D_High_Speed.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_CINEMA,                  MNT_CONFIG_BAK_SOURCE(/DP_Color_Cinema.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_BRIGHT,                  MNT_CONFIG_BAK_SOURCE(/DP_Color_Bright.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_ENHANCED,                MNT_CONFIG_BAK_SOURCE(/DP_Color_Enhanced.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_REC709,                  MNT_CONFIG_BAK_SOURCE(/DP_Color_REC709.conf),                   0, 0},
    {eDATA_NODE_DP_COLOR_DICOMSIM,                MNT_CONFIG_BAK_SOURCE(/DP_Color_DICOMSIM.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_BLENDING,                MNT_CONFIG_BAK_SOURCE(/DP_Color_Blending.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_USER,                    MNT_CONFIG_BAK_SOURCE(/DP_Color_USER.conf),                     0, 0},
    {eDATA_NODE_DP_COLOR_HDR,                     MNT_CONFIG_BAK_SOURCE(/DP_Color_HDR.conf),                      0, 0},
    {eDATA_NODE_DP_COLOR_3D,                      MNT_CONFIG_BAK_SOURCE(/DP_Color_3D.conf),                       0, 0},
    {eDATA_NODE_DP_COLOR_2D_HIGH_SPEED,           MNT_CONFIG_BAK_SOURCE(/DP_Color_2D_High_Speed.conf),            0, 0},

    {eDATA_NODE_3GSDI_COMMON,                     MNT_CONFIG_BAK_SOURCE(/3GSDI_Common.conf),                      0, 0}, //71
    {eDATA_NODE_3GSDI_HSG_CINEMA,                 MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_Cinema.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_BRIGHT,                 MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_Bright.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_ENHANCED,               MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_Enhanced.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_REC709,                 MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_REC709.conf),                  0, 0},
    {eDATA_NODE_3GSDI_HSG_DICOMSIM,               MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_DICOMSIM.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_BLENDING,               MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_Blending.conf),                0, 0},
    {eDATA_NODE_3GSDI_HSG_USER,                   MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER.conf),                    0, 0},
    {eDATA_NODE_3GSDI_HSG_HDR,                    MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_HDR.conf),                     0, 0},
    {eDATA_NODE_3GSDI_HSG_3D,                     MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_3D.conf),                      0, 0},
    {eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED,          MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_2D_High_Speed.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_CINEMA,               MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_Cinema.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_BRIGHT,               MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_Bright.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_ENHANCED,             MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_Enhanced.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_REC709,               MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_REC709.conf),                0, 0},
    {eDATA_NODE_3GSDI_COLOR_DICOMSIM,             MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_BLENDING,             MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_Blending.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER,                 MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_USER.conf),                  0, 0},
    {eDATA_NODE_3GSDI_COLOR_HDR,                  MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_HDR.conf),                   0, 0},
    {eDATA_NODE_3GSDI_COLOR_3D,                   MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_3D.conf),                    0, 0},
    {eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED,        MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_2D_High_Speed.conf),         0, 0},

    {eDATA_NODE_HDBASET_COMMON,                   MNT_CONFIG_BAK_SOURCE(/HDBASET_Common.conf),                    0, 0}, //92
    {eDATA_NODE_HDBASET_HSG_CINEMA,               MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_Cinema.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_BRIGHT,               MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_Bright.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_ENHANCED,             MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_Enhanced.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_REC709,               MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_REC709.conf),                0, 0},
    {eDATA_NODE_HDBASET_HSG_DICOMSIM,             MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_BLENDING,             MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_Blending.conf),              0, 0},
    {eDATA_NODE_HDBASET_HSG_USER,                 MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER.conf),                  0, 0},
    {eDATA_NODE_HDBASET_HSG_HDR,                  MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_HDR.conf),                   0, 0},
    {eDATA_NODE_HDBASET_HSG_3D,                   MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_3D.conf),                    0, 0},
    {eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED,        MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_2D_High_Speed.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_CINEMA,             MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_Cinema.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_BRIGHT,             MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_Bright.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_ENHANCED,           MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_Enhanced.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_REC709,             MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_REC709.conf),              0, 0},
    {eDATA_NODE_HDBASET_COLOR_DICOMSIM,           MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_BLENDING,           MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_Blending.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER,               MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_USER.conf),                0, 0},
    {eDATA_NODE_HDBASET_COLOR_HDR,                MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_HDR.conf),                 0, 0},
    {eDATA_NODE_HDBASET_COLOR_3D,                 MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_3D.conf),                  0, 0},
    {eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED,      MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_2D_High_Speed.conf),       0, 0},

    {eDATA_NODE_WAP_CALIBRATION_TAG,              MNT_CONFIG_BAK_WAP(/WAP_Calibration_Tag.conf),                  0, 0}, // 113
    {eDATA_NODE_WAP_CINEMA_RATIO,                 MNT_CONFIG_BAK_WAP(/WAP_Ratio_Cinema.conf),                     0, 0},
    {eDATA_NODE_WAP_BRIGHT_RATIO,                 MNT_CONFIG_BAK_WAP(/WAP_Ratio_Bright.conf),                     0, 0},
    {eDATA_NODE_WAP_ENHANCED_RATIO,               MNT_CONFIG_BAK_WAP(/WAP_Ratio_Enhanced.conf),                   0, 0},
    {eDATA_NODE_WAP_REC709_RATIO,                 MNT_CONFIG_BAK_WAP(/WAP_Ratio_REC709.conf),                     0, 0},
    {eDATA_NODE_WAP_DICOM_RATIO,                  MNT_CONFIG_BAK_WAP(/WAP_Ratio_DICOM.conf),                      0, 0},
    {eDATA_NODE_WAP_BLENDING_RATIO,               MNT_CONFIG_BAK_WAP(/WAP_Ratio_Blending.conf),                   0, 0},
    {eDATA_NODE_WAP_USER_RATIO,                   MNT_CONFIG_BAK_WAP(/WAP_Ratio_USER.conf),                       0, 0},
    {eDATA_NODE_WAP_HDR_RATIO,                    MNT_CONFIG_BAK_WAP(/WAP_Ratio_HDR.conf),                        0, 0},
    {eDATA_NODE_WAP_3D_RATIO,                     MNT_CONFIG_BAK_WAP(/WAP_Ratio_3D.conf),                         0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO,          MNT_CONFIG_BAK_WAP(/WAP_Ratio_2DHSP.conf),                      0, 0},

    {eDATA_NODE_WAP_CINEMA_OFFSET,                MNT_CONFIG_BAK_WAP(/WAP_Offset_Cinema.conf),                    0, 0}, //124
    {eDATA_NODE_WAP_BRIGHT_OFFSET,                MNT_CONFIG_BAK_WAP(/WAP_Offset_Bright.conf),                    0, 0},
    {eDATA_NODE_WAP_ENHANCED_OFFSET,              MNT_CONFIG_BAK_WAP(/WAP_Offset_Enhanced.conf),                  0, 0},
    {eDATA_NODE_WAP_REC709_OFFSET,                MNT_CONFIG_BAK_WAP(/WAP_Offset_REC709.conf),                    0, 0},
    {eDATA_NODE_WAP_DICOM_OFFSET,                 MNT_CONFIG_BAK_WAP(/WAP_Offset_DICOM.conf),                     0, 0},
    {eDATA_NODE_WAP_BLENDING_OFFSET,              MNT_CONFIG_BAK_WAP(/WAP_Offset_Blending.conf),                  0, 0},
    {eDATA_NODE_WAP_USER_OFFSET,                  MNT_CONFIG_BAK_WAP(/WAP_Offset_USER.conf),                      0, 0},
    {eDATA_NODE_WAP_HDR_OFFSET,                   MNT_CONFIG_BAK_WAP(/WAP_Offset_HDR.conf),                       0, 0},
    {eDATA_NODE_WAP_3D_OFFSET,                    MNT_CONFIG_BAK_WAP(/WAP_Offset_3D.conf),                        0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET,         MNT_CONFIG_BAK_WAP(/WAP_Offset_2DHSP.conf),                     0, 0},

    {eDATA_NODE_WAP_CINEMA_PWM,                   MNT_CONFIG_BAK_WAP(/WAP_PWM_Cinema.conf),                       0, 0}, //134
    {eDATA_NODE_WAP_BRIGHT_PWM,                   MNT_CONFIG_BAK_WAP(/WAP_PWM_Bright.conf),                       0, 0},
    {eDATA_NODE_WAP_ENHANCED_PWM,                 MNT_CONFIG_BAK_WAP(/WAP_PWM_Enhanced.conf),                     0, 0},
    {eDATA_NODE_WAP_REC709_PWM,                   MNT_CONFIG_BAK_WAP(/WAP_PWM_REC709.conf),                       0, 0},
    {eDATA_NODE_WAP_DICOM_PWM,                    MNT_CONFIG_BAK_WAP(/WAP_PWM_DICOM.conf),                        0, 0},
    {eDATA_NODE_WAP_BLENDING_PWM,                 MNT_CONFIG_BAK_WAP(/WAP_PWM_Blending.conf),                     0, 0},
    {eDATA_NODE_WAP_USER_PWM,                     MNT_CONFIG_BAK_WAP(/WAP_PWM_USER.conf),                         0, 0},
    {eDATA_NODE_WAP_HDR_PWM,                      MNT_CONFIG_BAK_WAP(/WAP_PWM_HDR.conf),                          0, 0},
    {eDATA_NODE_WAP_3D_PWM,                       MNT_CONFIG_BAK_WAP(/WAP_PWM_3D.conf),                           0, 0},
    {eDATA_NODE_WAP_2D_HIGH_SPEED_PWM,            MNT_CONFIG_BAK_WAP(/WAP_PWM_2DHSP.conf),                        0, 0},

    {eDATA_NODE_HDMI1_COLOR_USER_CINEMA,          MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_Cinema.conf),           0, 0}, // 144
    {eDATA_NODE_HDMI1_COLOR_USER_BRIGHT,          MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_ENHANCED,        MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_REC709,          MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM,        MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_BLENDING,        MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_HDR,             MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_3D,              MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_BAK_SOURCE(/HDMI1_Color_User_2D_High_Speed.conf),    0, 0},

    {eDATA_NODE_HDMI2_COLOR_USER_CINEMA,          MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_Cinema.conf),           0, 0}, //154
    {eDATA_NODE_HDMI2_COLOR_USER_BRIGHT,          MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_ENHANCED,        MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_REC709,          MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM,        MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_BLENDING,        MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_HDR,             MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_3D,              MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_BAK_SOURCE(/HDMI2_Color_User_2D_High_Speed.conf),    0, 0},

#if 0
    {eDATA_NODE_DVID_COLOR_USER_CINEMA,           MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_Cinema.conf),            0, 0}, //164
    {eDATA_NODE_DVID_COLOR_USER_BRIGHT,           MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_Bright.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_USER_ENHANCED,         MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_Enhanced.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_REC709,           MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_REC709.conf),            0, 0},
    {eDATA_NODE_DVID_COLOR_USER_DICOMSIM,         MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_DICOMSIM.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_BLENDING,         MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_Blending.conf),          0, 0},
    {eDATA_NODE_DVID_COLOR_USER_HDR,              MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_HDR.conf),               0, 0},
    {eDATA_NODE_DVID_COLOR_USER_3D,               MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_3D.conf),                0, 0},
    {eDATA_NODE_DVID_COLOR_USER_2D_HIGH_SPEED,    MNT_CONFIG_BAK_SOURCE(/DVID_Color_User_2D_High_Speed.conf),     0, 0},
#endif /* 0 */

    {eDATA_NODE_DP_COLOR_USER_CINEMA,             MNT_CONFIG_BAK_SOURCE(/DP_Color_User_Cinema.conf),              0, 0}, //164
    {eDATA_NODE_DP_COLOR_USER_BRIGHT,             MNT_CONFIG_BAK_SOURCE(/DP_Color_User_Bright.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_USER_ENHANCED,           MNT_CONFIG_BAK_SOURCE(/DP_Color_User_Enhanced.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_REC709,             MNT_CONFIG_BAK_SOURCE(/DP_Color_User_REC709.conf),              0, 0},
    {eDATA_NODE_DP_COLOR_USER_DICOMSIM,           MNT_CONFIG_BAK_SOURCE(/DP_Color_User_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_BLENDING,           MNT_CONFIG_BAK_SOURCE(/DP_Color_User_Blending.conf),            0, 0},
    {eDATA_NODE_DP_COLOR_USER_HDR,                MNT_CONFIG_BAK_SOURCE(/DP_Color_User_HDR.conf),                 0, 0},
    {eDATA_NODE_DP_COLOR_USER_3D,                 MNT_CONFIG_BAK_SOURCE(/DP_Color_User_3D.conf),                  0, 0},
    {eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED,      MNT_CONFIG_BAK_SOURCE(/DP_Color_User_2D_High_Speed.conf),       0, 0},

    {eDATA_NODE_3GSDI_COLOR_USER_CINEMA,          MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_Cinema.conf),           0, 0}, //174
    {eDATA_NODE_3GSDI_COLOR_USER_BRIGHT,          MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_Bright.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_ENHANCED,        MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_Enhanced.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_REC709,          MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_REC709.conf),           0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM,        MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_BLENDING,        MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_Blending.conf),         0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_HDR,             MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_HDR.conf),              0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_3D,              MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_3D.conf),               0, 0},
    {eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED,   MNT_CONFIG_BAK_SOURCE(/3GSDI_Color_User_2D_High_Speed.conf),    0, 0},

    {eDATA_NODE_HDBASET_COLOR_USER_CINEMA,        MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_Cinema.conf),         0, 0}, //184
    {eDATA_NODE_HDBASET_COLOR_USER_BRIGHT,        MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_Bright.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_ENHANCED,      MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_Enhanced.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_REC709,        MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_REC709.conf),         0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM,      MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_DICOMSIM.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_BLENDING,      MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_Blending.conf),       0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_HDR,           MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_HDR.conf),            0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_3D,            MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_3D.conf),             0, 0},
    {eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED, MNT_CONFIG_BAK_SOURCE(/HDBASET_Color_User_2D_High_Speed.conf),  0, 0},

    {eDATA_NODE_HDMI1_HSG_USER_CINEMA,            MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_Cinema.conf),             0, 0}, //194
    {eDATA_NODE_HDMI1_HSG_USER_BRIGHT,         	  MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_ENHANCED,          MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_REC709,		      MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_REC709.conf),			  0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_DICOMSIM,          MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_BLENDING,          MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_HDR,			  	  MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_HDR.conf), 		 	      0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_3D,                MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_BAK_SOURCE(/HDMI1_HSG_USER_2D_High_Speed.conf),      0, 0},

    {eDATA_NODE_HDMI2_HSG_USER_CINEMA,		      MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_Cinema.conf),	          0, 0}, //204
    {eDATA_NODE_HDMI2_HSG_USER_BRIGHT,            MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_ENHANCED,          MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_REC709,		      MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_REC709.conf),			  0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_DICOMSIM,          MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_BLENDING,          MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_HDR,				  MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_HDR.conf), 		 	      0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_3D,                MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_BAK_SOURCE(/HDMI2_HSG_USER_2D_High_Speed.conf),      0, 0},

#if 0
	{eDATA_NODE_DVID_HSG_USER_CINEMA,			  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_Cinema.conf),			  0, 0}, //214
    {eDATA_NODE_DVID_HSG_USER_BRIGHT,             MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_Bright.conf),              0, 0},
    {eDATA_NODE_DVID_HSG_USER_ENHANCED,       	  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_Enhanced.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_REC709,		      MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_REC709.conf),			  0, 0},
    {eDATA_NODE_DVID_HSG_USER_DICOMSIM,           MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_DICOMSIM.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_BLENDING,           MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_Blending.conf),            0, 0},
    {eDATA_NODE_DVID_HSG_USER_HDR,			      MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_HDR.conf), 		 	      0, 0},
    {eDATA_NODE_DVID_HSG_USER_3D,             	  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_3D.conf),                  0, 0},
    {eDATA_NODE_DVID_HSG_USER_2D_HIGH_SPEED,  	  MNT_CONFIG_BAK_SOURCE(/DVID_HSG_USER_2D_High_Speed.conf),       0, 0},
#endif /* 0 */

	{eDATA_NODE_DP_HSG_USER_CINEMA,			      MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_Cinema.conf),			      0, 0}, //214
    {eDATA_NODE_DP_HSG_USER_BRIGHT,               MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_Bright.conf),                0, 0},
    {eDATA_NODE_DP_HSG_USER_ENHANCED,       	  MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_Enhanced.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_REC709,		          MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_REC709.conf),			      0, 0},
    {eDATA_NODE_DP_HSG_USER_DICOMSIM,             MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_DICOMSIM.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_BLENDING,             MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_Blending.conf),              0, 0},
    {eDATA_NODE_DP_HSG_USER_HDR,			      MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_HDR.conf), 		 	      0, 0},
    {eDATA_NODE_DP_HSG_USER_3D,             	  MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_3D.conf),                    0, 0},
    {eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED,  	  MNT_CONFIG_BAK_SOURCE(/DP_HSG_USER_2D_High_Speed.conf),         0, 0},

	{eDATA_NODE_3GSDI_HSG_USER_CINEMA,			  MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_Cinema.conf),			  0, 0}, //224
    {eDATA_NODE_3GSDI_HSG_USER_BRIGHT,            MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_Bright.conf),             0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_ENHANCED,          MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_Enhanced.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_REC709,		      MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_REC709.conf),			  0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_DICOMSIM,          MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_DICOMSIM.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_BLENDING,          MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_Blending.conf),           0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_HDR,			      MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_HDR.conf), 		 	      0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_3D,                MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_3D.conf),                 0, 0},
    {eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED,     MNT_CONFIG_BAK_SOURCE(/3GSDI_HSG_USER_2D_High_Speed.conf),      0, 0},

	{eDATA_NODE_HDBASET_HSG_USER_CINEMA,		  MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_Cinema.conf), 		  0, 0}, //234
    {eDATA_NODE_HDBASET_HSG_USER_BRIGHT,          MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_Bright.conf),           0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_ENHANCED,        MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_Enhanced.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_REC709,		  MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_REC709.conf),			  0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_DICOMSIM,        MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_DICOMSIM.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_BLENDING,        MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_Blending.conf),         0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_HDR,			  MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_HDR.conf), 		 	  0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_3D,              MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_3D.conf),               0, 0},
    {eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED,   MNT_CONFIG_BAK_SOURCE(/HDBASET_HSG_USER_2D_High_Speed.conf),    0, 0},
};

#define SOURCE_DATA_NODE_BAK_NUMBER sizeof(m_sSourceDataNodeBakCtrl)/sizeof(m_sSourceDataNodeBakCtrl[0])
#endif /* CONF_BACKUP */

void utilDataMgrSourceInit(sSOURCE_PARA_TABLE sSourceTable);
sPARA_FORMAT* utilDataMgrSource_ParaTableGet(eDATA_NODE eNode);

#endif /* _UTIL_DATAMGRSOURCETABLE_ */

