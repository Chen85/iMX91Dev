// ===============================================================================
// FILE NAME: utilDataMgrSource.c
// DESCRIPTION:
//
//
// Modification History
// --------------------
// 2021/12/24, Larry Create
// --------------------
// ===============================================================================

#include "utilDataMgrSourceTable.h"

static sSOURCE_PARA_TABLE m_sSourceTable = {NULL};

// ==============================================================================
// FUNCTION NAME: utilDataMgrSourceInit
// DESCRIPTION:
//
//
// Params:
//
// Returns:
//
//
// Modification History
// --------------------
// 2021/12/24, Larry Create
// --------------------
// ==============================================================================
void utilDataMgrSourceInit(sSOURCE_PARA_TABLE sSourceTable)
{
    m_sSourceTable.p_sSourceData        = sSourceTable.p_sSourceData;
    m_sSourceTable.p_sWAP_RatioData     = sSourceTable.p_sWAP_RatioData;
    m_sSourceTable.p_sWAP_OffsetData    = sSourceTable.p_sWAP_OffsetData;
    m_sSourceTable.p_sWAP_PWMData       = sSourceTable.p_sWAP_PWMData;
}

// ==============================================================================
// FUNCTION NAME: utilDataMgrSource_ParaTableGet
// DESCRIPTION:
//
//
// Params:
//
// Returns:
//
//
// Modification History
// --------------------
// 2021/12/24, Larry Create
// --------------------
// ==============================================================================
sPARA_FORMAT* utilDataMgrSource_ParaTableGet(eDATA_NODE eNode)
{
    sPARA_FORMAT *psPara = NULL;

    switch(eNode)
    {
    	case eDATA_NODE_HDMI1_COLOR_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_Cinema;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_Bright;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_Enhanced;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_REC709;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_Blending;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_USER;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_HDR;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_3D;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_User_2D_High_Speed;
            break;

    	case eDATA_NODE_HDMI2_COLOR_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_Cinema;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_Bright;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_Enhanced;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_REC709;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_Blending;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_USER;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_HDR;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_3D;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_User_2D_High_Speed;
            break;
#if 0
    	case eDATA_NODE_DVID_COLOR_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_Cinema;
            break;
        case eDATA_NODE_DVID_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_Bright;
            break;
        case eDATA_NODE_DVID_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_Enhanced;
            break;
        case eDATA_NODE_DVID_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_REC709;
            break;
        case eDATA_NODE_DVID_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_DVID_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_Blending;
            break;
        case eDATA_NODE_DVID_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_USER;
            break;
        case eDATA_NODE_DVID_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_HDR;
            break;
        case eDATA_NODE_DVID_COLOR_USER_3D:
            psPara =  m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_3D;
            break;
        case eDATA_NODE_DVID_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_User_2D_High_Speed;
            break;
#endif /* 0 */

    	case eDATA_NODE_DP_COLOR_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_Cinema;
            break;
        case eDATA_NODE_DP_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_Bright;
            break;
        case eDATA_NODE_DP_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_Enhanced;
            break;
        case eDATA_NODE_DP_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_REC709;
            break;
        case eDATA_NODE_DP_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_DP_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_Blending;
            break;
        case eDATA_NODE_DP_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_USER;
            break;
        case eDATA_NODE_DP_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_HDR;
            break;
        case eDATA_NODE_DP_COLOR_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_3D;
            break;
        case eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_User_2D_High_Speed;
            break;

    	case eDATA_NODE_3GSDI_COLOR_USER_CINEMA:
            psPara =m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_Cinema;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_Bright;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_Enhanced;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_REC709;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_Blending;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_USER;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_HDR;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_3D;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_User_2D_High_Speed;
            break;

    	case eDATA_NODE_HDBASET_COLOR_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_Cinema;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_Bright;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_Enhanced;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_REC709;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_DICOMSIM;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_Blending;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_USER;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_HDR;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_3D;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_User_2D_High_Speed;
            break;

        case eDATA_NODE_HDMI1_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sCommon;
            break;
        case eDATA_NODE_HDMI1_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_Cinema;
            break;
        case eDATA_NODE_HDMI1_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_Bright;
            break;
        case eDATA_NODE_HDMI1_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_Enhanced;
            break;
        case eDATA_NODE_HDMI1_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_REC709;
            break;
        case eDATA_NODE_HDMI1_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_HDMI1_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_Blending;
            break;
        case eDATA_NODE_HDMI1_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER;
            break;
        case eDATA_NODE_HDMI1_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_HDR;
            break;
        case eDATA_NODE_HDMI1_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_3D;
            break;
		case eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_HDMI1_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_Cinema;
            break;
        case eDATA_NODE_HDMI1_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_Bright;
            break;
        case eDATA_NODE_HDMI1_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_Enhanced;
            break;
        case eDATA_NODE_HDMI1_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_REC709;
            break;
        case eDATA_NODE_HDMI1_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_DICOMSIM;
            break;
        case eDATA_NODE_HDMI1_COLOR_BLENDING:
            psPara =  m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_Blending;
            break;
        case eDATA_NODE_HDMI1_COLOR_USER:
            psPara =  m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_USER;
            break;
        case eDATA_NODE_HDMI1_COLOR_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_HDR;
            break;
        case eDATA_NODE_HDMI1_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_3D;
            break;
        case eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sColor_2D_High_Speed;
            break;

        case eDATA_NODE_HDMI2_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sCommon;
            break;
        case eDATA_NODE_HDMI2_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_Cinema;
            break;
        case eDATA_NODE_HDMI2_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_Bright;
            break;
        case eDATA_NODE_HDMI2_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_Enhanced;
            break;
        case eDATA_NODE_HDMI2_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_REC709;
            break;
        case eDATA_NODE_HDMI2_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_HDMI2_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_Blending;
            break;
        case eDATA_NODE_HDMI2_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER;
            break;
        case eDATA_NODE_HDMI2_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_HDR;
            break;
        case eDATA_NODE_HDMI2_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_3D;
            break;
		case eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_HDMI2_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_Cinema;
            break;
        case eDATA_NODE_HDMI2_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_Bright;
            break;
        case eDATA_NODE_HDMI2_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_Enhanced;
            break;
        case eDATA_NODE_HDMI2_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_REC709;
            break;
        case eDATA_NODE_HDMI2_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_DICOMSIM;
            break;
        case eDATA_NODE_HDMI2_COLOR_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_Blending;
            break;
        case eDATA_NODE_HDMI2_COLOR_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_USER;
            break;
        case eDATA_NODE_HDMI2_COLOR_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_HDR;
            break;
        case eDATA_NODE_HDMI2_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_3D;
            break;
        case eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sColor_2D_High_Speed;
            break;
#if 0
        case eDATA_NODE_DVID_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sCommon;
            break;
        case eDATA_NODE_DVID_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_Cinema;
            break;
        case eDATA_NODE_DVID_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_Bright;
            break;
        case eDATA_NODE_DVID_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_Enhanced;
            break;
        case eDATA_NODE_DVID_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_REC709;
            break;
        case eDATA_NODE_DVID_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_DVID_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_Blending;
            break;
        case eDATA_NODE_DVID_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER;
            break;
        case eDATA_NODE_DVID_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_HDR;
            break;
        case eDATA_NODE_DVID_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_3D;
            break;
		case eDATA_NODE_DVID_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_DVID_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_Cinema;
            break;
        case eDATA_NODE_DVID_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_Bright;
            break;
        case eDATA_NODE_DVID_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_Enhanced;
            break;
        case eDATA_NODE_DVID_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_REC709;
            break;
        case eDATA_NODE_DVID_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_DICOMSIM;
            break;
        case eDATA_NODE_DVID_COLOR_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_Blending;
            break;
        case eDATA_NODE_DVID_COLOR_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_USER;
            break;
        case eDATA_NODE_DVID_COLOR_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_HDR;
            break;
        case eDATA_NODE_DVID_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_3D;
            break;
        case eDATA_NODE_DVID_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sColor_2D_High_Speed;
            break;
#endif /* 0 */

        case eDATA_NODE_DP_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sCommon;
            break;
        case eDATA_NODE_DP_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_Cinema;
            break;
        case eDATA_NODE_DP_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_Bright;
            break;
        case eDATA_NODE_DP_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_Enhanced;
            break;
        case eDATA_NODE_DP_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_REC709;
            break;
        case eDATA_NODE_DP_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_DP_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_Blending;
            break;
        case eDATA_NODE_DP_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER;
            break;
        case eDATA_NODE_DP_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_HDR;
            break;
        case eDATA_NODE_DP_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_3D;
            break;
		case eDATA_NODE_DP_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_DP_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_Cinema;
            break;
        case eDATA_NODE_DP_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_Bright;
            break;
        case eDATA_NODE_DP_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_Enhanced;
            break;
        case eDATA_NODE_DP_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_REC709;
            break;
        case eDATA_NODE_DP_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_DICOMSIM;
            break;
        case eDATA_NODE_DP_COLOR_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_Blending;
            break;
        case eDATA_NODE_DP_COLOR_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_USER;
            break;
        case eDATA_NODE_DP_COLOR_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_HDR;
            break;
        case eDATA_NODE_DP_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_3D;
            break;
        case eDATA_NODE_DP_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sColor_2D_High_Speed;
            break;

        case eDATA_NODE_3GSDI_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sCommon;
            break;
        case eDATA_NODE_3GSDI_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_Cinema;
            break;
        case eDATA_NODE_3GSDI_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_Bright;
            break;
        case eDATA_NODE_3GSDI_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_Enhanced;
            break;
        case eDATA_NODE_3GSDI_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_REC709;
            break;
        case eDATA_NODE_3GSDI_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_3GSDI_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_Blending;
            break;
        case eDATA_NODE_3GSDI_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER;
            break;
        case eDATA_NODE_3GSDI_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_HDR;
            break;
        case eDATA_NODE_3GSDI_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_3D;
            break;
		case eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_3GSDI_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_Cinema;
            break;
        case eDATA_NODE_3GSDI_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_Bright;
            break;
        case eDATA_NODE_3GSDI_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_Enhanced;
            break;
        case eDATA_NODE_3GSDI_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_REC709;
            break;
        case eDATA_NODE_3GSDI_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_DICOMSIM;
            break;
        case eDATA_NODE_3GSDI_COLOR_BLENDING:
            psPara =  m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_Blending;
            break;
        case eDATA_NODE_3GSDI_COLOR_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_USER;
            break;
        case eDATA_NODE_3GSDI_COLOR_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_HDR;
            break;
        case eDATA_NODE_3GSDI_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_3D;
            break;
        case eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sColor_2D_High_Speed;
            break;

        case eDATA_NODE_HDBASET_COMMON:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sCommon;
            break;
        case eDATA_NODE_HDBASET_HSG_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_Cinema;
            break;
        case eDATA_NODE_HDBASET_HSG_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_Bright;
            break;
        case eDATA_NODE_HDBASET_HSG_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_Enhanced;
            break;
        case eDATA_NODE_HDBASET_HSG_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_REC709;
            break;
        case eDATA_NODE_HDBASET_HSG_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_DICOMSIM;
            break;
        case eDATA_NODE_HDBASET_HSG_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_Blending;
            break;
        case eDATA_NODE_HDBASET_HSG_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER;
            break;
        case eDATA_NODE_HDBASET_HSG_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_HDR;
            break;
        case eDATA_NODE_HDBASET_HSG_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_3D;
            break;
		case eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_2D_High_Speed;
            break;

        case eDATA_NODE_HDBASET_COLOR_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_Cinema;
            break;
        case eDATA_NODE_HDBASET_COLOR_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_Bright;
            break;
        case eDATA_NODE_HDBASET_COLOR_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_Enhanced;
            break;
        case eDATA_NODE_HDBASET_COLOR_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_REC709;
            break;
        case eDATA_NODE_HDBASET_COLOR_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_DICOMSIM;
            break;
        case eDATA_NODE_HDBASET_COLOR_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_Blending;
            break;
        case eDATA_NODE_HDBASET_COLOR_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_USER;
            break;
        case eDATA_NODE_HDBASET_COLOR_HDR:
            psPara =  m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_HDR;
            break;
        case eDATA_NODE_HDBASET_COLOR_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_3D;
            break;
        case eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sColor_2D_High_Speed;
            break;

        case eDATA_NODE_WAP_CINEMA_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_CINEMA].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BRIGHT_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_BRIGHT].sPresetMode;
        	break;
        case eDATA_NODE_WAP_ENHANCED_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_ENHANCED].sPresetMode;
        	break;
        case eDATA_NODE_WAP_REC709_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_REC709].sPresetMode;
        	break;
        case eDATA_NODE_WAP_DICOM_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_DICOMSIM].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BLENDING_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_BLENDING].sPresetMode;
        	break;
        case eDATA_NODE_WAP_USER_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_USER].sPresetMode;
        	break;
        case eDATA_NODE_WAP_HDR_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_HDR].sPresetMode;
        	break;
        case eDATA_NODE_WAP_3D_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_3D].sPresetMode;
        	break;
        case eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO:
        	psPara = m_sSourceTable.p_sWAP_RatioData[eIFC_WAP_2DHIGHSPEED].sPresetMode;
        	break;

        case eDATA_NODE_WAP_CINEMA_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_CINEMA].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BRIGHT_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_BRIGHT].sPresetMode;
        	break;
        case eDATA_NODE_WAP_ENHANCED_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_ENHANCED].sPresetMode;
        	break;
        case eDATA_NODE_WAP_REC709_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_REC709].sPresetMode;
        	break;
        case eDATA_NODE_WAP_DICOM_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_DICOMSIM].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BLENDING_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_BLENDING].sPresetMode;
        	break;
        case eDATA_NODE_WAP_USER_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_USER].sPresetMode;
        	break;
        case eDATA_NODE_WAP_HDR_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_HDR].sPresetMode;
        	break;
        case eDATA_NODE_WAP_3D_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_3D].sPresetMode;
        	break;
        case eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET:
        	psPara = m_sSourceTable.p_sWAP_OffsetData[eIFC_WAP_2DHIGHSPEED].sPresetMode;
        	break;

        case eDATA_NODE_WAP_CINEMA_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_CINEMA].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BRIGHT_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_BRIGHT].sPresetMode;
        	break;
        case eDATA_NODE_WAP_ENHANCED_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_ENHANCED].sPresetMode;
        	break;
        case eDATA_NODE_WAP_REC709_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_REC709].sPresetMode;
        	break;
        case eDATA_NODE_WAP_DICOM_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_DICOMSIM].sPresetMode;
        	break;
        case eDATA_NODE_WAP_BLENDING_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_BLENDING].sPresetMode;
        	break;
        case eDATA_NODE_WAP_USER_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_USER].sPresetMode;
        	break;
        case eDATA_NODE_WAP_HDR_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_HDR].sPresetMode;
        	break;
        case eDATA_NODE_WAP_3D_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_3D].sPresetMode;
        	break;
        case eDATA_NODE_WAP_2D_HIGH_SPEED_PWM:
        	psPara = m_sSourceTable.p_sWAP_PWMData[eIFC_WAP_2DHIGHSPEED].sPresetMode;
        	break;

		case eDATA_NODE_HDMI1_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_Bright;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_REC709;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_Blending;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_USER;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_HDR;
            break;
        case eDATA_NODE_HDMI1_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_3D;
            break;
		case eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI1].sHSG_USER_2D_High_Speed;
            break;

        case eDATA_NODE_HDMI2_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_Bright;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_REC709;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_Blending;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_USER;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_HDR;
            break;
        case eDATA_NODE_HDMI2_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_3D;
            break;
		case eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDMI2].sHSG_USER_2D_High_Speed;
            break;

#if 0
        case eDATA_NODE_DVID_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_DVID_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_Bright;
            break;
        case eDATA_NODE_DVID_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_DVID_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_REC709;
            break;
        case eDATA_NODE_DVID_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_DVID_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_Blending;
            break;
        case eDATA_NODE_DVID_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_USER;
            break;
        case eDATA_NODE_DVID_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_HDR;
            break;
        case eDATA_NODE_DVID_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_3D;
            break;
		case eDATA_NODE_DVID_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DVI].sHSG_USER_2D_High_Speed;
            break;
#endif /* 0 */

        case eDATA_NODE_DP_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_DP_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_Bright;
            break;
        case eDATA_NODE_DP_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_DP_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_REC709;
            break;
        case eDATA_NODE_DP_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_DP_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_Blending;
            break;
        case eDATA_NODE_DP_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_USER;
            break;
        case eDATA_NODE_DP_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_HDR;
            break;
        case eDATA_NODE_DP_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_3D;
            break;
		case eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_DISPLAYPORT].sHSG_USER_2D_High_Speed;
            break;

        case eDATA_NODE_3GSDI_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_Bright;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_REC709;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_Blending;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_USER;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_HDR;
            break;
        case eDATA_NODE_3GSDI_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_3D;
            break;
		case eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_3GSDI].sHSG_USER_2D_High_Speed;
            break;

        case eDATA_NODE_HDBASET_HSG_USER_CINEMA:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_Cinema;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_BRIGHT:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_Bright;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_ENHANCED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_Enhanced;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_REC709:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_REC709;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_DICOMSIM:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_DICOMSIM;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_BLENDING:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_Blending;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_USER:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_USER;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_HDR:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_HDR;
            break;
        case eDATA_NODE_HDBASET_HSG_USER_3D:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_3D;
            break;
		case eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED:
            psPara = m_sSourceTable.p_sSourceData[eGUI_SOURCE_ID_HDBASET].sHSG_USER_2D_High_Speed;
            break;

        default:
            psPara = NULL;
            break;
    }

    return psPara;
}


