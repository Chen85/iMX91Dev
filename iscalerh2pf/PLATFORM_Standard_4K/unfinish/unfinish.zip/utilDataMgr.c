#include "utilDataMgrAPI.h"
#include "utilDataMapping.h"
#include "utilDbgMsg.h"
#include "utilHostAPI.h"

#include "cJSON.h"
#include "conf.h"
#include "GEC_EventTable.h"
#include "appDataMgr.h"			//G100_Doulas_0004
#include "appIllumination.h"	//G100_Doulas_0010
#include "appLANProcAPI.h"
#include "appGui.h"

#include "dvMCUDriver.h"
#include "utilDataMgrSourceTable.h"


typedef struct
{
    sDATA_NODE_CTRL *psNode;
    UINT16          uiSize;
}sDATA_NODE_GROUP;

sPARA_FORMAT* utilDataMgr_ParaTableGet(eDATA_NODE eNode);
UINT32 utilDataMgr_ParaTableSizeGet(eDATA_NODE eNode);

sPARA_FORMAT m_sCustomer_Version[] =
{
    {eCUSTOMER_VERSION_STAGE,   "VERSTAGE", "0"},
    {eCUSTOMER_VERSION_MAJOR,   "VERMAJOR", "0"},
    {eCUSTOMER_VERSION_MINOR,   "VERMINOR", "0"},
    {eCUSTOMER_VERSION_CODE,    "CODE",     "0"}
};
VERIFY_SIZE_OF(m_sCustomer_Version, sizeof(m_sCustomer_Version[0])*eCUSTOMER_VERSION_NUMBER);


sPARA_FORMAT m_sSystem_Version[] =
{
    {eCV_SCALER,    "SCALER",    "0"},
    {eCV_FRONTEND,  "FRONTEND",  "0"},
    {eCV_FORMATTER, "FORMATTER", "0"},
    {eCV_LD,        "LD",        "0"},
    {eCV_KEYPAD,    "KEYPAD",    "0"},
    {eCV_MOTOR,     "MOTOR",     "0"},
    {eCV_HDBASET,   "HDBASET",   "0"},
    {eCV_FPGA_1,    "FPGA_1",    "0"},
    {eCV_FPGA_2,    "FPGA_2",    "0"},
    {eCV_FPGA_3,    "FPGA_3",    "0"},
    {eCV_XFPGA,     "XFPGA",     "0"},
    {eCV_GEOMETRY,  "GEOMETRY",  "0"}
};
VERIFY_SIZE_OF(m_sSystem_Version, sizeof(m_sSystem_Version[0])*eVERSION_NUMBER);


sPARA_FORMAT m_sProjectorInfo_Default[] =
{
    {ePI_UCMAJOR,           "ucMajor","0"},
    {ePI_UCMINOR,           "ucMinor","0"},
    {ePI_UCSUBMINOR,        "ucSubminor","0"},
    {ePI_UCMODELNAME,       "ucModelName","NA"},
    {ePI_UCCUSTOM_CODE,     "ucCustomCode","00000000\0"},
    {ePI_UCSERIALNUMBER,    "ucSerialNumber","31211199"},
    {ePI_CUSTOM_REGION,     "ucRegion","0"},			//A65_OPTOMA_Doulas_0033
    {ePI_CUSTOM_DEFAULT_LOGO, "ucDefaultLogo","0"},		//A65_OPTOMA_Doulas_0033
    {ePI_UCMODEL_SWITCH, 	"ucModelSwitch","0"},	    //A65_OPTOMA_Julie_0064
    {ePI_UICHECKSUM,        "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sProjectorInfo_Default, sizeof(m_sProjectorInfo_Default[0])*ePI_NUMBER);


sPARA_FORMAT m_sSystemCal_Default[] =
{
    {eSC_UIRGBOFFSET_0,      "uiRGBOffset_0","0"},
    {eSC_UIYUVOFFSET_0,      "uiYUVOffset_0","0"},
    {eSC_UIRGBOFFSET2_0,     "uiRGBOffset2_0","0"},
    {eSC_UIYUVOFFSET2_0,     "uiYUVOffset2_0","0"},
    {eSC_UIRGBOFFSET_1,      "uiRGBOffset_1","0"},
    {eSC_UIYUVOFFSET_1,      "uiYUVOffset_1","0"},
    {eSC_UIRGBOFFSET2_1,     "uiRGBOffset2_1","0"},
    {eSC_UIYUVOFFSET2_1,     "uiYUVOffset2_1","0"},
    {eSC_UIRGBOFFSET_2,      "uiRGBOffset_2","0"},
    {eSC_UIYUVOFFSET_2,      "uiYUVOffset_2","0"},
    {eSC_UIRGBOFFSET2_2,     "uiRGBOffset2_2","0"},
    {eSC_UIYUVOFFSET2_2,     "uiYUVOffset2_2","0"},
    {eSC_UIRGBGAIN_0,        "uiRGBGain_0","802"},
    {eSC_UIRGBGAIN_1,        "uiRGBGain_1","804"},
    {eSC_UIRGBGAIN_2,        "uiRGBGain_2","804"},
    {eSC_UIYUVGAIN_0,        "uiYUVGain_0","540"},
    {eSC_UIYUVGAIN_1,        "uiYUVGain_1","680"},
    {eSC_UIYUVGAIN_2,        "uiYUVGain_2","535"},
    {eSC_UIRGBGAIN2_0,       "uiRGBGain2_0","801"},
    {eSC_UIRGBGAIN2_1,       "uiRGBGain2_1","801"},
    {eSC_UIRGBGAIN2_2,       "uiRGBGain2_2","808"},
    {eSC_UIYUVGAIN2_0,       "uiYUVGain2_0","540"},
    {eSC_UIYUVGAIN2_1,       "uiYUVGain2_1","680"},
    {eSC_UIYUVGAIN2_2,       "uiYUVGain2_2","535"},
    {eSC_UIFWINDEX_0,        "uiFWIndex_0","660"},
    {eSC_UIFWINDEX_1,        "uiFWIndex_1","660"},
    {eSC_UIPWINDEX_0,        "uiPWIndex_0","440"},
    {eSC_UIPWINDEX_1,        "uiPWIndex_1","440"},
    {eSC_UCPOWER_OFFSET,     "ucPOWER_OFFSET","0"},
    {eSC_UCCOLOR_OFFSET,     "ucCOLOR_OFFSET","100"},
    {eSC_UCABP_CALIBRATEFLAG,       "ucABP_CalibrateFlag","0"},
    {eSC_UILIGHTSENSORFULL_BLD_Y,   "uiLightSensorFull_BLD_Y","0"},
    {eSC_UILIGHTSENSORFULL_BLD_R,   "uiLightSensorFull_BLD_R","0"},
    {eSC_UILIGHTSENSORFULL_BLD_B,   "uiLightSensorFull_BLD_B","0"},
    {eSC_UILIGHTSENSORFULL_BLD_G,   "uiLightSensorFull_BLD_G","0"},
    {eSC_UILIGHTSENSORECO_BLD_Y,    "uiLightSensorEco_BLD_Y","0"},
    {eSC_UILIGHTSENSORECO_BLD_R,    "uiLightSensorEco_BLD_R","0"},
    {eSC_UILIGHTSENSORECO_BLD_B,    "uiLightSensorEco_BLD_B","0"},
    {eSC_UILIGHTSENSORECO_BLD_G,    "uiLightSensorEco_BLD_G","0"},
    {eSC_UILIGHTPWMFULL_BLD_Y,      "uiLightPWMFull_BLD_Y","0"},
    {eSC_UILIGHTPWMFULL_BLD_R,      "uiLightPWMFull_BLD_R","0"},
    {eSC_UILIGHTPWMFULL_BLD_B,      "uiLightPWMFull_BLD_B","0"},
    {eSC_UILIGHTPWMFULL_BLD_G,      "uiLightPWMFull_BLD_G","0"},
    {eSC_UILIGHTPWMECO_BLD_Y,       "uiLightPWMEco_BLD_Y","0"},
    {eSC_UILIGHTPWMECO_BLD_R,       "uiLightPWMEco_BLD_R","0"},
    {eSC_UILIGHTPWMECO_BLD_B,       "uiLightPWMEco_BLD_B","0"},
    {eSC_UILIGHTPWMECO_BLD_G,       "uiLightPWMEco_BLD_G","0"},
    {eSC_UILIGHTSENSORFULL_RLD_Y,   "uiLightSensorFull_RLD_Y","0"},
    {eSC_UILIGHTSENSORFULL_RLD_R,   "uiLightSensorFull_RLD_R","0"},
    {eSC_UILIGHTSENSORFULL_RLD_B,   "uiLightSensorFull_RLD_B","0"},
    {eSC_UILIGHTSENSORFULL_RLD_G,   "uiLightSensorFull_RLD_G","0"},
    {eSC_UILIGHTSENSORECO_RLD_Y,    "uiLightSensorEco_RLD_Y","0"},
    {eSC_UILIGHTSENSORECO_RLD_R,    "uiLightSensorEco_RLD_R","0"},
    {eSC_UILIGHTSENSORECO_RLD_B,    "uiLightSensorEco_RLD_B","0"},
    {eSC_UILIGHTSENSORECO_RLD_G,    "uiLightSensorEco_RLD_G","0"},
    {eSC_UILIGHTPWMFULL_RLD_Y,      "uiLightPWMFull_RLD_Y","0"},
    {eSC_UILIGHTPWMFULL_RLD_R,      "uiLightPWMFull_RLD_R","0"},
    {eSC_UILIGHTPWMFULL_RLD_B,      "uiLightPWMFull_RLD_B","0"},
    {eSC_UILIGHTPWMFULL_RLD_G,      "uiLightPWMFull_RLD_G","0"},
    {eSC_UILIGHTPWMECO_RLD_Y,       "uiLightPWMEco_RLD_Y","0"},
    {eSC_UILIGHTPWMECO_RLD_R,       "uiLightPWMEco_RLD_R","0"},
    {eSC_UILIGHTPWMECO_RLD_B,       "uiLightPWMEco_RLD_B","0"},
    {eSC_UILIGHTPWMECO_RLD_G,       "uiLightPWMEco_RLD_G","0"},
	{eSC_UCLIGHTSENSORTIME_Y,       "ucLightSensorTime_Y","0"},		//A65_OPTOMA_Doulas_0105 start
    {eSC_UCLIGHTSENSORTIME_R,       "ucLightSensorTime_R","0"},
    {eSC_UCLIGHTSENSORTIME_B,       "ucLightSensorTime_B","0"},
    {eSC_UCLIGHTSENSORTIME_G,       "ucLightSensorTime_G","0"},
    {eSC_UILIGHTSENSORTARGET_Y,     "uiLightSensorTarget_Y","0"},
    {eSC_UILIGHTSENSORTARGET_R,     "uiLightSensorTarget_R","0"},
    {eSC_UILIGHTSENSORTARGET_B,     "uiLightSensorTarget_B","0"},
    {eSC_UILIGHTSENSORTARGET_G,     "uiLightSensorTarget_G","0"},
    {eSC_UILIGHTSENSORTARGET_RY,    "uiLightSensorTarget_RY","0"},	//A65_OPTOMA_Doulas_0105 end
    {eSC_UILIGHTSENSORTARGET_RR,    "uiLightSensorTarget_RR","0"},
    {eSC_UCLIGHTSENSORGAIN_Y,       "afiLightSensorGain_Y","1.0"},  //A70G2_Owen_0002 Start
    {eSC_UCLIGHTSENSORGAIN_R,       "afiLightSensorGain_R","1.0"},
    {eSC_UCLIGHTSENSORGAIN_B,       "afiLightSensorGain_B","1.0"},
    {eSC_UCLIGHTSENSORGAIN_G,       "afiLightSensorGain_G","1.0"},
    {eSC_UCLIGHTSENSOROFFSET_Y,     "uiLightSensorOffset_Y","0"},
    {eSC_UCLIGHTSENSOROFFSET_R,     "uiLightSensorOffset_R","0"},
    {eSC_UCLIGHTSENSOROFFSET_B,     "uiLightSensorOffset_B","0"},
    {eSC_UCLIGHTSENSOROFFSET_G,     "uiLightSensorOffset_G","0"},   //A70G2_Owen_0002 End
    {eSC_UCUST,                     "ucUST","0"}, //A35G2_BRC_Casper_0089
    //{eSC_LENS_CALIBRATION_STATUS,   "ucLensCalibrationStatus","0"}, //R70K_AC_0009 //Larry禁用，不適合放在這裡
    {eSC_UICHECKSUM,                "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sSystemCal_Default, sizeof(m_sSystemCal_Default[0])*eSC_NUMBER);


sPARA_FORMAT m_sBurnin_Default[] =
{
    {eBI_URNINENABLE,       "ucBurnInEnable","0"},
    {eBI_UCLAMPON,          "ucLampOn","120"},
    {eBI_UCLAMPOFF,         "ucLampOff","15"},
    {eBI_UIBURNINCYCLE,     "uiBurnInCycle","10"},
    {eBI_UCBURNINMODE,      "ucBurnInMode","0"},
    {eBI_UCBURNINALWAYSON,  "ucBurnInAlwaysOn","0"},
    {eBI_UICHECKSUM,        "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sBurnin_Default, sizeof(m_sBurnin_Default[0])*eBI_NUMBER);

sPARA_FORMAT m_sStartup_Default[] =
{
    {eSU_UCFIRSTSTARTUPFLAG,    "ucFirstStartupFlag","1"},
    {eSU_UCUSTFIRSTSTARTUP,     "ucUSTFirstStartup","1"},
    {eSU_UCPINPROTECT,  "ucPINProtect","0"},
    {eSU_UCPASSWORD_0,  "ucPassWord_0","1"},
    {eSU_UCPASSWORD_1,  "ucPassWord_1","2"},
    {eSU_UCPASSWORD_2,  "ucPassWord_2","3"},
    {eSU_UCPASSWORD_3,  "ucPassWord_3","4"},
    {eSU_UCPASSWORD_4,  "ucPassWord_4","5"},
    {eSU_OPFU_CHECK,    "ucOPFU_Check","0"},
    {eSU_UICHECKSUM,    "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sStartup_Default, sizeof(m_sStartup_Default[0])*eSU_NUMBER);


sPARA_FORMAT m_sSystemHours_Default[] =
{
    {eSH_ULTOTALPROJECTORMINUTE,    "ulTotalProjectorMinute",    "0"},
    {eSH_ULLIGHTSOURCEMINUTE_B,     "ulLightSourceMinute_B",     "0"},
    {eSH_ULLIGHTSOURCEMINUTE_R,     "ulLightSourceMinute_R",     "0"},
    {eSH_ULLIGHTSOURCEMINUTENORMAL, "ulLightSourceMinuteNormal", "0"},
    {eSH_ULLIGHTSOURCEMINUTEECO,    "ulLightSourceMinuteEco",    "0"},
    {eSH_ULLIGHTSOURCEMINUTEQUIET,  "ulLightSourceMinuteQuiet",  "0"},
    {eSH_ULLIGHTSOURCEMINUTECUSTOM, "ulLightSourceMinuteCustom", "0"},

    {eSH_UICHECKSUM,                "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sSystemHours_Default, sizeof(m_sSystemHours_Default[0])*eSH_NUMBER);


sPARA_FORMAT m_sCommonGui_Default[] =
{
    {eCG_UCLENSTYPE,    "ucLensType","0"},
    {eCG_ULDBMASK,      "ulDbMask","0"},
    {eCG_UCPANEL,       "ucPanel","11"},
    {eCG_UCPOWERMODE,   "ucPowerMode","0"},
    {eCG_UCWAVEFORMGAIN,        "ucWaveformGain","0"},
    {eCG_UCIRWAVEFORMGAIN,      "ucIRWaveformGain","0"},
    {eCG_UCIRMODE_WAVEFORMGAIN, "ucIRMode_WaveformGain","0"},
    {eCG_UCIRMODE_IRWAVEFORMGAIN,   "ucIRMode_IRWaveformGain","0"},
    {eCG_UCIRLD,                    "ucIRLD","0"},
    {eCG_UCIRBLD,                   "ucIRBLD","0"},
    {eCG_UCLIGHTCALIBRATIONMODE,    "ucLightCalibrationMode","0"},
    {eCG_UCMENULOCATION,    "ucMenuLocation","2"},
    {eCG_UCOSDTRANSLUCENCY, "ucOSDTranslucency","50"},
    {eCG_UCOSDTIMEOUT,      "ucOSDTimeout","1"},
    {eCG_UCSHOWMESSAGES,    "ucShowMessages","1"},
    {eCG_UCMENUOFFSETX,     "ucMenuOffsetX","0"},
    {eCG_UCMENUOFFSETY,     "ucMenuOffsetY","0"},
    {eCG_UCMENULOCKOUT,     "ucMenuLockout","0"},
    {eCG_UCMENUTRANSPARENCY,    "ucMenuTransparency","0"},
    {eCG_UCSEARCHSCREEN,        "ucSearchScreen","0"},
    {eCG_UCSHOWNETWORKMESSAGES, "ucShowNetworkMessages","1"},
    {eCG_UCDHCP,                "ucDHCP","0"},
    {eCG_UCHSGADJUSTMENTENABLE, "ucHSGAdjustmentEnable","0"},
    {eCG_UCHSGADJUSTMENTAUTOTESTPATTERN,    "ucHSGAdjustmentAutoTestPattern","1"},
    {eCG_UCBLANKONSIGNALSWITCH, "ucBlankonSignalSwitch","1"},
    {eCG_UCSYNCTHRESHOLD,       "ucSyncThreshold","10"},
    {eCG_UCCONTRASTENHANCEMENT, "ucContrastEnhancement","0"},
    {eCG_UI3DFRAME_DELAY_TIMING_0,  "ui3DFRAME_DELAY_TIMING_0","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_1,  "ui3DFRAME_DELAY_TIMING_1","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_2,  "ui3DFRAME_DELAY_TIMING_2","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_3,  "ui3DFRAME_DELAY_TIMING_3","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_4,  "ui3DFRAME_DELAY_TIMING_4","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_5,  "ui3DFRAME_DELAY_TIMING_5","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_6,  "ui3DFRAME_DELAY_TIMING_6","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_7,  "ui3DFRAME_DELAY_TIMING_7","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_8,  "ui3DFRAME_DELAY_TIMING_8","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_9,  "ui3DFRAME_DELAY_TIMING_9","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_10, "ui3DFRAME_DELAY_TIMING_10","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_11, "ui3DFRAME_DELAY_TIMING_11","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_12, "ui3DFRAME_DELAY_TIMING_12","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_13, "ui3DFRAME_DELAY_TIMING_13","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_14, "ui3DFRAME_DELAY_TIMING_14","1"},
    {eCG_UI3DFRAME_DELAY_TIMING_15, "ui3DFRAME_DELAY_TIMING_15","1"},
    {eCG_UCFILM,                "ucFilm","0"},
    {eCG_UCWALLCOLOR,           "ucWallColor","0"},
    {eCG_UCIMAGEFREEZE,         "ucImageFreeze","0"},
    {eCG_UCCEILINGMOUNT,        "ucCeilingMount","2"},
    {eCG_UCREARPROJECT,         "ucRearProject","0"},
    {eCG_UCLIGHTSOUTTIMER,      "ucLightsOutTimer","0"},
    {eCG_UCLIGHTSOUTSIGNALLEVEL,"ucLightsOutSignalLevel","78"},
    {eCG_UCLIGHTS_ON_THRESHOLD, "ucLights_On_Threshold","28"},  //A70LK_Simon_0002
    {eCG_UCCOMPATIBLE_4K,       "ucCompatible_4K","1"},
    {eCG_UCHDMI_EDID_1,         "ucHDMI_EDID_1","1"},
    {eCG_UCHDMI_EDID_2,         "ucHDMI_EDID_2","1"},
    {eCG_UCHDRENABLE,           "ucHDREnable","1"},
    {eCG_UCHDRLEVEL,            "ucHDRLevel","0"},
    {eCG_UCCW_SPEED,            "ucCW_Speed","1"},
    {eCG_UCDBSPEED,             "ucDBSpeed","1"},
    {eCG_UCDBSTRENGTH,          "ucDBStrength","2"},
    {eCG_UCDBLIGHTLEVEL,        "ucDBLightLevel","100"},
    {eCG_UCDBREALBLACKENABLE,   "ucDBRealBlackEnable","0"},
    {eCG_UCLANGUAGE,            "ucLanguage","0"},
    {eCG_UCACPOWERON,           "ucACPowerOn","0"},
    {eCG_UCSTANDBYPOWERSAVE,    "ucStandbyPowerSave","2"},
    {eCG_UCPROJECTORADDRESS,    "ucProjectorAddress","0"},
    {eCG_UCPROJECTORID,         "ucProjectorID","0"},
    {eCG_UCKEYPADBACKLIGHT,     "ucKeypadBacklight","0"},
    {eCG_UCSTATUSLED,           "ucStatusLED","0"},
    {eCG_UCAUTOOFFTIME,         "ucAutoOffTime","0"},
    {eCG_UCSCREENSAVETIME,      "ucScreenSaveTime","0"},
    {eCG_UCSLEEPTIMER,          "ucSleepTimer","0"},
    {eCG_UCCHANGEPIN,           "ucChangePIN","8"},
    {eCG_UCSERIALPORTBAUDRATE,  "ucSerialPortBaudRate","8"},
    {eCG_UCSERIALPORTECHO,      "ucSerialPortEcho","0"},
    {eCG_UCSERIALPORTPATH,      "ucSerialPortPath","0"},
    {eCG_UCIRCONTROL_TOP,       "ucIRControl_Top","1"},
    {eCG_UCIRCONTROL_FRONT,     "ucIRControl_Front","1"},
    {eCG_UCIRCONTROL_HDBASET,   "ucIRControl_HDBaseT","1"},
    {eCG_UCHDBASETENABLE,       "ucHDBaseTEnable","1"},
    {eCG_UCSYSERRCODE,          "ucSysErrCode","0"},
    {eCG_UC12VTRIGGE,           "uc12VTrigge","0"},
    {eCG_UCLENSADJUST,          "ucLensAdjust","0"},
    {eCG_UCLENSSHIFT,           "ucLensShift","0"},
    {eCG_UCLENSMEMORYAPPLY,     "ucLensMemoryApply","0"},
    {eCG_UCLENSMEMORYSAVE,      "ucLensMemorySave","0"},
    {eCG_UCHIGHALTITUDE,        "ucHighAltitude","0"},
    {eCG_UCFACTORYTESTPATTERN,          "ucFactoryTestPattern","0"},
    {eCG_UCSERVICEMENUTESTPATTERN,      "ucServiceMenuTestPattern","0"},
    {eCG_UCFACTORYMENUCUSTOMPATTERN,    "ucFactoryMenuCustomPattern","0"},
    {eCG_UCSPLASHSTARTUPENABLE, "ucSplashStartupEnable","3"},
    {eCG_UCACTUATORSWITCH,      "ucActuatorSwitch","1"},
    {eCG_UCCOOLINGDOWN,         "ucCoolingDown","0"},
    {eCG_UCOSDTESTPATTERN,      "ucOSDTestPattern","0"},
    {eCG_UCUARTSWITCH,          "ucUartSwitch","0"},
    {eCG_UCBACKUPRESTORESAVE,   "ucBackupRestoreSave","0"},
    {eCG_UCBACKUPRESTORERESTORE,"ucBackupRestoreRestore","0"},
    {eCG_UCLENSDETECTION,       "ucLensDetection","1"},
    {eCG_UCLOWLATENCY,          "ucLowLatency","0"},
    {eCG_BACKUP_INPUT_SWITCH,   "ucBackupIputSwitch","0"},
    {eCG_BACKUP_PRIMARY_INPUT,  "ucBackupPrimaryInput","0"},
    {eCG_BACKUP_SECONDARY_INPUT,    "ucBackupSecondaryInput","1"}, //G100_Steven_0028
    {eCG_UCINPUTSOURCEMAIN,     "ucInputSourceMain","3"},
    {eCG_UCINPUTSOURCESUB,      "ucInputSourceSub","5"},
    {eCG_UCPIPENABLE,           "ucPIPEnable","0"},
    {eCG_UCMAINLAYOUT,           "ucMainLayout","0"},
    {eCG_UCPIPLAYOUT,           "ucPIPLayout","4"},
    {eCG_UCPBPLAYOUT,           "ucPBPLayout","0"},
    {eCG_UCPIPSIZE,             "ucPIPSize","2"},
    {eCG_UCSOURCEKEYOPTION,     "ucSourceKeyOption","1"},
    {eCG_UISOURCEINFO,          "uiSourceInfo","0"},
    {eCG_UCPOWERUPSOURCE,       "ucPowerUpSource","0"},
    {eCG_UCSOURCELOCK,          "ucSourceLock","0"},
    {eCG_UCCUSTOMKEY,           "ucCustomKey","0"},
    {eCG_UCBLANKKEY,            "ucBlankKey","0"},
    {eCG_UCSOURCEHOTKEYENABLE,  "ucSourceHotKeyEnable","1"},
    {eCG_BACKGROUND_COLOR,      "ucBackgroundColor","1"},
    {eCG_SIGNAL_POWERON,        "ucSignalPowerOn","1"},
    {eCG_SECURITY_TOTALREMAINMIN,  "ulSecurity_TotalRemainMin","0"},
    {eCG_UCHDBaseT_EDID,        "ucUCHDBaseT_EDID","0"},  //G100_John_0003 fix EDID version change issue //G100_Steven_0005
    {eCG_STARTUP_SHUTTER,       "ucStartupShutter","0"},    //G100_Owen_0017
    {eCG_AUTO_SOURCE_RESYNC,    "ucAutoSourceResync","0"},	//G100_Doulas_0006
    {eCG_CONSTANT_BRIGHTNESS,   "ucConstantBrightness","0"},	//G100_Doulas_0008
    {eCG_UCSERIALPORTOUT_BAUDRATE,"ucSerialPortOut_BaudRate","7"},    //G100_Owen_0023
    {eCG_UCFADEIN_TIME,         "ucFadeIn_Time","5"},       //G100_Owen_0023
    {eCG_UCFADEOUT_TIME,        "ucFadeOut_Time","5"},      //G100_Owen_0023
    {eCG_UCPWRKEYBACKLIGHT,     "ucPwrKeyBacklight","1"},   //G100_Owen_0024
    {eCG_UCCUSTOMKEY2,          "ucCustomKey2","0"}, //G100_Wilsonj_0053
    {eCG_UCCRESTRON_ENABLE,     "ucCRESTRON_ENABLE","0"},
    {eCG_UCLOGOCHANGE,          "ucLogoChange","0"},        //G100_Owen_0048
    {eCG_UCHDMI_OUT,            "ucHDMI_OUT","0"},			//G100_Doulas_0057
    {eCG_UCFAST_POWER_ON,       "ucFast_Power_On","0"},		//G100_Clare_0055
    {eCG_UCHSGADJUSTMENTAUTOTESTPATTERN_2,  "ucHSGAdjustmentAutoTestPattern_2","1"},	//G100_Coda_00109
    {eCG_UCHSGSELECTED,         "ucHSGSelected","0"},
    {eCG_UCEQMODE_HDMI1,        "ucEQ_HDMI1","0"},
    {eCG_UCEQMODE_HDMI2,        "ucEQ_HDMI2","0"},
    {eCG_UCEQMODE_DVI,          "ucEQ_DVI","0"},
    {eCG_AUTO_HDMI_SWITCH,      "ucAuto_HDMI_Switch","0"},      // Off          //G100_Tim_0057, add, start //A35G2_BRC_Casper_0060
    {eCG_INPUT_KEY_LAST_VALUE,  "ucInput_Key_Last_Value","1"},  // Auto Src On  //G100_Tim_0060, mod, 0 //A35G2_BRC_Casper_0060
    {eCG_3D_MODE_LAST_VALUE,    "uc3D_Mode_Last_Value","1"},    // 3D On        //G100_Tim_0060, mod, 0//G100_Tim_0057, add, end //A35G2_BRC_Casper_0060
    {eCG_PROJ_NATIVE_TIMING,    "ucProj_Native_Timing","0"},    // WU           //G100_Tim_0058, add //A35G2_BRC_Casper_0060
	{eCG_ACU_DATA_ENABLE,		"ucACU_Data_Enable", "0"},	//A35G2_Alan_0007
    {eCG_UI3DSYNC_DELAY_TIMING_0,   "ui3DSYNC_DELAY_TIMING_0","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_1,   "ui3DSYNC_DELAY_TIMING_1","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_2,   "ui3DSYNC_DELAY_TIMING_2","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_3,   "ui3DSYNC_DELAY_TIMING_3","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_4,   "ui3DSYNC_DELAY_TIMING_4","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_5,   "ui3DSYNC_DELAY_TIMING_5","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_6,   "ui3DSYNC_DELAY_TIMING_6","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_7,   "ui3DSYNC_DELAY_TIMING_7","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_8,   "ui3DSYNC_DELAY_TIMING_8","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_9,   "ui3DSYNC_DELAY_TIMING_9","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_10,  "ui3DSYNC_DELAY_TIMING_10","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_11,  "ui3DSYNC_DELAY_TIMING_11","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_12,  "ui3DSYNC_DELAY_TIMING_12","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_13,  "ui3DSYNC_DELAY_TIMING_13","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_14,  "ui3DSYNC_DELAY_TIMING_14","1"},
    {eCG_UI3DSYNC_DELAY_TIMING_15,  "ui3DSYNC_DELAY_TIMING_15","1"},

    {eCG_UCAUDIO_VOLUME,            "ucAudioVoluem","10"},// R70K_Bruce_0002
    {eCG_UCAUDIO_MUTE,              "ucAudioMute","0"},// R70K_Bruce_0002
    {eCG_UCDBSPEED_CONTROL,         "ucDBSpeedControl","0"},

    {eCG_UCLENSPEED,                "ucLens_Speed","0"},

    {eCG_CUSTOMEDID_HDMI1_STATUS,    "ucCustomEDID_HDMI1_Status","0"}, //A35G2_Simon_0091
    {eCG_CUSTOMEDID_HDMI2_STATUS,    "ucCustomEDID_HDMI2_Status","0"}, //A35G2_Simon_0091

    {eCG_UICHECKSUM,                "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sCommonGui_Default, sizeof(m_sCommonGui_Default[0])*eCG_NUMBER);


sPARA_FORMAT m_sWarping_Default[] =
{
    {eWI_UCWARPMODE,                "ucWarpMode","0"},
    {eWI_UCWARPHORZKEYSTONE,        "ucWarpHorzKeystone","20"},
    {eWI_UCWARPVERTKEYSTONE,        "ucWarpVertKeystone","20"},
    {eWI_UCWARPHORZPINCUSHION,      "ucWarpHorzPincushion","50"},
    {eWI_UCWARPVERTPINCUSHION,      "ucWarpVertPincushion","50"},
    {eWI_UCWARPPINCUSHIONBARREL,    "ucWarpPincushionBarrel","0"},
    {eWI_UCGEOMETRYPCMODE,          "ucGeometryPCMode","0"},
    {eWI_UI4CORNERTOPLEFTHORZ,      "ui4CornerTopLeftHorz","0"},
    {eWI_UI4CORNERTOPLEFTVERT,      "ui4CornerTopLeftVert","0"},
    {eWI_UI4CORNERTOPRIGHTHORZ,     "ui4CornerTopRightHorz","0"},
    {eWI_UI4CORNERTOPRIGHTVERT,     "ui4CornerTopRightVert","0"},
    {eWI_UI4CORNERBOTTOMLEFTHORZ,   "ui4CornerBottomLeftHorz","0"},
    {eWI_UI4CORNERBOTTOMLEFTVERT,   "ui4CornerBottomLeftVert","0"},
    {eWI_UI4CORNERBOTTOMRIGHTHORZ,  "ui4CornerBottomRightHorz","0"},
    {eWI_UI4CORNERBOTTOMRIGHTVERT,  "ui4CornerBottomRightVert","0"},
    {eWI_UCWARPAUTOFILTER,  "ucWarpAutoFilter","1"},
    {eWI_UCWARPFILTERH,     "ucWarpFilterH","7"},   //A35G2_Simon_0115
    {eWI_UCWARPFILTERV,     "ucWarpFilterV","7"},   //A35G2_Simon_0115
    {eWI_UCMOVEPITCHMODE,   "ucMovePitchMode","0"},
    {eWI_UCBLENDINGTOPENABLE,   "ucBlendingTopEnable","0"},
    {eWI_UIBLENDINGTOPSTARTPIXEL,   "uiBlendingTopStartPixel","0"},
    {eWI_UIBLENDINGTOPPIXELWIDTH,   "uiBlendingTopPixelWidth","5"},
    {eWI_UCBLENDINGBOTTOMENABLE,    "ucBlendingBottomEnable","0"},
    {eWI_UIBLENDINGBOTTOMSTARTPIXEL,"uiBlendingBottomStartPixel","0"},
    {eWI_UIBLENDINGBOTTOMPIXELWIDTH,"uiBlendingBottomPixelWidth","5"},
    {eWI_UCBLENDINGLEFTENABLE,      "ucBlendingLeftEnable","0"},
    {eWI_UIBLENDINGLEFTSTARTPIXEL,  "uiBlendingLeftStartPixel","0"},
    {eWI_UIBLENDINGLEFTPIXELWIDTH,  "uiBlendingLeftPixelWidth","5"},
    {eWI_UCBLENDINGRIGHTENABLE,     "ucBlendingRightEnable","0"},
    {eWI_UIBLENDINGRIGHTSTARTPIXEL, "uiBlendingRightStartPixel","0"},
    {eWI_UIBLENDINGRIGHTPIXELWIDTH, "uiBlendingRightPixelWidth","5"},
    {eWI_UCAUTOADJUSTMENTMODE,  "ucAutoAdjustmentMode","1"},
    {eWI_UCWARPINGAPPLYSETTING, "ucWarpingApplySetting","0"},
    {eWI_UCWARPINGSAVESETTING,  "ucWarpingSaveSetting","0"},
    {eWI_UCWARPINGLASTSAVED,    "ucWarpingLastSaved","0"},  //A35G2_CDS_Simon_0008
    {eWI_UCBLENDAPPLYSETTING,   "ucBlendApplySetting","0"},
    {eWI_UCBLENDSAVESETTING,    "ucBlendSaveSetting","0"},
    {eWI_UCBLENDLASTSAVED,      "ucBlendLastSaved","0"},  //A35G2_CDS_Simon_0008
    {eWI_UCBLENDINGGAMMA,   "ucBlendingGamma","4"},  //2.2
    {eWI_UCWARPINGAPPLY_0,  "ucWarpingApply_0","0"},
    {eWI_UCWARPINGNAME_0,   "ucWarpingName_0","Record 1"},
    {eWI_UCBLENDAPPLY_0,    "ucBlendApply_0","0"},
    {eWI_UCBLENDINGNAME_0,  "ucBlendingName_0","Record 1"},
    {eWI_UCWARPINGAPPLY_1,  "ucWarpingApply_1","0"},
    {eWI_UCWARPINGNAME_1,   "ucWarpingName_1","Record 2"},
    {eWI_UCBLENDAPPLY_1,    "ucBlendApply_1","0"},
    {eWI_UCBLENDINGNAME_1,  "ucBlendingName_1","Record 2"},
    {eWI_UCWARPINGAPPLY_2,  "ucWarpingApply_2","0"},
    {eWI_UCWARPINGNAME_2,   "ucWarpingName_2","Record 3"},
    {eWI_UCBLENDAPPLY_2,    "ucBlendApply_2","0"},
    {eWI_UCBLENDINGNAME_2,  "ucBlendingName_2","Record 3"},
    {eWI_UCWARPINGAPPLY_3,  "ucWarpingApply_3","0"},
    {eWI_UCWARPINGNAME_3,   "ucWarpingName_3","Record 4"},
    {eWI_UCBLENDAPPLY_3,    "ucBlendApply_3","0"},
    {eWI_UCBLENDINGNAME_3,  "ucBlendingName_3","Record 4"},
    {eWI_UCWARPINGAPPLY_4,  "ucWarpingApply_4","0"},
    {eWI_UCWARPINGNAME_4,   "ucWarpingName_4","Record 5"},
    {eWI_UCBLENDAPPLY_4,    "ucBlendApply_4","0"},
    {eWI_UCBLENDINGNAME_4,  "ucBlendingName_4","Record 5"},
	{eWI_UCADV_WARP_CONTROL,				"ucADVWarpControl","0"},	//G100_Doulas_0027 Add
	{eWI_UCADV_WARP_GRIDPOINTS,				"ucADVWarpGridPoints","0"},
	{eWI_UCADV_WARP_INNER,					"ucADVWarpInner","1"},			//G100_Doulas_0067
	{eWI_UCADV_WARP_SHARPNESS,				"ucADVWarpSharpness","9"},
	{eWI_UCADV_WARP_GRIDCOLOR,				"ucADVWarpGridColor","0"},
	{eWI_UCADV_WARP_GRIDBACKGROUND,			"ucADVWarpGridBackground","0"},
	{eWI_UCADV_BLEND_OVERLAP_GRIDNUMBER,	"ucADVBlendOverlapGridNumber","0"},
	{eWI_UCADV_BLEND_GAMMA,					"ucADVBlendGamma","4"},
	{eWI_UIADV_BLEND_LEFT,					"ucADVBlendLeft","0"},
	{eWI_UIADV_BLEND_RIGHT,					"ucADVBlendRight","0"},
	{eWI_UIADV_BLEND_TOP,					"ucADVBlendTop","0"},
	{eWI_UIADV_BLEND_BOTTOM,				"ucADVBlendBottom","0"},
    {eWI_UCADV_WARP_INNER_LAST_VALUE,       "ucADVWarpInner_LastValue","0"},    //G100_Tim_0055, add//A35G2_BRC_Casper_0051
	{eWI_UCADV_BLACK_LEVEL_AREA,			"ucADVBlackLevelArea","0"},			//A65_OPTOMA_Doulas_0020
	{eWI_UCADV_BLACK_LEVEL_ENABLE_TOP,		"ucADVBlackLevelEbableTop","0"},
	{eWI_UCADV_BLACK_LEVEL_ENABLE_BOTTOM,	"ucADVBlackLevelEbableBottom","0"},
	{eWI_UCADV_BLACK_LEVEL_RED_TOP,			"ucADVBlackLevelRedTop","20"},
	{eWI_UCADV_BLACK_LEVEL_RED_BOTTOM,		"ucADVBlackLevelRedBottom","20"},
	{eWI_UCADV_BLACK_LEVEL_GREEN_TOP,		"ucADVBlackLevelGreenTop","20"},
	{eWI_UCADV_BLACK_LEVEL_GREEN_BOTTOM,	"ucADVBlackLevelGreenBottom","20"},
	{eWI_UCADV_BLACK_LEVEL_BLUE_TOP,		"ucADVBlackLevelBlueTop","20"},
	{eWI_UCADV_BLACK_LEVEL_BLUE_BOTTOM,		"ucADVBlackLevelBlueBottom","20"},
    {eWI_UCGEOMETRYENABLE,                  "ucGeometryEnable","1"},
    {eWI_UICHECKSUM,        "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sWarping_Default, sizeof(m_sWarping_Default[0])*eWI_NUMBER);


sPARA_FORMAT m_sAutoBrightness_Default[] =
{
    {eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_Y,   "uiLightSensorFull_Dynamic_RLD_Y","0"},
    {eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_R,   "uiLightSensorFull_Dynamic_RLD_R","0"},
    {eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_B,   "uiLightSensorFull_Dynamic_RLD_B","0"},
    {eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_G,   "uiLightSensorFull_Dynamic_RLD_G","0"},
    {eAB_UILIGHTSENSORECO_DYNAMIC_RLD_Y,    "uiLightSensorEco_Dynamic_RLD_Y","0"},
    {eAB_UILIGHTSENSORECO_DYNAMIC_RLD_R,    "uiLightSensorEco_Dynamic_RLD_R","0"},
    {eAB_UILIGHTSENSORECO_DYNAMIC_RLD_B,    "uiLightSensorEco_Dynamic_RLD_B","0"},
    {eAB_UILIGHTSENSORECO_DYNAMIC_RLD_G,    "uiLightSensorEco_Dynamic_RLD_G","0"},
    {eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_Y,     "uiLightFull_PWM_Dynamic_RLD_Y","0"},
    {eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_R,     "uiLightFull_PWM_Dynamic_RLD_R","0"},
    {eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_B,     "uiLightFull_PWM_Dynamic_RLD_B","0"},
    {eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_G,     "uiLightFull_PWM_Dynamic_RLD_G","0"},
    {eAB_UILIGHTECO_PWM_DYNAMIC_RLD_Y,      "uiLightEco_PWM_Dynamic_RLD_Y","0"},
    {eAB_UILIGHTECO_PWM_DYNAMIC_RLD_R,      "uiLightEco_PWM_Dynamic_RLD_R","0"},
    {eAB_UILIGHTECO_PWM_DYNAMIC_RLD_B,      "uiLightEco_PWM_Dynamic_RLD_B","0"},
    {eAB_UILIGHTECO_PWM_DYNAMIC_RLD_G,      "uiLightEco_PWM_Dynamic_RLD_G","0"},
    {eAB_UIINTENSITYPWM_BLD_Y,              "uiIntensityPWM_BLD_Y","0"},
    {eAB_UIINTENSITYPWM_BLD_R,              "uiIntensityPWM_BLD_R","0"},
    {eAB_UIINTENSITYPWM_BLD_B,              "uiIntensityPWM_BLD_B","0"},
    {eAB_UIINTENSITYPWM_BLD_G,              "uiIntensityPWM_BLD_G","0"},
    {eAB_UIINTENSITYPWM_RLD_Y,              "uiIntensityPWM_RLD_Y","0"},
    {eAB_UIINTENSITYPWM_RLD_R,              "uiIntensityPWM_RLD_R","0"},
    {eAB_UIINTENSITYPWM_RLD_B,              "uiIntensityPWM_RLD_B","0"},
    {eAB_UIINTENSITYPWM_RLD_G,              "uiIntensityPWM_RLD_G","0"},
    {eAB_UILIGHTSENSORINTENSITY_BLD_Y,      "uiLightSensorIntensity_BLD_Y","0"},
    {eAB_UILIGHTSENSORINTENSITY_BLD_R,      "uiLightSensorIntensity_BLD_R","0"},
    {eAB_UILIGHTSENSORINTENSITY_BLD_B,      "uiLightSensorIntensity_BLD_B","0"},
    {eAB_UILIGHTSENSORINTENSITY_BLD_G,      "uiLightSensorIntensity_BLD_G","0"},
    {eAB_UILIGHTSENSORINTENSITY_RLD_Y,      "uiLightSensorIntensity_RLD_Y","0"},
    {eAB_UILIGHTSENSORINTENSITY_RLD_R,      "uiLightSensorIntensity_RLD_R","0"},
    {eAB_UILIGHTSENSORINTENSITY_RLD_B,      "uiLightSensorIntensity_RLD_B","0"},
    {eAB_UILIGHTSENSORINTENSITY_RLD_G,      "uiLightSensorIntensity_RLD_G","0"},
    {eAB_UICHECKSUM,    "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sAutoBrightness_Default, sizeof(m_sAutoBrightness_Default[0])*eAB_NUMBER);


sPARA_FORMAT m_sCommon_InputSource_Default[] =
{
    {eSCM_CSOURCENAME,              "cSourceName","NA"},
    {eSCM_UCASPECTRATIO,            "ucAspectRatio","0"},
    {eSCM_UCASPECTRATIO219,         "ucAspectRatio219","0"},// x35G2_Bruce_0004
    {eSCM_UCOVERSCAN,               "ucOverScan","0"},
    {eSCM_UCPHASE,                  "ucPhase","50"},
    {eSCM_UCTRACKING,               "ucTracking","50"},
    {eSCM_UCHORZPOSITION,           "ucHorzPosition","50"},
    {eSCM_UCVERTPOSITION,           "ucVertPosition","50"},
    {eSCM_UIDIGITALHORZZOOM,        "uiDigitalHorzZoom","100"},
    {eSCM_UIDIGITALVERTZOOM,        "uiDigitalVertZoom","100"},
    {eSCM_UIDIGITALHORZSHIFT,       "uiDigitalHorzShift","50"},
    {eSCM_UIDIGITALVERTSHIFT,       "uiDigitalVertShift","50"},
    {eSCM_UICUSTOMDIGITALHORZZOOM,  "uiCustomDigitalHorzZoom","100"},
    {eSCM_UICUSTOMDIGITALVERTZOOM,  "uiCustomDigitalVertZoom","100"},
    {eSCM_UICUSTOMDIGITALHORZSHIFT, "uiCustomDigitalHorzShift","50"},
    {eSCM_UICUSTOMDIGITALVERTSHIFT, "uiCustomDigitalVertShift","50"},
    {eSCM_UCPRESETMODE,             "ucPresetMode","1"},
    {eSCM_UCBACKUPPRESET,           "ucBackupPreset","1"},
    {eSCM_UCSAVEPRESET,             "ucSavePreset","0"},
    {eSCM_UCPREUSERMODE,            "ucPreUserMode","1"},
    {eSCM_UC3D_ENABLE,              "uc3D_Enable","0"},
    {eSCM_UC3D_INVERT,              "uc3D_Invert","0"},
    {eSCM_UC3D_SYNCOUT,             "uc3D_SyncOut","0"},
    {eSCM_UC3D_SYNCIN,              "uc3D_SyncIn","0"},
    {eSCM_UC3D_REFERENCE,           "uc3D_Reference","0"},
    {eSCM_UC3D_2D_VIEW,             "uc3D_2D_View","0"},
    {eSCM_UCEDGEMASK,               "ucEdgeMask","0"},
    {eSCM_UC3D_MODE,                "uc3D_Mode","1"},
    {eSCM_UC3D_TECH,                "uc3D_Tech","1"},
    {eSCM_UCAUTOIMAGE,              "ucAutoImage","1"},
    {eSCM_UCDIGITALZOOMPROP,        "ucDigitalZoomProp","1"},
    {eSCM_UICHECKSUM,               "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sCommon_InputSource_Default, sizeof(m_sCommon_InputSource_Default[0])*eSCM_NUMBER);


sPARA_FORMAT m_sHSG_Default[] =
{
    {eHSG_R_HUE,        "HSG_R_HUE","127"},
    {eHSG_R_SAT,        "HSG_R_SAT","127"},
    {eHSG_R_GAIN,       "HSG_R_GAIN","127"},
    {eHSG_G_HUE,        "HSG_G_HUE","127"},
    {eHSG_G_SAT,        "HSG_G_SAT","127"},
    {eHSG_G_GAIN,       "HSG_G_GAIN","127"},
    {eHSG_B_HUE,        "HSG_B_HUE","127"},
    {eHSG_B_SAT,        "HSG_B_SATS","127"},
    {eHSG_B_GAIN,       "HSG_B_GAIN","127"},
    {eHSG_C_HUE,        "HSG_C_HUE","127"},
    {eHSG_C_SAT,        "HSG_C_SAT","127"},
    {eHSG_C_GAIN,       "HSG_C_GAIN","127"},
    {eHSG_M_HUE,        "HSG_M_HUE","127"},
    {eHSG_M_SAT,        "HSG_M_SAT","127"},
    {eHSG_M_GAIN,       "HSG_M_GAIN","127"},
    {eHSG_Y_HUE,        "HSG_Y_HUE","127"},
    {eHSG_Y_SAT,        "HSG_Y_SAT","127"},
    {eHSG_Y_GAIN,       "HSG_Y_GAIN","127"},
    {eHSG_W_R_GAIN,     "HSG_W_R_GAIN","127"},
    {eHSG_W_G_GAIN,     "HSG_W_G_GAIN","127"},
    {eHSG_W_B_GAIN,     "HSG_W_B_GAIN","127"},
    {eHSG_UICHECKSUM,   "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sHSG_Default, sizeof(m_sHSG_Default[0])*eHSG_NUMBER);


sPARA_FORMAT m_sWAP_Tag_Default[] =
{
    {eWAP_CALIBRATION_TAG,     "WAP_CALIBRATION_TAG","0"},
	{eWAP_CRC,                 "WAP_CRC","0"},


    {eWAP_TAG_UICHECKSUM,          "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sWAP_Tag_Default, sizeof(m_sWAP_Tag_Default[0])*eWAP_TAG_NUMBERS);

//G100_Steven_0084
sPARA_FORMAT m_sTEC_GATING_Default[] =
{
	{eTEC_GATING_CNT,      "ucTEC_GATING_Cnt","0"},
	{eTEC_GATING_CYCLE0,   "ucTEC_GATING_CYCLE0","0"},
	{eTEC_GATING_CYCLE1,   "ucTEC_GATING_CYCLE1","0"},
	{eTEC_GATING_CYCLE2,   "ucTEC_GATING_CYCLE2","0"},
	{eTEC_GATING_CYCLE3,   "ucTEC_GATING_CYCLE3","0"},
	{eTEC_GATING_CYCLE4,   "ucTEC_GATING_CYCLE4","0"},
	{eTEC_GATING_CYCLE5,   "ucTEC_GATING_CYCLE5","0"},
	{eTEC_GATING_CYCLE6,   "ucTEC_GATING_CYCLE6","0"},
	{eTEC_GATING_CYCLE7,   "ucTEC_GATING_CYCLE7","0"},
	{eTEC_GATING_CYCLE8,   "ucTEC_GATING_CYCLE8","0"},
	{eTEC_GATING_CYCLE9,   "ucTEC_GATING_CYCLE9","0"},
	{eTEC_GATING_UICHECKSUM,          "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sTEC_GATING_Default, sizeof(m_sTEC_GATING_Default[0])*eTEC_GATING_NUMBERS);

sPARA_FORMAT m_sWAP_Ratio_Default[] =
{
    {eWAP_LD_SEG_BLD_R,        "WAP_RATIO_BR","100"},
	{eWAP_LD_SEG_BLD_G,        "WAP_RATIO_BG","100"},
	{eWAP_LD_SEG_BLD_B,        "WAP_RATIO_BB","100"},
	{eWAP_LD_SEG_BLD_Y,        "WAP_RATIO_BY","100"},
	{eWAP_LD_SEG_RLD_R,        "WAP_RATIO_RR","100"},
	{eWAP_LD_SEG_RLD_Y,        "WAP_RATIO_RY","100"},

    {eWAP_UICHECKSUM,   "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sWAP_Ratio_Default, sizeof(m_sWAP_Ratio_Default[0])*eWAP_LD_SEG_NUMBERS);


sPARA_FORMAT m_sWAP_Offset_Default[] =
{
    {eWAP_LD_SEG_BLD_R,        "WAP_OFFSET_BR","0"},
	{eWAP_LD_SEG_BLD_G,        "WAP_OFFSET_BG","0"},
	{eWAP_LD_SEG_BLD_B,        "WAP_OFFSET_BB","0"},
	{eWAP_LD_SEG_BLD_Y,        "WAP_OFFSET_BY","0"},
	{eWAP_LD_SEG_RLD_R,        "WAP_OFFSET_RR","0"},
	{eWAP_LD_SEG_RLD_Y,        "WAP_OFFSET_RY","0"},

    {eWAP_UICHECKSUM,   "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sWAP_Offset_Default, sizeof(m_sWAP_Offset_Default[0])*eWAP_LD_SEG_NUMBERS);


sPARA_FORMAT m_sWAP_PWM_Default[] =
{
    {eWAP_LD_SEG_BLD_R,        "WAP_PWM_BR","0"},
	{eWAP_LD_SEG_BLD_G,        "WAP_PWM_BG","0"},
	{eWAP_LD_SEG_BLD_B,        "WAP_PWM_BB","0"},
	{eWAP_LD_SEG_BLD_Y,        "WAP_PWM_BY","0"},
	{eWAP_LD_SEG_RLD_R,        "WAP_PWM_RR","0"},
	{eWAP_LD_SEG_RLD_Y,        "WAP_PWM_RY","0"},

    {eWAP_UICHECKSUM,   "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sWAP_PWM_Default, sizeof(m_sWAP_PWM_Default[0])*eWAP_LD_SEG_NUMBERS);

sPARA_FORMAT m_sColor_Default[] =
{
    {eSCR_UCCS,                     "ucCS","0"},
    {eSCR_UCCT,                     "ucCT","1"},
    {eSCR_UCGAMMA,                  "ucGamma","2"},  //gamma bright
    {eSCR_UCBRILLIENTCOLORENABLE,   "ucBrillientColorEnabled","1"},
    {eSCR_UCWHITEPEAKING,           "ucWhitePeaking","10"},
    {eSCR_UCCOLORENHANCEMENT,       "ucColorEnhancement","1"},
    {eSCR_UCSKINCOLOR,              "ucSkinColor","0"},
    {eSCR_UCSHARPNESS,              "ucSharpness","8"},
    {eSCR_UCBRIGHTNESS,             "ucBrightness","50"},
    {eSCR_UCCONTRAST,               "ucContrast","50"},
    {eSCR_UCTINT,                   "ucTint","50"},
    {eSCR_UCSATURATION,             "ucSaturation","50"},
    {eSCR_UCREDGAIN,                "ucRedGain","50"},
    {eSCR_UCGREENGAIN,              "ucGreenGain","50"},
    {eSCR_UCBLUEGAIN,               "ucBlueGain","50"},
    {eSCR_UCREDOFFSET,              "ucRedOffset","50"},
    {eSCR_UCGREENOFFSET,            "ucGreenOffset","50"},
    {eSCR_UCBLUEOFFSET,             "ucBlueOffset","50"},
	{eSCR_UCWALLCOLORSET,           "ucWallColorSet","0"},   //G100_Steven_0047
    {eSCR_UICHECKSUM,               "uiCheckSum","0"}
};
VERIFY_SIZE_OF(m_sColor_Default, sizeof(m_sColor_Default[0])*eSCR_NUMBER);


sPARA_FORMAT m_sLan_Default[] =
{
    {eLII_DHCP,             "Dhcp",        "0"},
    {eLII_DHCP,             "Port",        "0"}, //A35G2_CDS_Larry_0028
    {eLII_IPADDR,           "IpAddr",      "0.0.0.0"},
    {eLII_SUBMASK,          "SubMask",     "0.0.0.0"},
    {eLII_GATEWAY,          "Gateway",     "0.0.0.0"},
    {eLII_PRIMARYDNS,       "PrimaryDns",  "0.0.0.0"},
    {eLII_SECONDDNS,        "SecondDns",   "0.0.0.0"},
    {eLII_MAC,              "Mac",         "00:00:00:00:00:00\0"},
    {eLII_WIFI,             "Wifi",        "1"},
    {eLII_WIFISSID,         "WifiSSID",    "Coretronic@123456\0"},
    {eLII_PASSWORD,         "Password",    "12345678"},
    {eLII_STARTIPADDR,      "StartIpAddr", "0.0.0.0"},
    {eLII_ENDIPADDR,        "EndIpAddr",   "0.0.0.0"},
    {eLII_WIFISUBMASK,      "WifiSubMask", "0.0.0.0"},
    {eLII_WIFIGATEWAY,      "WifiGateway", "0.0.0.0"},
    {eLII_CRESTRON,         "Crestron",        "0"},  //G100_Wilsonj_0055
    {eLII_CRESTRONIPADDR,   "CrestronIpAddr",  "0.0.0.0"},
    {eLII_CRESTRONIPID,     "CrestronIpId",    "0.0.0.0"},
    {eLII_CRESTRONPORT,     "CrestronPort",    "0.0.0.0"},
    {eLII_SERVICE,          "Service",     "0.0.0.0"},
    {eLII_MODE,             "Mode",        "Ntp"},
    {eLII_TIMEZONE,         "Timezone",    "-0"},
    {eLII_INTERVAL,         "Interval",    "Hourly"},
    {eLII_NTP,              "Ntp",         "time1.google.com"},
    {eLII_LOCALNTP,         "LocalNtp",    "0"},
    {eLII_YEAR,             "Year",        "2018"},
    {eLII_MONTH,            "Month",       "1"},
    {eLII_DAY,              "Day",         "1"},
    {eLII_HOUR,             "Hour",        "0"},
    {eLII_MINUTE,           "Minute",      "0"},
    {eLII_PATH,             "Path",        "0"},
};
VERIFY_SIZE_OF(m_sLan_Default, sizeof(m_sLan_Default[0])*eLII_NUMBER);


sPARA_FORMAT m_sBackupRestoreCheck_Default[] =	//G100_Doulas_0002
{
    {eBR_UCMODEL,       "ucModel","G100"},
    {eBR_UCBACKUP_RESTORE_TYPE,    "ucBackupRestoreType","0"},
};
VERIFY_SIZE_OF(m_sBackupRestoreCheck_Default, sizeof(m_sBackupRestoreCheck_Default[0])*eBR_NUMBER);


sPARA_FORMAT m_sBackupRestoreCheck_Change_Projector[] =	//G100_Doulas_0004
{
    {eBR_UCMODEL,       "ucModel","G100"},
    {eBR_UCBACKUP_RESTORE_TYPE,    "ucBackupRestoreType","1"},
};
VERIFY_SIZE_OF(m_sBackupRestoreCheck_Change_Projector, sizeof(m_sBackupRestoreCheck_Change_Projector[0])*eBR_NUMBER);


sPARA_FORMAT m_sBackupRestoreCheck_Change_Main_Board[] =	//G100_Doulas_0004
{
    {eBR_UCMODEL,       "ucModel","G100"},
    {eBR_UCBACKUP_RESTORE_TYPE,    "ucBackupRestoreType","2"},
};
VERIFY_SIZE_OF(m_sBackupRestoreCheck_Change_Main_Board, sizeof(m_sBackupRestoreCheck_Change_Main_Board[0])*eBR_NUMBER);

sPARA_FORMAT m_sPROSERVICE_Default[] =
{
    {ePROSERVICE_PAIRED_STATUS,  "PROSERVICE_PAIRED_STATUS",  "0"},
    {ePROSERVICE_BINDED_STATUS,  "PROSERVICE_BINDED_STATUS",  "0"},
    {ePROSERVICE_PAIRED_CODE,    "PROSERVICE_PAIRED_CODE",    "0"},
    {ePROSERVICE_PAIRED_ACCOUNT, "PROSERVICE_PAIRED_ACCOUNT", "0"},
    {ePROSERVICE_OSD_LOCK,       "PROSERVICE_OSD_LOCK",       "0"},
    {ePROSERVICE_FOTA_ENABLE,    "PROSERVICE_FOTA_ENABLE",    "1"},

    {ePROSERVICE_UICHECKSUM,     "uiCheckSum",                "0"}
};

#if (ENABLE_COLOR_UNIFORMITY == TRUE)   //G100_Tim_0012, add, start // A35G2_CDS_Coda_0028
sPARA_FORMAT m_sACU_Default[] =
{
    {eACU_FILE_VALID,                   "ACU_FILE_VALID","15"},
    {eACU_DISPLAY_MODE,                 "ACU_DISPLAY_MODE","99"},
    {eACU_TARGET_SELECT,                "ACU_TARGET_SELECT","54"},              //G100_Tim_0048, add, same as ACU_TARGET_DEFAULT
	{eACU_DATA_ENABLE,					"ACU_Data_Enable", "0"},				//A35G2_Alan_0007

    {eACU_UICHECKSUM,                   "uiCheckSum","0"}
};
#endif //ENABLE_COLOR_UNIFORMITY        //G100_Tim_0012, add, end

sPARA_FORMAT m_sActuator_Default[] =
{
    {eACT_DAC_AWC0,            "ucDAC_AWC0",               "150"},
    {eACT_SFDELAY_AWC0,        "ulSubframeDelay_AWC0",     "12000"},
    {eACT_SEGMENTLEN_AWC0,     "uiSegmentLength_AWC0",     "330"},
    {eACT_DAC_AWC1,            "ucDAC_AWC1",               "135"},
    {eACT_SFDELAY_AWC1,        "ulSubframeDelay_AWC1",     "12000"},
    {eACT_SEGMENTLEN_AWC1,     "uiSegmentLength_AWC1",     "344"},

    {eACT_UICHECKSUM,          "uiCheckSum",               "0"}
};
VERIFY_SIZE_OF(m_sActuator_Default, sizeof(m_sActuator_Default[0])*eACT_NUMBERS);

static sPARA_FORMAT m_sProjectorInfo[ePI_NUMBER];
static sPARA_FORMAT m_sSystemCal[eSC_NUMBER];
static sPARA_FORMAT m_sBurnin[eBI_NUMBER];
static sPARA_FORMAT m_sStartup[eSU_NUMBER];
static sPARA_FORMAT m_sSystemHours[eSH_NUMBER];
static sPARA_FORMAT m_sCommonGui[eCG_NUMBER];
static sPARA_FORMAT m_sWarping[eWI_NUMBER];
static sPARA_FORMAT m_sAutoBrightness[eAB_NUMBER];
static sPARA_FORMAT m_sTEC_GATING[eTEC_GATING_NUMBERS];
static sPARA_FORMAT m_sActuator[eACT_NUMBERS];

static sSOURCE_DATA_TABLE m_sSourceData[eGUI_SOURCE_ID_NUMBER];

static sPARA_FORMAT m_sBackup_Restore_Check[eBR_NUMBER];		//G100_Doulas_0002
//G100_Steven_0011 start
static sPARA_FORMAT m_sWAP_Calibration_Tag[eWAP_TAG_NUMBERS];

static sSOURCE_DATA_TABLE m_sSourceData[eGUI_SOURCE_ID_NUMBER];
static sWAP_DATA_TABLE m_sWAP_RatioData[eIFC_WAP_NUMBER];
static sWAP_DATA_TABLE m_sWAP_OffsetData[eIFC_WAP_NUMBER];
static sWAP_DATA_TABLE m_sWAP_PWMData[eIFC_WAP_NUMBER];
static sPARA_FORMAT m_sTEC_GATING[eTEC_GATING_NUMBERS]; //G100_Steven_0084
#if (ENABLE_COLOR_UNIFORMITY == TRUE)   //G100_Tim_0012, add, start  //A35G2_CDS_Coda_0027
static sPARA_FORMAT m_sACU_DATA[eACU_NUMBERS];
#endif //ENABLE_COLOR_UNIFORMITY        //G100_Tim_0012, add, end
static sPARA_FORMAT m_sProService_DATA[ePROSERVICE_NUMBERS]; //A65_Jerry_0005 add

UINT16 utilDataMgr_SourceColorTableGet(eSOURCE_TYPE eType, eGUI_SOURCE_ID eGuiSource, eGUI_PICTURE_SETTINGS_ID ePre)
{
    if((eType < eSOURCE_TYPE_NUMBER) && (eGuiSource < eGUI_SOURCE_ID_NUMBER) && (ePre < eGUI_PICTURE_SETTINGS_NUMBER))
    {
        return m_cSourceTableMtached[eType][eGuiSource][ePre];
    }

    return eDATA_NODE_NUMBER;
}

UINT16 utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE eType,  eGUI_SOURCE_ID eGuiSource, eGUI_PRE_USER_ID ePre)
{
    if((eType < eSOURCE_TYPE_NUMBER) && (eGuiSource < eGUI_SOURCE_ID_NUMBER) && (ePre < eGUI_PRE_USERS_NUMBER))
    {
        return m_cSourceTableUserModeMtached[eType][eGuiSource][ePre];
    }

    return eDATA_NODE_NUMBER;
}

UINT16 utilDataMgr_SourceCommonTablerGet(eGUI_SOURCE_ID eGuiSource)
{
    if(eGuiSource < eGUI_SOURCE_ID_NUMBER)
    {
        return m_cSourceTableCommon[eGuiSource];
    }

    return eDATA_NODE_NUMBER;
}

UINT16 utilDataMgr_WapTableGet(eWAP_PARA ePara, eIFC_WAP_PresetMode eMode)
{
    if((ePara < eWAP_PARA_NUMBERS) && (eMode < eIFC_WAP_NUMBER))
    {
        return m_cWAP_Table[eMode][ePara];
    }

    return eDATA_NODE_NUMBER;
}

#define MNT_CONFIG_SCALER(x) CONF_SCALER_PATH#x

//要留意列舉和struct要匹配
static sDATA_NODE_CTRL m_sDataNodeCtrl[] =
{
    {eDATA_NODE_PROJECTORINFO,          		 MNT_CONFIG_SCALER(/system/ProjectorInfo.conf),                    0, 0},  //0
    {eDATA_NODE_SYSTEMCAL,              		 MNT_CONFIG_SCALER(/system/SystemCal.conf),                        0, 0},
    {eDATA_NODE_SYSTEMHOURS,            		 MNT_CONFIG_SCALER(/system/SystemHours.conf),                      0, 0},
    {eDATA_NODE_BURNIN,                 		 MNT_CONFIG_SCALER(/system/Burnin.conf),                           0, 0},
    {eDATA_NODE_STARTUP,                		 MNT_CONFIG_SCALER(/system/Startup.conf),                          0, 0},
    {eDATA_NODE_AUTOBRIGHTNESS,         		 MNT_CONFIG_SCALER(/system/AutoBrightness.conf),                   0, 0},
    {eDATA_NODE_COMMONGUI,              		 MNT_CONFIG_SCALER(/gui/CommonGui.conf),                           0, 0},
    {eDATA_NODE_WARPING,                		 MNT_CONFIG_SCALER(/gui/Warping.conf),                             0, 0},
	{eDATA_NODE_TEC_GATING_INFO,       			 MNT_CONFIG_SCALER(/system/TEC_GATING.conf),                       0, 0},
#if (ENABLE_COLOR_UNIFORMITY == TRUE)   //G100_Tim_0012, add, start
    {eDATA_NODE_ACU,                             MNT_CONFIG_SCALER(/CUDATA/ACU.conf),                              0, 0},
#endif //ENABLE_COLOR_UNIFORMITY        //G100_Tim_0012, add, end
	{eDATA_NODE_PROSERVICE, 					 MNT_CONFIG_SCALER(/OMS/Proservice.conf), 						   0, 0},  //A65_Jerry_0005 add
	{eDATA_NODE_ACTUATOR, 					     MNT_CONFIG_SCALER(/system/Actuator.conf), 						   0, 0},
};
#define DATA_NODE_NUMBER sizeof(m_sDataNodeCtrl)/sizeof(m_sDataNodeCtrl[0])

sDATA_NODE_GROUP m_sDataNodeGroup[] =
{
    {m_sDataNodeCtrl,       DATA_NODE_NUMBER},
    {m_sSourceDataNodeCtrl, SOURCE_DATA_NODE_NUMBER},
};
#define MAX_NODE_GROUP_NUMBER sizeof(m_sDataNodeGroup)/sizeof(m_sDataNodeGroup[0])


#ifdef CONF_BACKUP
#define MNT_CONFIG_BAK(x)    CONF_BAK_PATH#x

static sDATA_NODE_CTRL m_sDataNodeBakCtrl[] =
{
    {eDATA_NODE_PROJECTORINFO,          		 MNT_CONFIG_BAK(/system/ProjectorInfo.conf),                    0, 0},  //0
    {eDATA_NODE_SYSTEMCAL,              		 MNT_CONFIG_BAK(/system/SystemCal.conf),                        0, 0},
    {eDATA_NODE_SYSTEMHOURS,            		 MNT_CONFIG_BAK(/system/SystemHours.conf),                      0, 0},
    {eDATA_NODE_BURNIN,                 		 MNT_CONFIG_BAK(/system/Burnin.conf),                           0, 0},
    {eDATA_NODE_STARTUP,                		 MNT_CONFIG_BAK(/system/Startup.conf),                          0, 0},
    {eDATA_NODE_AUTOBRIGHTNESS,         		 MNT_CONFIG_BAK(/system/AutoBrightness.conf),                   0, 0},
    {eDATA_NODE_COMMONGUI,              		 MNT_CONFIG_BAK(/gui/CommonGui.conf),                           0, 0},
    {eDATA_NODE_WARPING,                		 MNT_CONFIG_BAK(/gui/Warping.conf),                             0, 0},
	{eDATA_NODE_TEC_GATING_INFO,       			 MNT_CONFIG_BAK(/system/TEC_GATING.conf),                       0, 0},
#if (ENABLE_COLOR_UNIFORMITY == TRUE)   //G100_Tim_0012, add, start
    {eDATA_NODE_ACU,                             MNT_CONFIG_BAK(/CUDATA/ACU.conf),                              0, 0},
#endif //ENABLE_COLOR_UNIFORMITY        //G100_Tim_0012, add, end
	{eDATA_NODE_PROSERVICE, 					 MNT_CONFIG_BAK(/OMS/Proservice.conf), 						    0, 0},  //A65_Jerry_0005 add
	{eDATA_NODE_ACTUATOR, 					     MNT_CONFIG_BAK(/system/Actuator.conf), 						0, 0},
};
#define DATA_NODE_BAK_NUMBER sizeof(m_sDataNodeBakCtrl)/sizeof(m_sDataNodeBakCtrl[0])

sDATA_NODE_GROUP m_sDataNodeBakGroup[] =
{
    {m_sDataNodeBakCtrl,       DATA_NODE_BAK_NUMBER},
    {m_sSourceDataNodeBakCtrl, SOURCE_DATA_NODE_BAK_NUMBER},
};
#define MAX_NODE_GROUP_BAK_NUMBER sizeof(m_sDataNodeBakGroup)/sizeof(m_sDataNodeBakGroup[0])

#endif /* CONF_BACKUP */


sDATA_NODE_CTRL m_sDataNodeCtrlBackup[] =	//G100_Doulas_0002
{
	{eDATA_BACKUP_RESTORE_CHECK0, 				"/mnt/configs0/scaler/BackupRestoreCheck.conf",    0, 0},
	{eDATA_BACKUP_RESTORE_CHECK1, 				"/mnt/configs1/scaler/BackupRestoreCheck.conf",    0, 0},
	{eDATA_BACKUP_RESTORE_CHECK2, 				"/mnt/configs2/scaler/BackupRestoreCheck.conf",    0, 0},
	{eDATA_BACKUP_RESTORE_CHECK3, 				"/mnt/configs3/scaler/BackupRestoreCheck.conf",    0, 0},
	{eDATA_BACKUP_RESTORE_CHECK4, 				"/mnt/configs4/scaler/BackupRestoreCheck.conf",    0, 0},
	{eDATA_BACKUP_RESTORE_CHECK_WEB,   	        "/mnt/Backup/scaler/BackupRestoreCheck.conf",      0, 0},	//G100_Doulas_0004 Modify
	{eDATA_BACKUP_RESTORE_COMMON_GUI0,      	"/mnt/configs0/scaler/gui/CommonGui.conf",         0, 0},
	{eDATA_BACKUP_RESTORE_COMMON_GUI1,      	"/mnt/configs1/scaler/gui/CommonGui.conf",         0, 0},
	{eDATA_BACKUP_RESTORE_COMMON_GUI2,      	"/mnt/configs2/scaler/gui/CommonGui.conf",         0, 0},
	{eDATA_BACKUP_RESTORE_COMMON_GUI3,      	"/mnt/configs3/scaler/gui/CommonGui.conf",         0, 0},
	{eDATA_BACKUP_RESTORE_COMMON_GUI4,      	"/mnt/configs4/scaler/gui/CommonGui.conf",         0, 0},
	{eDATA_BACKUP_RESTORE_COMMON_WEB_GUI,  		"/mnt/Backup/scaler/gui/CommonGui.conf",           0, 0},	//G100_Doulas_0004 Modify
	{eDATA_BACKUP_RESTORE_PROJECTOR_INFO,  		"/mnt/Backup/scaler/system/ProjectorInfo.conf",    0, 0},	//G100_Doulas_0004
};
#define BACKUP_DATA_NODE_NUMBER sizeof(m_sDataNodeCtrlBackup)/sizeof(m_sDataNodeCtrlBackup[0])

const char *m_cLANFileName[] =
{
    "/mnt/configs/net.conf",
    "/mnt/configs/pjlink.conf",
    "/mnt/configs/time.conf",
    "/mnt/configs/wifi.conf",
    "/mnt/configs/crestron.conf"
};

#define MAX_LAN_FILE_NODE sizeof(m_cLANFileName)/sizeof(m_cLANFileName[0])

pthread_mutex_t m_xutilDataMgrTaskMutex;

BOOL utilDataMgr_MutexGive(const char *pcSemaphore)
{
#if (SYSTEM_OS_TYPE == POSIX_COMPLIANT)

    if(pthread_mutex_unlock(&m_xutilDataMgrTaskMutex) != 0)
    {
        return FALSE;
    }

    return TRUE;

#else
    return TRUE;
#endif

}

static BOOL utilDataMgr_MutexTake(const char *pcSemaphore)
{
#if (SYSTEM_OS_TYPE == POSIX_COMPLIANT)
	if (pthread_mutex_lock(&m_xutilDataMgrTaskMutex) != 0)
    {
        LOG_MSG(db_ALWAYS, "(func:%s) Lock Fail\r\n", pcSemaphore);
        return FALSE;
    }
    else
    {
        LOG_MSG(db_HAL_EEP, "(func:%s) Lock\r\n", pcSemaphore);
    }

    return TRUE;

#else
    return TRUE;
#endif
}

sPARA_FORMAT* utilDataMgr_ParaTableDefaultGet(UINT16 uiNode, UINT32 *ulSize)
{
    sPARA_FORMAT *psPara = NULL;

    switch(uiNode)
    {
        case eDATA_NODE_PROJECTORINFO:
            psPara = m_sProjectorInfo_Default;
            *ulSize = ARRAY_SIZE(m_sProjectorInfo_Default);
            break;

        case eDATA_NODE_SYSTEMCAL:
            psPara = m_sSystemCal_Default;
            *ulSize = ARRAY_SIZE(m_sSystemCal_Default);
            break;

        case eDATA_NODE_BURNIN:
            psPara = m_sBurnin_Default;
            *ulSize = ARRAY_SIZE(m_sBurnin_Default);
            break;

        case eDATA_NODE_STARTUP:
            psPara = m_sStartup_Default;
            *ulSize = ARRAY_SIZE(m_sStartup_Default);
            break;

        case eDATA_NODE_SYSTEMHOURS:
            psPara = m_sSystemHours_Default;
            *ulSize = ARRAY_SIZE(m_sSystemHours_Default);
            break;

        case eDATA_NODE_COMMONGUI:
            psPara = m_sCommonGui_Default;
            *ulSize = ARRAY_SIZE(m_sCommonGui_Default);
            break;

        case eDATA_NODE_WARPING:
            psPara = m_sWarping_Default;
            *ulSize = ARRAY_SIZE(m_sWarping_Default);
            break;

        case eDATA_NODE_AUTOBRIGHTNESS:
            psPara = m_sAutoBrightness_Default;
            *ulSize = ARRAY_SIZE(m_sAutoBrightness_Default);
            break;

        case eDATA_NODE_TEC_GATING_INFO:
            psPara = m_sTEC_GATING_Default;
            *ulSize = ARRAY_SIZE(m_sTEC_GATING_Default);
            break;

		case eDATA_NODE_ACTUATOR:
            psPara = m_sActuator_Default;
            *ulSize = ARRAY_SIZE(m_sActuator_Default);
            break;

		case eDATA_NODE_VGA_COMMON:
        case eDATA_NODE_HDMI1_COMMON:
        case eDATA_NODE_HDMI2_COMMON:
        case eDATA_NODE_DVID_COMMON:
        case eDATA_NODE_DP_COMMON:
        case eDATA_NODE_3GSDI_COMMON:
        case eDATA_NODE_HDBASET_COMMON:
            psPara = m_sCommon_InputSource_Default;
            *ulSize = ARRAY_SIZE(m_sCommon_InputSource_Default);
            break;

        case eDATA_NODE_VGA_HSG_PRESENTATION:
        case eDATA_NODE_VGA_HSG_BRIGHT:
        case eDATA_NODE_VGA_HSG_CINEMA:
        case eDATA_NODE_VGA_HSG_HDR:
        case eDATA_NODE_VGA_HSG_SRGB:
        case eDATA_NODE_VGA_HSG_ENHANCED:
        case eDATA_NODE_VGA_HSG_SUPER_RED:
        case eDATA_NODE_VGA_HSG_DICOMSIM:
        case eDATA_NODE_VGA_HSG_BLENDING:
        case eDATA_NODE_VGA_HSG_USER:
        case eDATA_NODE_VGA_HSG_3D:
        case eDATA_NODE_VGA_HSG_2D_HIGH_SPEED:

        case eDATA_NODE_HDMI1_HSG_PRESENTATION:
        case eDATA_NODE_HDMI1_HSG_CINEMA:
        case eDATA_NODE_HDMI1_HSG_BRIGHT:
        case eDATA_NODE_HDMI1_HSG_ENHANCED:
        case eDATA_NODE_HDMI1_HSG_REC709:
		case eDATA_NODE_HDMI1_HSG_SRGB:
        case eDATA_NODE_HDMI1_HSG_DICOMSIM:
        case eDATA_NODE_HDMI1_HSG_BLENDING:
        case eDATA_NODE_HDMI1_HSG_USER:
        case eDATA_NODE_HDMI1_HSG_HDR:
        case eDATA_NODE_HDMI1_HSG_3D:
        case eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI1_HSG_SUPER_RED:

		case eDATA_NODE_HDMI2_HSG_PRESENTATION:
        case eDATA_NODE_HDMI2_HSG_CINEMA:
        case eDATA_NODE_HDMI2_HSG_BRIGHT:
        case eDATA_NODE_HDMI2_HSG_ENHANCED:
        case eDATA_NODE_HDMI2_HSG_REC709:
		case eDATA_NODE_HDMI2_HSG_SRGB:
        case eDATA_NODE_HDMI2_HSG_DICOMSIM:
        case eDATA_NODE_HDMI2_HSG_BLENDING:
        case eDATA_NODE_HDMI2_HSG_USER:
        case eDATA_NODE_HDMI2_HSG_HDR:
        case eDATA_NODE_HDMI2_HSG_3D:
		case eDATA_NODE_HDMI2_HSG_SUPER_RED:
        case eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED:

		case eDATA_NODE_DVID_HSG_PRESENTATION:
        case eDATA_NODE_DVID_HSG_CINEMA:
        case eDATA_NODE_DVID_HSG_BRIGHT:
        case eDATA_NODE_DVID_HSG_ENHANCED:
        case eDATA_NODE_DVID_HSG_REC709:
		case eDATA_NODE_DVID_HSG_SRGB:
        case eDATA_NODE_DVID_HSG_DICOMSIM:
        case eDATA_NODE_DVID_HSG_BLENDING:
        case eDATA_NODE_DVID_HSG_USER:
        case eDATA_NODE_DVID_HSG_HDR:
        case eDATA_NODE_DVID_HSG_3D:
        case eDATA_NODE_DVID_HSG_2D_HIGH_SPEED:
		case eDATA_NODE_DVID_HSG_SUPER_RED:

		case eDATA_NODE_DP_HSG_PRESENTATION:
        case eDATA_NODE_DP_HSG_CINEMA:
        case eDATA_NODE_DP_HSG_BRIGHT:
        case eDATA_NODE_DP_HSG_ENHANCED:
        case eDATA_NODE_DP_HSG_REC709:
		case eDATA_NODE_DP_HSG_SRGB:
        case eDATA_NODE_DP_HSG_DICOMSIM:
        case eDATA_NODE_DP_HSG_BLENDING:
        case eDATA_NODE_DP_HSG_USER:
        case eDATA_NODE_DP_HSG_HDR:
        case eDATA_NODE_DP_HSG_3D:
		case eDATA_NODE_DP_HSG_SUPER_RED:
        case eDATA_NODE_DP_HSG_2D_HIGH_SPEED:

		case eDATA_NODE_3GSDI_HSG_PRESENTATION:
        case eDATA_NODE_3GSDI_HSG_CINEMA:
        case eDATA_NODE_3GSDI_HSG_BRIGHT:
        case eDATA_NODE_3GSDI_HSG_ENHANCED:
        case eDATA_NODE_3GSDI_HSG_REC709:
		case eDATA_NODE_3GSDI_HSG_SRGB:
        case eDATA_NODE_3GSDI_HSG_DICOMSIM:
        case eDATA_NODE_3GSDI_HSG_BLENDING:
		case eDATA_NODE_3GSDI_HSG_SUPER_RED:
        case eDATA_NODE_3GSDI_HSG_USER:
        case eDATA_NODE_3GSDI_HSG_HDR:
        case eDATA_NODE_3GSDI_HSG_3D:
        case eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED:

		case eDATA_NODE_HDBASET_HSG_PRESENTATION:
        case eDATA_NODE_HDBASET_HSG_CINEMA:
        case eDATA_NODE_HDBASET_HSG_BRIGHT:
        case eDATA_NODE_HDBASET_HSG_ENHANCED:
        case eDATA_NODE_HDBASET_HSG_REC709:
		case eDATA_NODE_HDBASET_HSG_SRGB:
        case eDATA_NODE_HDBASET_HSG_DICOMSIM:
        case eDATA_NODE_HDBASET_HSG_BLENDING:
        case eDATA_NODE_HDBASET_HSG_USER:
        case eDATA_NODE_HDBASET_HSG_HDR:
        case eDATA_NODE_HDBASET_HSG_3D:
        case eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED:
		case eDATA_NODE_HDBASET_HSG_SUPER_RED:
            psPara = m_sHSG_Default;
            *ulSize = ARRAY_SIZE(m_sHSG_Default);
            break;

        case eDATA_NODE_VGA_HSG_USER_PRESENTATION:
        case eDATA_NODE_VGA_HSG_USER_BRIGHT:
        case eDATA_NODE_VGA_HSG_USER_CINEMA:
        case eDATA_NODE_VGA_HSG_USER_HDR:
        case eDATA_NODE_VGA_HSG_USER_SRGB:
        case eDATA_NODE_VGA_HSG_USER_ENHANCED:
        case eDATA_NODE_VGA_HSG_USER_SUPER_RED:
        case eDATA_NODE_VGA_HSG_USER_DICOMSIM:
        case eDATA_NODE_VGA_HSG_USER_BLENDING:
        case eDATA_NODE_VGA_HSG_USER_USER:
        case eDATA_NODE_VGA_HSG_USER_3D:
        case eDATA_NODE_VGA_HSG_USER_2D_HIGH_SPEED:

        case eDATA_NODE_HDMI1_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDMI1_HSG_USER_CINEMA:
        case eDATA_NODE_HDMI1_HSG_USER_BRIGHT:
        case eDATA_NODE_HDMI1_HSG_USER_ENHANCED:
        case eDATA_NODE_HDMI1_HSG_USER_REC709:
		case eDATA_NODE_HDMI1_HSG_USER_SRGB:
        case eDATA_NODE_HDMI1_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDMI1_HSG_USER_BLENDING:
        case eDATA_NODE_HDMI1_HSG_USER_USER:
        case eDATA_NODE_HDMI1_HSG_USER_HDR:
        case eDATA_NODE_HDMI1_HSG_USER_3D:
        case eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI1_HSG_USER_SUPER_RED:

		case eDATA_NODE_HDMI2_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDMI2_HSG_USER_CINEMA:
        case eDATA_NODE_HDMI2_HSG_USER_BRIGHT:
        case eDATA_NODE_HDMI2_HSG_USER_ENHANCED:
        case eDATA_NODE_HDMI2_HSG_USER_REC709:
		case eDATA_NODE_HDMI2_HSG_USER_SRGB:
        case eDATA_NODE_HDMI2_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDMI2_HSG_USER_BLENDING:
        case eDATA_NODE_HDMI2_HSG_USER_USER:
        case eDATA_NODE_HDMI2_HSG_USER_HDR:
        case eDATA_NODE_HDMI2_HSG_USER_3D:
        case eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI2_HSG_USER_SUPER_RED:

		case eDATA_NODE_DVID_HSG_USER_PRESENTATION:
        case eDATA_NODE_DVID_HSG_USER_CINEMA:
        case eDATA_NODE_DVID_HSG_USER_BRIGHT:
        case eDATA_NODE_DVID_HSG_USER_ENHANCED:
        case eDATA_NODE_DVID_HSG_USER_REC709:
		case eDATA_NODE_DVID_HSG_USER_SRGB:
        case eDATA_NODE_DVID_HSG_USER_DICOMSIM:
        case eDATA_NODE_DVID_HSG_USER_BLENDING:
        case eDATA_NODE_DVID_HSG_USER_USER:
        case eDATA_NODE_DVID_HSG_USER_HDR:
        case eDATA_NODE_DVID_HSG_USER_3D:
        case eDATA_NODE_DVID_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DVID_HSG_USER_SUPER_RED:

		case eDATA_NODE_DP_HSG_USER_PRESENTATION:
        case eDATA_NODE_DP_HSG_USER_CINEMA:
        case eDATA_NODE_DP_HSG_USER_BRIGHT:
        case eDATA_NODE_DP_HSG_USER_ENHANCED:
        case eDATA_NODE_DP_HSG_USER_REC709:
		case eDATA_NODE_DP_HSG_USER_SRGB:
        case eDATA_NODE_DP_HSG_USER_DICOMSIM:
        case eDATA_NODE_DP_HSG_USER_BLENDING:
        case eDATA_NODE_DP_HSG_USER_USER:
        case eDATA_NODE_DP_HSG_USER_HDR:
        case eDATA_NODE_DP_HSG_USER_3D:
        case eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DP_HSG_USER_SUPER_RED:

		case eDATA_NODE_3GSDI_HSG_USER_PRESENTATION:
        case eDATA_NODE_3GSDI_HSG_USER_CINEMA:
        case eDATA_NODE_3GSDI_HSG_USER_BRIGHT:
        case eDATA_NODE_3GSDI_HSG_USER_ENHANCED:
        case eDATA_NODE_3GSDI_HSG_USER_REC709:
		case eDATA_NODE_3GSDI_HSG_USER_SRGB:
        case eDATA_NODE_3GSDI_HSG_USER_DICOMSIM:
        case eDATA_NODE_3GSDI_HSG_USER_BLENDING:
        case eDATA_NODE_3GSDI_HSG_USER_USER:
        case eDATA_NODE_3GSDI_HSG_USER_HDR:
        case eDATA_NODE_3GSDI_HSG_USER_3D:
        case eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_3GSDI_HSG_USER_SUPER_RED:

		case eDATA_NODE_HDBASET_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDBASET_HSG_USER_CINEMA:
        case eDATA_NODE_HDBASET_HSG_USER_BRIGHT:
        case eDATA_NODE_HDBASET_HSG_USER_ENHANCED:
        case eDATA_NODE_HDBASET_HSG_USER_REC709:
		case eDATA_NODE_HDBASET_HSG_USER_SRGB:
        case eDATA_NODE_HDBASET_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDBASET_HSG_USER_BLENDING:
        case eDATA_NODE_HDBASET_HSG_USER_USER:
        case eDATA_NODE_HDBASET_HSG_USER_HDR:
        case eDATA_NODE_HDBASET_HSG_USER_3D:
        case eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDBASET_HSG_USER_SUPER_RED:
            psPara = m_sHSG_Default;
            *ulSize = ARRAY_SIZE(m_sHSG_Default);
            break;

        case eDATA_NODE_WAP_CALIBRATION_TAG:
            psPara = m_sWAP_Tag_Default;
            *ulSize = ARRAY_SIZE(m_sWAP_Tag_Default);
        	break;

		case eDATA_NODE_WAP_PRESENTATION_RATIO:
        case eDATA_NODE_WAP_CINEMA_RATIO:
        case eDATA_NODE_WAP_BRIGHT_RATIO:
        case eDATA_NODE_WAP_ENHANCED_RATIO:
        case eDATA_NODE_WAP_REC709_RATIO:
		case eDATA_NODE_WAP_SRGB_RATIO:
        case eDATA_NODE_WAP_DICOM_RATIO:
        case eDATA_NODE_WAP_BLENDING_RATIO:
        case eDATA_NODE_WAP_USER_RATIO:
        case eDATA_NODE_WAP_HDR_RATIO:
        case eDATA_NODE_WAP_3D_RATIO:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO:
		case eDATA_NODE_WAP_SUPER_BRIGHT_RATIO:
		case eDATA_NODE_WAP_SUPER_RED_RATIO:
        	 psPara = m_sWAP_Ratio_Default;
        	 *ulSize = ARRAY_SIZE(m_sWAP_Ratio_Default);
        	 break;

		case eDATA_NODE_WAP_PRESENTATION_OFFSET:
        case eDATA_NODE_WAP_CINEMA_OFFSET:
        case eDATA_NODE_WAP_BRIGHT_OFFSET:
        case eDATA_NODE_WAP_ENHANCED_OFFSET:
        case eDATA_NODE_WAP_REC709_OFFSET:
        case eDATA_NODE_WAP_SRGB_OFFSET:
        case eDATA_NODE_WAP_DICOM_OFFSET:
        case eDATA_NODE_WAP_BLENDING_OFFSET:
        case eDATA_NODE_WAP_USER_OFFSET:
        case eDATA_NODE_WAP_HDR_OFFSET:
        case eDATA_NODE_WAP_3D_OFFSET:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET:
		case eDATA_NODE_WAP_SUPER_RED_OFFSET:
		case eDATA_NODE_WAP_SUPER_BRIGHT_OFFSET:
        	 psPara = m_sWAP_Offset_Default;
        	 *ulSize = ARRAY_SIZE(m_sWAP_Offset_Default);
        	 break;

		case eDATA_NODE_WAP_PRESENTATION_PWM:
        case eDATA_NODE_WAP_CINEMA_PWM:
        case eDATA_NODE_WAP_BRIGHT_PWM:
        case eDATA_NODE_WAP_ENHANCED_PWM:
        case eDATA_NODE_WAP_REC709_PWM:
        case eDATA_NODE_WAP_SRGB_PWM:
        case eDATA_NODE_WAP_DICOM_PWM:
        case eDATA_NODE_WAP_BLENDING_PWM:
        case eDATA_NODE_WAP_USER_PWM:
        case eDATA_NODE_WAP_HDR_PWM:
        case eDATA_NODE_WAP_3D_PWM:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_PWM:
		case eDATA_NODE_WAP_SUPER_RED_PWM:
		case eDATA_NODE_WAP_SUPER_BRIGHT_PWM:
        	 psPara = m_sWAP_PWM_Default;
        	 *ulSize = ARRAY_SIZE(m_sWAP_PWM_Default);
        	 break;
        case eDATA_NODE_VGA_COLOR_PRESENTATION:
        case eDATA_NODE_VGA_COLOR_BRIGHT:
        case eDATA_NODE_VGA_COLOR_CINEMA:
        case eDATA_NODE_VGA_COLOR_HDR:
        case eDATA_NODE_VGA_COLOR_SRGB:
        case eDATA_NODE_VGA_COLOR_DICOMSIM:
        case eDATA_NODE_VGA_COLOR_BLENDING:
        case eDATA_NODE_VGA_COLOR_3D:
        case eDATA_NODE_VGA_COLOR_USER:
        case eDATA_NODE_VGA_COLOR_SUPER_RED:
        case eDATA_NODE_VGA_COLOR_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_COLOR_ENHANCED:

        case eDATA_NODE_HDMI1_COLOR_PRESENTATION:
        case eDATA_NODE_HDMI1_COLOR_CINEMA:
        case eDATA_NODE_HDMI1_COLOR_BRIGHT:
        case eDATA_NODE_HDMI1_COLOR_ENHANCED:
        case eDATA_NODE_HDMI1_COLOR_REC709:
        case eDATA_NODE_HDMI1_COLOR_SRGB:
        case eDATA_NODE_HDMI1_COLOR_DICOMSIM:
        case eDATA_NODE_HDMI1_COLOR_BLENDING:
        case eDATA_NODE_HDMI1_COLOR_USER:
        case eDATA_NODE_HDMI1_COLOR_HDR:
        case eDATA_NODE_HDMI1_COLOR_3D:
        case eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI1_COLOR_SUPER_RED:

		case eDATA_NODE_HDMI2_COLOR_PRESENTATION:
        case eDATA_NODE_HDMI2_COLOR_CINEMA:
        case eDATA_NODE_HDMI2_COLOR_BRIGHT:
        case eDATA_NODE_HDMI2_COLOR_ENHANCED:
        case eDATA_NODE_HDMI2_COLOR_REC709:
        case eDATA_NODE_HDMI2_COLOR_SRGB:
        case eDATA_NODE_HDMI2_COLOR_DICOMSIM:
        case eDATA_NODE_HDMI2_COLOR_BLENDING:
        case eDATA_NODE_HDMI2_COLOR_USER:
        case eDATA_NODE_HDMI2_COLOR_HDR:
        case eDATA_NODE_HDMI2_COLOR_3D:
        case eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI2_COLOR_SUPER_RED:

		case eDATA_NODE_DVID_COLOR_PRESENTATION:
        case eDATA_NODE_DVID_COLOR_CINEMA:
        case eDATA_NODE_DVID_COLOR_BRIGHT:
        case eDATA_NODE_DVID_COLOR_ENHANCED:
        case eDATA_NODE_DVID_COLOR_REC709:
        case eDATA_NODE_DVID_COLOR_SRGB:
        case eDATA_NODE_DVID_COLOR_DICOMSIM:
        case eDATA_NODE_DVID_COLOR_BLENDING:
        case eDATA_NODE_DVID_COLOR_USER:
        case eDATA_NODE_DVID_COLOR_HDR:
        case eDATA_NODE_DVID_COLOR_3D:
        case eDATA_NODE_DVID_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_DVID_COLOR_SUPER_RED:

		case eDATA_NODE_DP_COLOR_PRESENTATION:
        case eDATA_NODE_DP_COLOR_CINEMA:
        case eDATA_NODE_DP_COLOR_BRIGHT:
        case eDATA_NODE_DP_COLOR_ENHANCED:
        case eDATA_NODE_DP_COLOR_REC709:
        case eDATA_NODE_DP_COLOR_SRGB:
        case eDATA_NODE_DP_COLOR_DICOMSIM:
        case eDATA_NODE_DP_COLOR_BLENDING:
        case eDATA_NODE_DP_COLOR_USER:
        case eDATA_NODE_DP_COLOR_HDR:
        case eDATA_NODE_DP_COLOR_3D:
        case eDATA_NODE_DP_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_DP_COLOR_SUPER_RED:

		case eDATA_NODE_3GSDI_COLOR_PRESENTATION:
        case eDATA_NODE_3GSDI_COLOR_CINEMA:
        case eDATA_NODE_3GSDI_COLOR_BRIGHT:
        case eDATA_NODE_3GSDI_COLOR_ENHANCED:
        case eDATA_NODE_3GSDI_COLOR_REC709:
        case eDATA_NODE_3GSDI_COLOR_SRGB:
        case eDATA_NODE_3GSDI_COLOR_DICOMSIM:
        case eDATA_NODE_3GSDI_COLOR_BLENDING:
        case eDATA_NODE_3GSDI_COLOR_USER:
        case eDATA_NODE_3GSDI_COLOR_HDR:
        case eDATA_NODE_3GSDI_COLOR_3D:
        case eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_3GSDI_COLOR_SUPER_RED:

		case eDATA_NODE_HDBASET_COLOR_PRESENTATION:
        case eDATA_NODE_HDBASET_COLOR_CINEMA:
        case eDATA_NODE_HDBASET_COLOR_BRIGHT:
        case eDATA_NODE_HDBASET_COLOR_ENHANCED:
        case eDATA_NODE_HDBASET_COLOR_REC709:
        case eDATA_NODE_HDBASET_COLOR_SRGB:
        case eDATA_NODE_HDBASET_COLOR_DICOMSIM:
        case eDATA_NODE_HDBASET_COLOR_BLENDING:
        case eDATA_NODE_HDBASET_COLOR_USER:
        case eDATA_NODE_HDBASET_COLOR_HDR:
        case eDATA_NODE_HDBASET_COLOR_3D:
        case eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED:
		case eDATA_NODE_HDBASET_COLOR_SUPER_RED:
            psPara = m_sColor_Default;
            *ulSize = ARRAY_SIZE(m_sColor_Default);
            break;

        case eDATA_NODE_VGA_COLOR_USER_PRESENTATION:
        case eDATA_NODE_VGA_COLOR_USER_BRIGHT:
        case eDATA_NODE_VGA_COLOR_USER_CINEMA:
        case eDATA_NODE_VGA_COLOR_USER_HDR:
        case eDATA_NODE_VGA_COLOR_USER_SRGB:
        case eDATA_NODE_VGA_COLOR_USER_DICOMSIM:
        case eDATA_NODE_VGA_COLOR_USER_BLENDING:
        case eDATA_NODE_VGA_COLOR_USER_3D:
        case eDATA_NODE_VGA_COLOR_USER_USER:
        case eDATA_NODE_VGA_COLOR_USER_SUPER_RED:
        case eDATA_NODE_VGA_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_COLOR_USER_ENHANCED:

    	case eDATA_NODE_HDMI1_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDMI1_COLOR_USER_CINEMA:
        case eDATA_NODE_HDMI1_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDMI1_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDMI1_COLOR_USER_REC709:
        case eDATA_NODE_HDMI1_COLOR_USER_SRGB:
        case eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDMI1_COLOR_USER_BLENDING:
        case eDATA_NODE_HDMI1_COLOR_USER_USER:
        case eDATA_NODE_HDMI1_COLOR_USER_HDR:
        case eDATA_NODE_HDMI1_COLOR_USER_3D:
        case eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI1_COLOR_USER_SUPER_RED:

		case eDATA_NODE_HDMI2_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDMI2_COLOR_USER_CINEMA:
        case eDATA_NODE_HDMI2_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDMI2_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDMI2_COLOR_USER_REC709:
        case eDATA_NODE_HDMI2_COLOR_USER_SRGB:
        case eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDMI2_COLOR_USER_BLENDING:
        case eDATA_NODE_HDMI2_COLOR_USER_USER:
        case eDATA_NODE_HDMI2_COLOR_USER_HDR:
        case eDATA_NODE_HDMI2_COLOR_USER_3D:
        case eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI2_COLOR_USER_SUPER_RED:

		case eDATA_NODE_DVID_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_DVID_COLOR_USER_CINEMA:
        case eDATA_NODE_DVID_COLOR_USER_BRIGHT:
        case eDATA_NODE_DVID_COLOR_USER_ENHANCED:
        case eDATA_NODE_DVID_COLOR_USER_REC709:
        case eDATA_NODE_DVID_COLOR_USER_SRGB:
        case eDATA_NODE_DVID_COLOR_USER_DICOMSIM:
        case eDATA_NODE_DVID_COLOR_USER_BLENDING:
        case eDATA_NODE_DVID_COLOR_USER_USER:
        case eDATA_NODE_DVID_COLOR_USER_HDR:
        case eDATA_NODE_DVID_COLOR_USER_3D:
        case eDATA_NODE_DVID_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DVID_COLOR_USER_SUPER_RED:

		case eDATA_NODE_DP_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_DP_COLOR_USER_CINEMA:
        case eDATA_NODE_DP_COLOR_USER_BRIGHT:
        case eDATA_NODE_DP_COLOR_USER_ENHANCED:
        case eDATA_NODE_DP_COLOR_USER_REC709:
        case eDATA_NODE_DP_COLOR_USER_SRGB:
        case eDATA_NODE_DP_COLOR_USER_DICOMSIM:
        case eDATA_NODE_DP_COLOR_USER_BLENDING:
        case eDATA_NODE_DP_COLOR_USER_USER:
        case eDATA_NODE_DP_COLOR_USER_HDR:
        case eDATA_NODE_DP_COLOR_USER_3D:
        case eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DP_COLOR_USER_SUPER_RED:

		case eDATA_NODE_3GSDI_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_3GSDI_COLOR_USER_CINEMA:
        case eDATA_NODE_3GSDI_COLOR_USER_BRIGHT:
        case eDATA_NODE_3GSDI_COLOR_USER_ENHANCED:
        case eDATA_NODE_3GSDI_COLOR_USER_REC709:
        case eDATA_NODE_3GSDI_COLOR_USER_SRGB:
        case eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM:
        case eDATA_NODE_3GSDI_COLOR_USER_BLENDING:
        case eDATA_NODE_3GSDI_COLOR_USER_USER:
        case eDATA_NODE_3GSDI_COLOR_USER_HDR:
        case eDATA_NODE_3GSDI_COLOR_USER_3D:
        case eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_3GSDI_COLOR_USER_SUPER_RED:

		case eDATA_NODE_HDBASET_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDBASET_COLOR_USER_CINEMA:
        case eDATA_NODE_HDBASET_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDBASET_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDBASET_COLOR_USER_REC709:
        case eDATA_NODE_HDBASET_COLOR_USER_SRGB:
        case eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDBASET_COLOR_USER_BLENDING:
        case eDATA_NODE_HDBASET_COLOR_USER_USER:
        case eDATA_NODE_HDBASET_COLOR_USER_HDR:
        case eDATA_NODE_HDBASET_COLOR_USER_3D:
        case eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDBASET_COLOR_USER_SUPER_RED:
        	psPara = m_sColor_Default;
        	*ulSize = ARRAY_SIZE(m_sColor_Default);
        	break;

#if (ENABLE_COLOR_UNIFORMITY == TRUE)                   //G100_Tim_0012, add, start // A35G2_CDS_Coda_0028
       case eDATA_NODE_ACU:
           psPara = m_sACU_Default;
           *ulSize = ARRAY_SIZE(m_sACU_Default);
           break;
#endif //ENABLE_COLOR_UNIFORMITY                        //G100_Tim_0012, add, end

    	case eDATA_NODE_PROSERVICE:
			psPara = m_sPROSERVICE_Default;
			*ulSize = ARRAY_SIZE(m_sPROSERVICE_Default);
			break;

        default:
            psPara = NULL;
            *ulSize = 0;
            break;
    }

    return psPara;
}


sPARA_FORMAT* utilDataMgr_ParaTableGet(eDATA_NODE eNode)
{
    sPARA_FORMAT *psPara = NULL;

    switch(eNode)
    {
        case eDATA_NODE_PROJECTORINFO:
            psPara = m_sProjectorInfo;
            break;

        case eDATA_NODE_SYSTEMCAL:
            psPara = m_sSystemCal;
            break;

        case eDATA_NODE_BURNIN:
            psPara = m_sBurnin;
            break;

        case eDATA_NODE_STARTUP:
            psPara = m_sStartup;
            break;

        case eDATA_NODE_SYSTEMHOURS:
            psPara = m_sSystemHours;
            break;

        case eDATA_NODE_COMMONGUI:
            psPara = m_sCommonGui;
            break;

        case eDATA_NODE_WARPING:
            psPara = m_sWarping;
            break;

        case eDATA_NODE_AUTOBRIGHTNESS:
            psPara = m_sAutoBrightness;
            break;

        case eDATA_NODE_TEC_GATING_INFO:
        	psPara = m_sTEC_GATING;
        	break;

		case eDATA_NODE_ACTUATOR:
			psPara = m_sActuator;
			break;

        case eDATA_NODE_WAP_CALIBRATION_TAG:
        	psPara = m_sWAP_Calibration_Tag;
        	break;

#if (ENABLE_COLOR_UNIFORMITY == TRUE)                   //G100_Tim_0012, add, start
        case eDATA_NODE_ACU:
            psPara = m_sACU_DATA;
            break;
#endif //ENABLE_COLOR_UNIFORMITY                        //G100_Tim_0012, add, end

		case eDATA_NODE_PROSERVICE:
			psPara = m_sProService_DATA;
			break;

        default:
            psPara = utilDataMgrSource_ParaTableGet(eNode);
            break;
    }

    return psPara;
}

UINT32 utilDataMgr_ParaTableSizeGet(eDATA_NODE eNode)
{
    UINT32 ulSize = 0;

    switch(eNode)
    {
        case eDATA_NODE_PROJECTORINFO:
            ulSize = ePI_NUMBER;
            break;

        case eDATA_NODE_SYSTEMCAL:
            ulSize = eSC_NUMBER;
            break;

        case eDATA_NODE_BURNIN:
            ulSize = eBI_NUMBER;
            break;

        case eDATA_NODE_STARTUP:
            ulSize = eSU_NUMBER;
            break;

        case eDATA_NODE_SYSTEMHOURS:
            ulSize = eSH_NUMBER;
            break;

        case eDATA_NODE_COMMONGUI:
            ulSize = eCG_NUMBER;
            break;

        case eDATA_NODE_WARPING:
            ulSize = eWI_NUMBER;
            break;

        case eDATA_NODE_AUTOBRIGHTNESS:
            ulSize = eAB_NUMBER;
            break;

        case eDATA_NODE_TEC_GATING_INFO:
        	ulSize = eTEC_GATING_NUMBERS;
        	break;

		case eDATA_NODE_ACTUATOR:
        	ulSize = eACT_NUMBERS;
			break;

		case eDATA_NODE_VGA_COMMON:
        case eDATA_NODE_HDMI1_COMMON:
        case eDATA_NODE_HDMI2_COMMON:
        case eDATA_NODE_DVID_COMMON:
        case eDATA_NODE_DP_COMMON:
        case eDATA_NODE_3GSDI_COMMON:
        case eDATA_NODE_HDBASET_COMMON:
            ulSize = eSCM_NUMBER;
            break;

        case eDATA_NODE_VGA_HSG_PRESENTATION:
        case eDATA_NODE_VGA_HSG_BRIGHT:
		case eDATA_NODE_VGA_HSG_CINEMA:
		case eDATA_NODE_VGA_HSG_HDR:
		case eDATA_NODE_VGA_HSG_SRGB:
        case eDATA_NODE_VGA_HSG_ENHANCED:
        case eDATA_NODE_VGA_HSG_SUPER_RED:
        case eDATA_NODE_VGA_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_HSG_DICOMSIM:
        case eDATA_NODE_VGA_HSG_BLENDING:
        case eDATA_NODE_VGA_HSG_USER:
        case eDATA_NODE_VGA_HSG_3D:

        case eDATA_NODE_HDMI1_HSG_PRESENTATION:
        case eDATA_NODE_HDMI1_HSG_CINEMA:
        case eDATA_NODE_HDMI1_HSG_BRIGHT:
        case eDATA_NODE_HDMI1_HSG_ENHANCED:
        case eDATA_NODE_HDMI1_HSG_REC709:
        case eDATA_NODE_HDMI1_HSG_SRGB:
        case eDATA_NODE_HDMI1_HSG_DICOMSIM:
        case eDATA_NODE_HDMI1_HSG_BLENDING:
        case eDATA_NODE_HDMI1_HSG_USER:
        case eDATA_NODE_HDMI1_HSG_HDR:
        case eDATA_NODE_HDMI1_HSG_3D:
        case eDATA_NODE_HDMI1_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_HDMI1_HSG_SUPER_RED:

        case eDATA_NODE_HDMI2_HSG_PRESENTATION:
        case eDATA_NODE_HDMI2_HSG_CINEMA:
        case eDATA_NODE_HDMI2_HSG_BRIGHT:
        case eDATA_NODE_HDMI2_HSG_ENHANCED:
        case eDATA_NODE_HDMI2_HSG_REC709:
        case eDATA_NODE_HDMI2_HSG_SRGB:
        case eDATA_NODE_HDMI2_HSG_DICOMSIM:
        case eDATA_NODE_HDMI2_HSG_BLENDING:
        case eDATA_NODE_HDMI2_HSG_USER:
        case eDATA_NODE_HDMI2_HSG_HDR:
        case eDATA_NODE_HDMI2_HSG_3D:
        case eDATA_NODE_HDMI2_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_HDMI2_HSG_SUPER_RED:

        case eDATA_NODE_DVID_HSG_PRESENTATION:
        case eDATA_NODE_DVID_HSG_CINEMA:
        case eDATA_NODE_DVID_HSG_BRIGHT:
        case eDATA_NODE_DVID_HSG_ENHANCED:
        case eDATA_NODE_DVID_HSG_REC709:
        case eDATA_NODE_DVID_HSG_SRGB:
        case eDATA_NODE_DVID_HSG_DICOMSIM:
        case eDATA_NODE_DVID_HSG_BLENDING:
        case eDATA_NODE_DVID_HSG_USER:
        case eDATA_NODE_DVID_HSG_HDR:
        case eDATA_NODE_DVID_HSG_3D:
        case eDATA_NODE_DVID_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_DVID_HSG_SUPER_RED:

        case eDATA_NODE_DP_HSG_PRESENTATION:
        case eDATA_NODE_DP_HSG_CINEMA:
        case eDATA_NODE_DP_HSG_BRIGHT:
        case eDATA_NODE_DP_HSG_ENHANCED:
        case eDATA_NODE_DP_HSG_REC709:
        case eDATA_NODE_DP_HSG_SRGB:
        case eDATA_NODE_DP_HSG_DICOMSIM:
        case eDATA_NODE_DP_HSG_BLENDING:
        case eDATA_NODE_DP_HSG_USER:
        case eDATA_NODE_DP_HSG_HDR:
        case eDATA_NODE_DP_HSG_3D:
        case eDATA_NODE_DP_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_DP_HSG_SUPER_RED:

        case eDATA_NODE_3GSDI_HSG_PRESENTATION:
        case eDATA_NODE_3GSDI_HSG_CINEMA:
        case eDATA_NODE_3GSDI_HSG_BRIGHT:
        case eDATA_NODE_3GSDI_HSG_ENHANCED:
        case eDATA_NODE_3GSDI_HSG_REC709:
        case eDATA_NODE_3GSDI_HSG_SRGB:
        case eDATA_NODE_3GSDI_HSG_DICOMSIM:
        case eDATA_NODE_3GSDI_HSG_BLENDING:
        case eDATA_NODE_3GSDI_HSG_USER:
        case eDATA_NODE_3GSDI_HSG_HDR:
        case eDATA_NODE_3GSDI_HSG_3D:
        case eDATA_NODE_3GSDI_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_3GSDI_HSG_SUPER_RED:

        case eDATA_NODE_HDBASET_HSG_PRESENTATION:
        case eDATA_NODE_HDBASET_HSG_CINEMA:
        case eDATA_NODE_HDBASET_HSG_BRIGHT:
        case eDATA_NODE_HDBASET_HSG_ENHANCED:
        case eDATA_NODE_HDBASET_HSG_REC709:
        case eDATA_NODE_HDBASET_HSG_SRGB:
        case eDATA_NODE_HDBASET_HSG_DICOMSIM:
        case eDATA_NODE_HDBASET_HSG_BLENDING:
        case eDATA_NODE_HDBASET_HSG_USER:
        case eDATA_NODE_HDBASET_HSG_HDR:
        case eDATA_NODE_HDBASET_HSG_3D:
        case eDATA_NODE_HDBASET_HSG_2D_HIGH_SPEED:
        case eDATA_NODE_HDBASET_HSG_SUPER_RED:

        case eDATA_NODE_VGA_HSG_USER_PRESENTATION:
        case eDATA_NODE_VGA_HSG_USER_BRIGHT:
		case eDATA_NODE_VGA_HSG_USER_CINEMA:
		case eDATA_NODE_VGA_HSG_USER_HDR:
		case eDATA_NODE_VGA_HSG_USER_SRGB:
        case eDATA_NODE_VGA_HSG_USER_ENHANCED:
        case eDATA_NODE_VGA_HSG_USER_SUPER_RED:
        case eDATA_NODE_VGA_HSG_USER_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_HSG_USER_DICOMSIM:
        case eDATA_NODE_VGA_HSG_USER_BLENDING:
        case eDATA_NODE_VGA_HSG_USER_USER:
        case eDATA_NODE_VGA_HSG_USER_3D:

        case eDATA_NODE_HDMI1_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDMI1_HSG_USER_CINEMA:
        case eDATA_NODE_HDMI1_HSG_USER_BRIGHT:
        case eDATA_NODE_HDMI1_HSG_USER_ENHANCED:
        case eDATA_NODE_HDMI1_HSG_USER_REC709:
		case eDATA_NODE_HDMI1_HSG_USER_SRGB:
        case eDATA_NODE_HDMI1_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDMI1_HSG_USER_BLENDING:
        case eDATA_NODE_HDMI1_HSG_USER_USER:
        case eDATA_NODE_HDMI1_HSG_USER_HDR:
        case eDATA_NODE_HDMI1_HSG_USER_3D:
        case eDATA_NODE_HDMI1_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI1_HSG_USER_SUPER_RED:

		case eDATA_NODE_HDMI2_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDMI2_HSG_USER_CINEMA:
        case eDATA_NODE_HDMI2_HSG_USER_BRIGHT:
        case eDATA_NODE_HDMI2_HSG_USER_ENHANCED:
        case eDATA_NODE_HDMI2_HSG_USER_REC709:
		case eDATA_NODE_HDMI2_HSG_USER_SRGB:
        case eDATA_NODE_HDMI2_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDMI2_HSG_USER_BLENDING:
        case eDATA_NODE_HDMI2_HSG_USER_USER:
        case eDATA_NODE_HDMI2_HSG_USER_HDR:
        case eDATA_NODE_HDMI2_HSG_USER_3D:
        case eDATA_NODE_HDMI2_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDMI2_HSG_USER_SUPER_RED:

		case eDATA_NODE_DVID_HSG_USER_PRESENTATION:
        case eDATA_NODE_DVID_HSG_USER_CINEMA:
        case eDATA_NODE_DVID_HSG_USER_BRIGHT:
        case eDATA_NODE_DVID_HSG_USER_ENHANCED:
        case eDATA_NODE_DVID_HSG_USER_REC709:
		case eDATA_NODE_DVID_HSG_USER_SRGB:
        case eDATA_NODE_DVID_HSG_USER_DICOMSIM:
        case eDATA_NODE_DVID_HSG_USER_BLENDING:
        case eDATA_NODE_DVID_HSG_USER_USER:
        case eDATA_NODE_DVID_HSG_USER_HDR:
        case eDATA_NODE_DVID_HSG_USER_3D:
        case eDATA_NODE_DVID_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DVID_HSG_USER_SUPER_RED:

		case eDATA_NODE_DP_HSG_USER_PRESENTATION:
        case eDATA_NODE_DP_HSG_USER_CINEMA:
        case eDATA_NODE_DP_HSG_USER_BRIGHT:
        case eDATA_NODE_DP_HSG_USER_ENHANCED:
        case eDATA_NODE_DP_HSG_USER_REC709:
		case eDATA_NODE_DP_HSG_USER_SRGB:
        case eDATA_NODE_DP_HSG_USER_DICOMSIM:
        case eDATA_NODE_DP_HSG_USER_BLENDING:
        case eDATA_NODE_DP_HSG_USER_USER:
        case eDATA_NODE_DP_HSG_USER_HDR:
        case eDATA_NODE_DP_HSG_USER_3D:
        case eDATA_NODE_DP_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_DP_HSG_USER_SUPER_RED:

		case eDATA_NODE_3GSDI_HSG_USER_PRESENTATION:
        case eDATA_NODE_3GSDI_HSG_USER_CINEMA:
        case eDATA_NODE_3GSDI_HSG_USER_BRIGHT:
        case eDATA_NODE_3GSDI_HSG_USER_ENHANCED:
        case eDATA_NODE_3GSDI_HSG_USER_REC709:
		case eDATA_NODE_3GSDI_HSG_USER_SRGB:
        case eDATA_NODE_3GSDI_HSG_USER_DICOMSIM:
        case eDATA_NODE_3GSDI_HSG_USER_BLENDING:
        case eDATA_NODE_3GSDI_HSG_USER_USER:
        case eDATA_NODE_3GSDI_HSG_USER_HDR:
        case eDATA_NODE_3GSDI_HSG_USER_3D:
        case eDATA_NODE_3GSDI_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_3GSDI_HSG_USER_SUPER_RED:

		case eDATA_NODE_HDBASET_HSG_USER_PRESENTATION:
        case eDATA_NODE_HDBASET_HSG_USER_CINEMA:
        case eDATA_NODE_HDBASET_HSG_USER_BRIGHT:
        case eDATA_NODE_HDBASET_HSG_USER_ENHANCED:
        case eDATA_NODE_HDBASET_HSG_USER_REC709:
		case eDATA_NODE_HDBASET_HSG_USER_SRGB:
        case eDATA_NODE_HDBASET_HSG_USER_DICOMSIM:
        case eDATA_NODE_HDBASET_HSG_USER_BLENDING:
        case eDATA_NODE_HDBASET_HSG_USER_USER:
        case eDATA_NODE_HDBASET_HSG_USER_HDR:
        case eDATA_NODE_HDBASET_HSG_USER_3D:
        case eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED:
		case eDATA_NODE_HDBASET_HSG_USER_SUPER_RED:
            ulSize = eHSG_NUMBER;
            break;

        case eDATA_NODE_VGA_COLOR_PRESENTATION:
        case eDATA_NODE_VGA_COLOR_BRIGHT:
        case eDATA_NODE_VGA_COLOR_CINEMA:
        case eDATA_NODE_VGA_COLOR_HDR:
        case eDATA_NODE_VGA_COLOR_SRGB:
        case eDATA_NODE_VGA_COLOR_DICOMSIM:
        case eDATA_NODE_VGA_COLOR_BLENDING:
        case eDATA_NODE_VGA_COLOR_USER:
        case eDATA_NODE_VGA_COLOR_3D:
        case eDATA_NODE_VGA_COLOR_SUPER_RED:
        case eDATA_NODE_VGA_COLOR_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_COLOR_ENHANCED:

        case eDATA_NODE_HDMI1_COLOR_PRESENTATION:
        case eDATA_NODE_HDMI1_COLOR_CINEMA:
        case eDATA_NODE_HDMI1_COLOR_BRIGHT:
        case eDATA_NODE_HDMI1_COLOR_ENHANCED:
        case eDATA_NODE_HDMI1_COLOR_REC709:
        case eDATA_NODE_HDMI1_COLOR_DICOMSIM:
        case eDATA_NODE_HDMI1_COLOR_BLENDING:
        case eDATA_NODE_HDMI1_COLOR_USER:
        case eDATA_NODE_HDMI1_COLOR_HDR:
		case eDATA_NODE_HDMI1_COLOR_SRGB:
        case eDATA_NODE_HDMI1_COLOR_3D:
        case eDATA_NODE_HDMI1_COLOR_SUPER_RED:
        case eDATA_NODE_HDMI1_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_HDMI2_COLOR_PRESENTATION:
        case eDATA_NODE_HDMI2_COLOR_CINEMA:
        case eDATA_NODE_HDMI2_COLOR_BRIGHT:
        case eDATA_NODE_HDMI2_COLOR_ENHANCED:
        case eDATA_NODE_HDMI2_COLOR_REC709:
        case eDATA_NODE_HDMI2_COLOR_SRGB:
        case eDATA_NODE_HDMI2_COLOR_DICOMSIM:
        case eDATA_NODE_HDMI2_COLOR_BLENDING:
        case eDATA_NODE_HDMI2_COLOR_USER:
        case eDATA_NODE_HDMI2_COLOR_HDR:
        case eDATA_NODE_HDMI2_COLOR_3D:
        case eDATA_NODE_HDMI2_COLOR_SUPER_RED:
        case eDATA_NODE_HDMI2_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_DVID_COLOR_PRESENTATION:
        case eDATA_NODE_DVID_COLOR_CINEMA:
        case eDATA_NODE_DVID_COLOR_BRIGHT:
        case eDATA_NODE_DVID_COLOR_ENHANCED:
        case eDATA_NODE_DVID_COLOR_REC709:
        case eDATA_NODE_DVID_COLOR_SRGB:
        case eDATA_NODE_DVID_COLOR_DICOMSIM:
        case eDATA_NODE_DVID_COLOR_BLENDING:
        case eDATA_NODE_DVID_COLOR_USER:
        case eDATA_NODE_DVID_COLOR_HDR:
        case eDATA_NODE_DVID_COLOR_3D:
        case eDATA_NODE_DVID_COLOR_SUPER_RED:
        case eDATA_NODE_DVID_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_DP_COLOR_PRESENTATION:
        case eDATA_NODE_DP_COLOR_CINEMA:
        case eDATA_NODE_DP_COLOR_BRIGHT:
        case eDATA_NODE_DP_COLOR_ENHANCED:
        case eDATA_NODE_DP_COLOR_REC709:
        case eDATA_NODE_DP_COLOR_SRGB:
        case eDATA_NODE_DP_COLOR_DICOMSIM:
        case eDATA_NODE_DP_COLOR_BLENDING:
        case eDATA_NODE_DP_COLOR_USER:
        case eDATA_NODE_DP_COLOR_HDR:
        case eDATA_NODE_DP_COLOR_3D:
        case eDATA_NODE_DP_COLOR_SUPER_RED:
        case eDATA_NODE_DP_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_3GSDI_COLOR_PRESENTATION:
        case eDATA_NODE_3GSDI_COLOR_CINEMA:
        case eDATA_NODE_3GSDI_COLOR_BRIGHT:
        case eDATA_NODE_3GSDI_COLOR_ENHANCED:
        case eDATA_NODE_3GSDI_COLOR_REC709:
        case eDATA_NODE_3GSDI_COLOR_SRGB:
        case eDATA_NODE_3GSDI_COLOR_DICOMSIM:
        case eDATA_NODE_3GSDI_COLOR_BLENDING:
        case eDATA_NODE_3GSDI_COLOR_USER:
        case eDATA_NODE_3GSDI_COLOR_HDR:
        case eDATA_NODE_3GSDI_COLOR_3D:
        case eDATA_NODE_3GSDI_COLOR_SUPER_RED:
        case eDATA_NODE_3GSDI_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_HDBASET_COLOR_PRESENTATION:
        case eDATA_NODE_HDBASET_COLOR_CINEMA:
        case eDATA_NODE_HDBASET_COLOR_BRIGHT:
        case eDATA_NODE_HDBASET_COLOR_ENHANCED:
        case eDATA_NODE_HDBASET_COLOR_REC709:
        case eDATA_NODE_HDBASET_COLOR_SRGB:
        case eDATA_NODE_HDBASET_COLOR_DICOMSIM:
        case eDATA_NODE_HDBASET_COLOR_BLENDING:
        case eDATA_NODE_HDBASET_COLOR_USER:
        case eDATA_NODE_HDBASET_COLOR_HDR:
        case eDATA_NODE_HDBASET_COLOR_3D:
        case eDATA_NODE_HDBASET_COLOR_SUPER_RED:
        case eDATA_NODE_HDBASET_COLOR_2D_HIGH_SPEED:

        case eDATA_NODE_VGA_COLOR_USER_PRESENTATION:
        case eDATA_NODE_VGA_COLOR_USER_BRIGHT:
        case eDATA_NODE_VGA_COLOR_USER_CINEMA:
        case eDATA_NODE_VGA_COLOR_USER_HDR:
        case eDATA_NODE_VGA_COLOR_USER_SRGB:
        case eDATA_NODE_VGA_COLOR_USER_DICOMSIM:
        case eDATA_NODE_VGA_COLOR_USER_BLENDING:
        case eDATA_NODE_VGA_COLOR_USER_3D:
        case eDATA_NODE_VGA_COLOR_USER_USER:
        case eDATA_NODE_VGA_COLOR_USER_SUPER_RED:
        case eDATA_NODE_VGA_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_VGA_COLOR_USER_ENHANCED:

    	case eDATA_NODE_HDMI1_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDMI1_COLOR_USER_CINEMA:
        case eDATA_NODE_HDMI1_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDMI1_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDMI1_COLOR_USER_REC709:
        case eDATA_NODE_HDMI1_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDMI1_COLOR_USER_BLENDING:
        case eDATA_NODE_HDMI1_COLOR_USER_USER:
        case eDATA_NODE_HDMI1_COLOR_USER_HDR:
        case eDATA_NODE_HDMI1_COLOR_USER_3D:
        case eDATA_NODE_HDMI1_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_HDMI1_COLOR_USER_SRGB:
        case eDATA_NODE_HDMI1_COLOR_USER_SUPER_RED:

    	case eDATA_NODE_HDMI2_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDMI2_COLOR_USER_CINEMA:
        case eDATA_NODE_HDMI2_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDMI2_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDMI2_COLOR_USER_REC709:
        case eDATA_NODE_HDMI2_COLOR_USER_SRGB:
        case eDATA_NODE_HDMI2_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDMI2_COLOR_USER_BLENDING:
        case eDATA_NODE_HDMI2_COLOR_USER_USER:
        case eDATA_NODE_HDMI2_COLOR_USER_HDR:
        case eDATA_NODE_HDMI2_COLOR_USER_3D:
        case eDATA_NODE_HDMI2_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_HDMI2_COLOR_USER_SUPER_RED:

    	case eDATA_NODE_DVID_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_DVID_COLOR_USER_CINEMA:
        case eDATA_NODE_DVID_COLOR_USER_BRIGHT:
        case eDATA_NODE_DVID_COLOR_USER_ENHANCED:
        case eDATA_NODE_DVID_COLOR_USER_REC709:
        case eDATA_NODE_DVID_COLOR_USER_SRGB:
        case eDATA_NODE_DVID_COLOR_USER_DICOMSIM:
        case eDATA_NODE_DVID_COLOR_USER_BLENDING:
        case eDATA_NODE_DVID_COLOR_USER_USER:
        case eDATA_NODE_DVID_COLOR_USER_HDR:
        case eDATA_NODE_DVID_COLOR_USER_3D:
        case eDATA_NODE_DVID_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_DVID_COLOR_USER_SUPER_RED:

    	case eDATA_NODE_DP_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_DP_COLOR_USER_CINEMA:
        case eDATA_NODE_DP_COLOR_USER_BRIGHT:
        case eDATA_NODE_DP_COLOR_USER_ENHANCED:
        case eDATA_NODE_DP_COLOR_USER_REC709:
        case eDATA_NODE_DP_COLOR_USER_SRGB:
        case eDATA_NODE_DP_COLOR_USER_DICOMSIM:
        case eDATA_NODE_DP_COLOR_USER_BLENDING:
        case eDATA_NODE_DP_COLOR_USER_USER:
        case eDATA_NODE_DP_COLOR_USER_HDR:
        case eDATA_NODE_DP_COLOR_USER_3D:
        case eDATA_NODE_DP_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_DP_COLOR_USER_SUPER_RED:

    	case eDATA_NODE_3GSDI_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_3GSDI_COLOR_USER_CINEMA:
        case eDATA_NODE_3GSDI_COLOR_USER_BRIGHT:
        case eDATA_NODE_3GSDI_COLOR_USER_ENHANCED:
        case eDATA_NODE_3GSDI_COLOR_USER_REC709:
        case eDATA_NODE_3GSDI_COLOR_USER_SRGB:
        case eDATA_NODE_3GSDI_COLOR_USER_DICOMSIM:
        case eDATA_NODE_3GSDI_COLOR_USER_BLENDING:
        case eDATA_NODE_3GSDI_COLOR_USER_USER:
        case eDATA_NODE_3GSDI_COLOR_USER_HDR:
        case eDATA_NODE_3GSDI_COLOR_USER_3D:
        case eDATA_NODE_3GSDI_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_3GSDI_COLOR_USER_SUPER_RED:

    	case eDATA_NODE_HDBASET_COLOR_USER_PRESENTATION:
    	case eDATA_NODE_HDBASET_COLOR_USER_CINEMA:
        case eDATA_NODE_HDBASET_COLOR_USER_BRIGHT:
        case eDATA_NODE_HDBASET_COLOR_USER_ENHANCED:
        case eDATA_NODE_HDBASET_COLOR_USER_REC709:
        case eDATA_NODE_HDBASET_COLOR_USER_SRGB:
        case eDATA_NODE_HDBASET_COLOR_USER_DICOMSIM:
        case eDATA_NODE_HDBASET_COLOR_USER_BLENDING:
        case eDATA_NODE_HDBASET_COLOR_USER_USER:
        case eDATA_NODE_HDBASET_COLOR_USER_HDR:
        case eDATA_NODE_HDBASET_COLOR_USER_3D:
        case eDATA_NODE_HDBASET_COLOR_USER_2D_HIGH_SPEED:
        case eDATA_NODE_HDBASET_COLOR_USER_SUPER_RED:
            ulSize = eSCR_NUMBER;
            break;

        case eDATA_NODE_WAP_CALIBRATION_TAG:
        	ulSize = eWAP_TAG_NUMBERS;
        	break;

        case eDATA_NODE_WAP_PRESENTATION_RATIO:
        case eDATA_NODE_WAP_CINEMA_RATIO:
        case eDATA_NODE_WAP_BRIGHT_RATIO:
        case eDATA_NODE_WAP_ENHANCED_RATIO:
        case eDATA_NODE_WAP_REC709_RATIO:
        case eDATA_NODE_WAP_SRGB_RATIO:
        case eDATA_NODE_WAP_DICOM_RATIO:
        case eDATA_NODE_WAP_BLENDING_RATIO:
        case eDATA_NODE_WAP_USER_RATIO:
        case eDATA_NODE_WAP_HDR_RATIO:
        case eDATA_NODE_WAP_3D_RATIO:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_RATIO:
        case eDATA_NODE_WAP_SUPER_RED_RATIO:
        case eDATA_NODE_WAP_SUPER_BRIGHT_RATIO:

        case eDATA_NODE_WAP_PRESENTATION_OFFSET:
        case eDATA_NODE_WAP_CINEMA_OFFSET:
        case eDATA_NODE_WAP_BRIGHT_OFFSET:
        case eDATA_NODE_WAP_ENHANCED_OFFSET:
        case eDATA_NODE_WAP_REC709_OFFSET:
        case eDATA_NODE_WAP_SRGB_OFFSET:
        case eDATA_NODE_WAP_DICOM_OFFSET:
        case eDATA_NODE_WAP_BLENDING_OFFSET:
        case eDATA_NODE_WAP_USER_OFFSET:
        case eDATA_NODE_WAP_HDR_OFFSET:
        case eDATA_NODE_WAP_3D_OFFSET:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_OFFSET:
        case eDATA_NODE_WAP_SUPER_RED_OFFSET:
        case eDATA_NODE_WAP_SUPER_BRIGHT_OFFSET:

        case eDATA_NODE_WAP_PRESENTATION_PWM:
        case eDATA_NODE_WAP_CINEMA_PWM:
        case eDATA_NODE_WAP_BRIGHT_PWM:
        case eDATA_NODE_WAP_ENHANCED_PWM:
        case eDATA_NODE_WAP_REC709_PWM:
        case eDATA_NODE_WAP_SRGB_PWM:
        case eDATA_NODE_WAP_DICOM_PWM:
        case eDATA_NODE_WAP_BLENDING_PWM:
        case eDATA_NODE_WAP_USER_PWM:
        case eDATA_NODE_WAP_HDR_PWM:
        case eDATA_NODE_WAP_3D_PWM:
        case eDATA_NODE_WAP_2D_HIGH_SPEED_PWM:
        case eDATA_NODE_WAP_SUPER_RED_PWM:
        case eDATA_NODE_WAP_SUPER_BRIGHT_PWM:
        	 ulSize = eWAP_LD_SEG_NUMBERS;
         	 break;

#if (ENABLE_COLOR_UNIFORMITY == TRUE) //A35G2_CDS_Coda_0029
        case eDATA_NODE_ACU:   //A65_OPTOMA_Jerry_0005  start // A35G2_CDS_Coda_0028
             ulSize = eACU_NUMBERS;
             break;
#endif

		case eDATA_NODE_PROSERVICE:
			ulSize = ePROSERVICE_NUMBERS;
			break;

        default:
            break;
    }

    return ulSize;
}

void utilDataMgr_NodeUpdateFlag(eDATA_NODE eNode)
{
    UINT16 cCount = 0;

    if(eNode < eDATA_NODE_HDMI1_COMMON)
    {
        for(cCount = 0;  cCount < DATA_NODE_NUMBER; cCount++)
        {
            if(m_sDataNodeCtrl[cCount].uiNode == eNode)
            {
                m_sDataNodeCtrl[cCount].cFlag = TRUE;
                break;
            }
        }

        ASSERT(cCount < DATA_NODE_NUMBER);
    }
    else if((eNode >=eDATA_NODE_HDMI1_COMMON) && (eNode < eDATA_NODE_NUMBER))
    {
        for(cCount = 0;  cCount < SOURCE_DATA_NODE_NUMBER; cCount++)
        {
            if(m_sSourceDataNodeCtrl[cCount].uiNode == eNode)
            {
                m_sSourceDataNodeCtrl[cCount].cFlag = TRUE;
                break;
            }
        }

        ASSERT(cCount < SOURCE_DATA_NODE_NUMBER);
    }
    else
    {
        ASSERT_ALWAYS();
    }

}

#if 0
UINT8 utilDataMgr_CommonSet(UINT16 uiIndex, UINT8 *pcData)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        sPARA_FORMAT *psPara = NULL;
        UINT16 uiNode = eDATA_NODE_NUMBER;

        //LOG_MSG(db_ALWAYS, "(func:%s, line:%d) %d\r\n", __FUNCTION__, __LINE__, uiIndex);

        switch(uiIndex)
        {
#if 0
//Data Mgr版號@appDataMgr.h，一般狀態下不會access
//utilDataMgr_RAMToFileProjectorInfo會寫入
            case eDF_MAJOR:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[ePI_UCMAJOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MINOR:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[ePI_UCMINOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SUBMINOR:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[ePI_UCSUBMINOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
#endif /* 0 */

            case eDF_MODELNAME:
                {
                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[ePI_UCMODELNAME].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CUSTOM_CODE:
                {
                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[ePI_UCCUSTOM_CODE].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERIALNUMBER:
                {
                    uiNode = eDATA_NODE_PROJECTORINFO;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[ePI_UCSERIALNUMBER].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET2_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET2_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET2_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET2_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET2_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET2_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET2_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET2_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBOFFSET2_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBOFFSET2_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVOFFSET2_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVOFFSET2_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN2_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN2_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN2_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN2_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_RGBGAIN2_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIRGBGAIN2_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN2_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN2_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN2_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN2_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_YUVGAIN2_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIYUVGAIN2_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FWINDEX_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIFWINDEX_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FWINDEX_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIFWINDEX_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PWINDEX_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIPWINDEX_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PWINDEX_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UIPWINDEX_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_POWER_OFFSET:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCPOWER_OFFSET].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_COLOR_OFFSET:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCCOLOR_OFFSET].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_ABP_CALIBRATEFLAG:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCABP_CALIBRATEFLAG].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_BLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_BLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_BLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_BLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_BLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_BLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_BLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_BLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_BLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_BLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_BLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_BLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_BLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_BLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_BLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_BLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_RLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_RLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_RLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORFULL_RLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_RLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_RLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_RLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORECO_RLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTSENSORECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_RLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_RLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_RLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMFULL_RLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMFULL_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_RLD_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_RLD_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_RLD_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTPWMECO_RLD_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_Y].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_R].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_B].cParaValue, "%d", data);

                    data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eSC_UILIGHTPWMECO_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTIME_Y:		//A65_OPTOMA_Doulas_0105
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORTIME_Y].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTIME_R:		//A65_OPTOMA_Doulas_0105
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORTIME_R].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTIME_B:		//A65_OPTOMA_Doulas_0105
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORTIME_B].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTIME_G:		//A65_OPTOMA_Doulas_0105
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORTIME_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_Y:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_Y].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_R:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_R].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_B:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_B].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_G:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_RY:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_RY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORTARGET_RR:	//A65_OPTOMA_Doulas_0105
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UILIGHTSENSORTARGET_RR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORGAIN_Y:
                {
                    float data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((float *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORGAIN_Y].cParaValue, "%f", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORGAIN_R:
                {
                    float data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((float *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORGAIN_R].cParaValue, "%f", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORGAIN_B:
                {
                    float data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((float *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORGAIN_B].cParaValue, "%f", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSORGAIN_G:
                {
                    float data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((float *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSORGAIN_G].cParaValue, "%f", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSOROFFSET_Y:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSOROFFSET_Y].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSOROFFSET_R:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSOROFFSET_R].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSOROFFSET_B:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSOROFFSET_B].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSENSOROFFSET_G:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_UCLIGHTSENSOROFFSET_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_UST_SET: //A35G2_BRC_Casper_0089
				{
					UINT8 data;

					uiNode = eDATA_NODE_SYSTEMCAL;
					psPara = utilDataMgr_ParaTableGet(uiNode);

					data= *((UINT8 *)pcData);
					sprintf(psPara[eSC_UCUST].cParaValue, "%d", data);

					utilDataMgr_NodeUpdateFlag(uiNode);
				}
				break;

            case eDF_BURNINENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eBI_URNINENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LAMPON:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eBI_UCLAMPON].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LAMPOFF:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eBI_UCLAMPOFF].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BURNINCYCLE:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eBI_UIBURNINCYCLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BURNINMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eBI_UCBURNINMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BURNINALWAYSON:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_BURNIN;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eBI_UCBURNINALWAYSON].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FIRSTSTARTUPFLAG:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSU_UCFIRSTSTARTUPFLAG].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_USTFIRSTSTARTUP:
            {
                UINT8 data;

                uiNode = eDATA_NODE_STARTUP;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eSU_UCUSTFIRSTSTARTUP].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_PINPROTECT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSU_UCPINPROTECT].cParaValue, "%d", data);	//G100_Doulas_0054 Modify index error

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PASSWORD_0:	//G100_Doulas_0005 Modify
                {
                    //UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    //data= *((UINT8 *)pcData);
                    //sprintf(psPara[eSU_UCPASSWORD_0].cParaValue, "%d", data);
                    strncpy(psPara[eSU_UCPASSWORD_0].cParaValue, pcData, 1);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PASSWORD_1:	//G100_Doulas_0005 Modify
                {
                    //UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    //data= *((UINT8 *)pcData);
                    //sprintf(psPara[eSU_UCPASSWORD_1].cParaValue, "%d", data);
                    strncpy(psPara[eSU_UCPASSWORD_1].cParaValue, pcData, 1);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PASSWORD_2:	//G100_Doulas_0005 Modify
                {
                    //UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    //data= *((UINT8 *)pcData);
                    //sprintf(psPara[eSU_UCPASSWORD_2].cParaValue, "%d", data);
					strncpy(psPara[eSU_UCPASSWORD_2].cParaValue, pcData, 1);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PASSWORD_3:	//G100_Doulas_0005 Modify
                {
                    //UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    //data= *((UINT8 *)pcData);
                    //sprintf(psPara[eSU_UCPASSWORD_3].cParaValue, "%d", data);
					strncpy(psPara[eSU_UCPASSWORD_3].cParaValue, pcData, 1);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PASSWORD_4:	//G100_Doulas_0005 Modify
                {
                    //UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    //data= *((UINT8 *)pcData);
                    //sprintf(psPara[eSU_UCPASSWORD_4].cParaValue, "%d", data);
					strncpy(psPara[eSU_UCPASSWORD_4].cParaValue, pcData, 1);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_OPFU_CHECK:    //G100_Simon_0064
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_STARTUP;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eSU_OPFU_CHECK].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_TOTALPROJECTORMINUTE:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULTOTALPROJECTORMINUTE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOURCEMINUTE_B:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTE_B].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOURCEMINUTE_R:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTE_R].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSTYPE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSTYPE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DBMASK:
                {
                    UINT64 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT64 *)pcData);
                    sprintf(psPara[eCG_ULDBMASK].cParaValue, "%llu", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PANEL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPANEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_POWERMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPOWERMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WAVEFORMGAIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCWAVEFORMGAIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRWAVEFORMGAIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRWAVEFORMGAIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRMODE_WAVEFORMGAIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRMODE_WAVEFORMGAIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRMODE_IRWAVEFORMGAIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRMODE_IRWAVEFORMGAIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRLD:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRLD].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRBLD:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRBLD].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTCALIBRATIONMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLIGHTCALIBRATIONMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MENULOCATION:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMENULOCATION].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_OSDTRANSLUCENCY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCOSDTRANSLUCENCY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_OSDTIMEOUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCOSDTIMEOUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SHOWMESSAGES:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSHOWMESSAGES].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MENUOFFSETX:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMENUOFFSETX].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MENUOFFSETY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMENUOFFSETY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MENULOCKOUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMENULOCKOUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MENUTRANSPARENCY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMENUTRANSPARENCY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SEARCHSCREEN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSEARCHSCREEN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SHOWNETWORKMESSAGES:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSHOWNETWORKMESSAGES].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DHCP:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDHCP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HSGADJUSTMENTENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHSGADJUSTMENTENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HSGADJUSTMENTAUTOTESTPATTERN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HSGSELECTED:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCHSGSELECTED].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_EQMode_HDMI1:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCEQMODE_HDMI1].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_EQMode_HDMI2:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCEQMODE_HDMI2].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_EQMode_DVI:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCEQMODE_DVI].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_BLANKONSIGNALSWITCH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCBLANKONSIGNALSWITCH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SYNCTHRESHOLD:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSYNCTHRESHOLD].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_HDMI_OUT:			//G100_Doulas_0057
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHDMI_OUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_TEC_GATING_CNT: //G100_Steven_0084 start
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CNT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE0:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE0].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE1:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE1].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE2:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE2].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE3:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE3].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE4:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE4].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE5:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE5].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE6:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE6].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE7:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE7].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE8:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE8].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

			case eDF_TEC_GATING_CYCLE9:
            {
                UINT8 data;

                uiNode = eDATA_NODE_TEC_GATING_INFO;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eTEC_GATING_CYCLE9].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CONTRASTENHANCEMENT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCONTRASTENHANCEMENT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_3:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_3].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_4:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_4].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_5:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_5].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_6:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_6].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_7:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_7].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_8:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_8].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_9:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_9].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_10:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_10].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_11:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_11].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_12:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_12].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_13:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_13].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_14:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_14].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DFRAME_DELAY_TIMING_15:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DFRAME_DELAY_TIMING_15].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FILM:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFILM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WALLCOLOR:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCWALLCOLOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IMAGEFREEZE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIMAGEFREEZE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CEILINGMOUNT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCEILINGMOUNT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_REARPROJECT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCREARPROJECT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOUTTIMER:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLIGHTSOUTTIMER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOUTSIGNALLEVEL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLIGHTSOUTSIGNALLEVEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTS_ON_THRESHOLD:		//A70Gen2_Doulas_0044
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLIGHTS_ON_THRESHOLD].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_COMPATIBLE_4K:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCOMPATIBLE_4K].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HDMI_EDID_1:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCHDMI_EDID_1].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_HDMI_EDID_2:
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCHDMI_EDID_2].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_HDBaseT_EDID: //G100_Steven_0005
            {
                UINT8 data;

                uiNode = eDATA_NODE_COMMONGUI;
                psPara = utilDataMgr_ParaTableGet(uiNode);

                data= *((UINT8 *)pcData);
                sprintf(psPara[eCG_UCHDBaseT_EDID].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

            case eDF_HDRENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHDRENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HDRLEVEL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHDRLEVEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CW_SPEED:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCW_SPEED].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DBSPEED:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDBSPEED].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DBSPEED_CONTROL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDBSPEED_CONTROL].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_DBSTRENGTH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDBSTRENGTH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DBLIGHTLEVEL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDBLIGHTLEVEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_DBREALBLACKENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCDBREALBLACKENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LANGUAGE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLANGUAGE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_ACPOWERON:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCACPOWERON].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_STANDBYPOWERSAVE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSTANDBYPOWERSAVE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PROJECTORADDRESS:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPROJECTORADDRESS].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PROJECTORID:
	            {
	                UINT8 data;

	                uiNode = eDATA_NODE_COMMONGUI;
	                psPara = utilDataMgr_ParaTableGet(uiNode);

	                data= *((UINT8 *)pcData);
	                sprintf(psPara[eCG_UCPROJECTORID].cParaValue, "%d", data);

	                utilDataMgr_NodeUpdateFlag(uiNode);
	            }
	            break;

            case eDF_KEYPADBACKLIGHT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCKEYPADBACKLIGHT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_STATUSLED:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSTATUSLED].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_AUTOOFFTIME:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCAUTOOFFTIME].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SCREENSAVETIME:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSCREENSAVETIME].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SLEEPTIMER:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSLEEPTIMER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CHANGEPIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCHANGEPIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERIALPORTBAUDRATE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSERIALPORTBAUDRATE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERIALPORTECHO:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSERIALPORTECHO].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERIALPORTPATH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSERIALPORTPATH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRCONTROL_TOP:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRCONTROL_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRCONTROL_FRONT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRCONTROL_FRONT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_IRCONTROL_HDBASET:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCIRCONTROL_HDBASET].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HDBASETENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHDBASETENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SYSERRCODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSYSERRCODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_12VTRIGGE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UC12VTRIGGE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSADJUST:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSADJUST].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSSHIFT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSSHIFT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSMEMORYAPPLY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSMEMORYAPPLY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSMEMORYSAVE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSMEMORYSAVE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_HIGHALTITUDE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHIGHALTITUDE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FACTORYTESTPATTERN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFACTORYTESTPATTERN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERVICEMENUTESTPATTERN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSERVICEMENUTESTPATTERN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FACTORYMENUCUSTOMPATTERN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFACTORYMENUCUSTOMPATTERN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SPLASHSTARTUPENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSPLASHSTARTUPENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_ACTUATORSWITCH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCACTUATORSWITCH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_COOLINGDOWN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCOOLINGDOWN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_OSDTESTPATTERN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCOSDTESTPATTERN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_UARTSWITCH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCUARTSWITCH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BACKUPRESTORESAVE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCBACKUPRESTORESAVE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BACKUPRESTORERESTORE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCBACKUPRESTORERESTORE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LENSDETECTION:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSDETECTION].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LOWLATENCY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLOWLATENCY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BACKUP_INPUT_SWITCH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_BACKUP_INPUT_SWITCH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;


            case eDF_BACKUP_PRIMARY_INPUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_BACKUP_PRIMARY_INPUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BACKUP_SECONDARY_INPUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_BACKUP_SECONDARY_INPUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BACKGROUND_COLOR:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_BACKGROUND_COLOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SIGNAL_POWERON:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_SIGNAL_POWERON].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SECURITY_TOTALREMAINMIN:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eCG_SECURITY_TOTALREMAINMIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_INPUTSOURCEMAIN:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCINPUTSOURCEMAIN].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_INPUTSOURCESUB:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCINPUTSOURCESUB].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PIPENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPIPENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MAINLAYOUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCMAINLAYOUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PIPLAYOUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPIPLAYOUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PBPLAYOUT:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPBPLAYOUT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PIPSIZE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPIPSIZE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SOURCEKEYOPTION:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSOURCEKEYOPTION].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SOURCEINFO:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UISOURCEINFO].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_POWERUPSOURCE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPOWERUPSOURCE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SOURCELOCK:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSOURCELOCK].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CUSTOMKEY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCUSTOMKEY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            //G100_Wilsonj_0053 Start
            case eDF_CUSTOMKEY2:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCUSTOMKEY2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
            //G100_Wilsonj_0053 End

            case eDF_BLANKKEY:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCBLANKKEY].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SOURCEHOTKEYENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSOURCEHOTKEYENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_STARTUP_SHUTTER:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_STARTUP_SHUTTER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_AUTO_SOURCE_RESYNC:		//G100_Doulas_0006
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_AUTO_SOURCE_RESYNC].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_CONSTANT_BRIGHTNESS:		//G100_Doulas_0008
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_CONSTANT_BRIGHTNESS].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_SERIALPORTOUT_BAUDRATE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCSERIALPORTOUT_BAUDRATE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FADEIN_TIME:       //G100_Owen_0023
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFADEIN_TIME].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_FADEOUT_TIME:      //G100_Owen_0023
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFADEOUT_TIME].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_PWRKEYBACKLIGHT:   //G100_Owen_0024
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCPWRKEYBACKLIGHT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_CONTROL:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_CONTROL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_GRIDPOINTS:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_GRIDPOINTS].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_INNER:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_INNER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_SHARPNESS:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_SHARPNESS].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_GRIDCOLOR:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_GRIDCOLOR].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_WARP_GRIDBACKGROUND:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_GRIDBACKGROUND].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_OVERLAP_GRIDNUMBER:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLEND_OVERLAP_GRIDNUMBER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_GAMMA:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLEND_GAMMA].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_LEFT:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UIADV_BLEND_LEFT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_RIGHT:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UIADV_BLEND_RIGHT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_TOP:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UIADV_BLEND_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLEND_BOTTOM:		//G100_Doulas_0027
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UIADV_BLEND_BOTTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            //G100_Tim_0055, add, start//A35G2_BRC_Casper_0051
			case eDF_ADV_WARP_INNER_LAST_VALUE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_WARP_INNER_LAST_VALUE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
            //G100_Tim_0055, add, end
				case eDF_ADV_BLACK_LEVEL_AREA:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_AREA].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_ENABLE_TOP:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_ENABLE_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_ENABLE_BOTTOM:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_ENABLE_BOTTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_RED_TOP:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_RED_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_RED_BOTTOM:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_RED_BOTTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_GREEN_TOP:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_GREEN_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_GREEN_BOTTOM:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_GREEN_BOTTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_BLUE_TOP:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_BLUE_TOP].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_ADV_BLACK_LEVEL_BLUE_BOTTOM:		//A65_OPTOMA_Doulas_0020
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCADV_BLACK_LEVEL_BLUE_BOTTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPHORZKEYSTONE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);

                    sprintf(psPara[eWI_UCWARPHORZKEYSTONE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPVERTKEYSTONE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPVERTKEYSTONE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPHORZPINCUSHION:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPHORZPINCUSHION].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPVERTPINCUSHION:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPVERTPINCUSHION].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPPINCUSHIONBARREL:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPPINCUSHIONBARREL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_GEOMETRYPCMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCGEOMETRYPCMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERTOPLEFTHORZ:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERTOPLEFTHORZ].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERTOPLEFTVERT:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERTOPLEFTVERT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERTOPRIGHTHORZ:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERTOPRIGHTHORZ].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERTOPRIGHTVERT:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERTOPRIGHTVERT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERBOTTOMLEFTHORZ:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERBOTTOMLEFTHORZ].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERBOTTOMLEFTVERT:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERBOTTOMLEFTVERT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERBOTTOMRIGHTHORZ:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERBOTTOMRIGHTHORZ].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_4CORNERBOTTOMRIGHTVERT:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UI4CORNERBOTTOMRIGHTVERT].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPAUTOFILTER:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPAUTOFILTER].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPFILTERH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPFILTERH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPFILTERV:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPFILTERV].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_MOVEPITCHMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCMOVEPITCHMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGTOPENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDINGTOPENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGTOPSTARTPIXEL:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGTOPSTARTPIXEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGTOPPIXELWIDTH:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGTOPPIXELWIDTH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGBOTTOMENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDINGBOTTOMENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGBOTTOMSTARTPIXEL:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGBOTTOMSTARTPIXEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGBOTTOMPIXELWIDTH:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGBOTTOMPIXELWIDTH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGLEFTENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDINGLEFTENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGLEFTSTARTPIXEL:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGLEFTSTARTPIXEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGLEFTPIXELWIDTH:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGLEFTPIXELWIDTH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGRIGHTENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDINGRIGHTENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGRIGHTSTARTPIXEL:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGRIGHTSTARTPIXEL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGRIGHTPIXELWIDTH:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eWI_UIBLENDINGRIGHTPIXELWIDTH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_AUTOADJUSTMENTMODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCAUTOADJUSTMENTMODE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLYSETTING:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLYSETTING].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGSAVESETTING:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGSAVESETTING].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGLASTSAVED:  //A35G2_CDS_Simon_0008
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGLASTSAVED].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLYSETTING:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLYSETTING].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDSAVESETTING:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDSAVESETTING].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDLASTSAVED:  //A35G2_CDS_Simon_0008
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDLASTSAVED].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGGAMMA:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDINGGAMMA].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLY_0:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLY_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGNAME_0:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCWARPINGNAME_0].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLY_0:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLY_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGNAME_0:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCBLENDINGNAME_0].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLY_1:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLY_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGNAME_1:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCWARPINGNAME_1].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLY_1:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLY_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGNAME_1:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCBLENDINGNAME_1].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLY_2:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLY_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGNAME_2:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCWARPINGNAME_2].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLY_2:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLY_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGNAME_2:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCBLENDINGNAME_2].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLY_3:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLY_3].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGNAME_3:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCWARPINGNAME_3].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLY_3:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLY_3].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGNAME_3:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCBLENDINGNAME_3].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGAPPLY_4:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCWARPINGAPPLY_4].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_WARPINGNAME_4:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCWARPINGNAME_4].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDAPPLY_4:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCBLENDAPPLY_4].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_BLENDINGNAME_4:
                {
                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    sprintf(psPara[eWI_UCBLENDINGNAME_4].cParaValue, "%s", pcData);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_INTENSITYPWM_BLD_Y:		//G100_Doulas_0010
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UIINTENSITYPWM_BLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UIINTENSITYPWM_BLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UIINTENSITYPWM_BLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UIINTENSITYPWM_BLD_G].cParaValue, "%d", data);


					data= *((UINT16 *)(pcData+8));
                    sprintf(psPara[eAB_UIINTENSITYPWM_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+10));
                    sprintf(psPara[eAB_UIINTENSITYPWM_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+12));
                    sprintf(psPara[eAB_UIINTENSITYPWM_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+14));
                    sprintf(psPara[eAB_UIINTENSITYPWM_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTSENSORINTENSITY_BLD_Y:		//G100_Doulas_0010
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_BLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_BLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_BLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_BLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTSENSORINTENSITY_RLD_Y:		//G100_Doulas_0010
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTSENSORINTENSITY_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTSENSORFULL_DYNAMIC_RLD_Y:		//G100_Doulas_0023
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTSENSORECO_DYNAMIC_RLD_Y:		//G100_Doulas_0023
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTFULL_PWM_DYNAMIC_RLD_Y:		//G100_Doulas_0023
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_LIGHTECO_PWM_DYNAMIC_RLD_Y:		//G100_Doulas_0023
				{
                    UINT16 data;

                    uiNode = eDATA_NODE_AUTOBRIGHTNESS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_Y].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+2));
                    sprintf(psPara[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_R].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+4));
                    sprintf(psPara[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_B].cParaValue, "%d", data);
					data= *((UINT16 *)(pcData+6));
                    sprintf(psPara[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_G].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOURCEMINUTENORMAL: //G100_Larry_0006
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTENORMAL].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOURCEMINUTEECO: //G100_Larry_0006
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTEECO].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;


            case eDF_LIGHTSOURCEMINUTEQUIET: //G100_Larry_0006
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTEQUIET].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LIGHTSOURCEMINUTECUSTOM: //G100_Larry_0006
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_SYSTEMHOURS;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eSH_ULLIGHTSOURCEMINUTECUSTOM].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_CRESTRON_ENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCCRESTRON_ENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_LOGOCHANGE:   //G100_Owen_0048
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLOGOCHANGE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			//G100_Clare_0055, add, >>>
            case eDF_FAST_POWER_ON:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCFAST_POWER_ON].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
				//G100_Clare_0055, add, <<<

            case eDF_LENS_CALIBRATION_STATUS: //R70G2_AC_0032 //R70K_AC_0009
#if 0
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_SYSTEMCAL;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eSC_LENS_CALIBRATION_STATUS].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
#endif /* 0 */
                break;

            case eDF_HSGADJUSTMENTAUTOTESTPATTERN_2:	//G100_Coda_00109
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            //G100_Tim_0057, add, start //A35G2_BRC_Casper_0060
            case eDF_AUTO_HDMI_SWITCH:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_AUTO_HDMI_SWITCH].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_INPUT_KEY_LAST_VALUE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_INPUT_KEY_LAST_VALUE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3D_MODE_LAST_VALUE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_3D_MODE_LAST_VALUE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
            //G100_Tim_0057, add, end

            //G100_Tim_0058, add, start //A35G2_BRC_Casper_0060
            case eDF_PROJ_NATIVE_TIMING:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_PROJ_NATIVE_TIMING].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;
            //G100_Tim_0058, add, end
			case eDF_CUSTOM_REGION: //A65_OPTOMA_Doulas_0027
                {
					UINT8 data;

                    uiNode = eDATA_NODE_PROJECTORINFO;				//A65_OPTOMA_Doulas_0033 Modify
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[ePI_CUSTOM_REGION].cParaValue, "%d", data);	//A65_OPTOMA_Doulas_0033 Modify

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			case eDF_CUSTOM_DEFAULT_LOGO: //A65_OPTOMA_Doulas_0027
                {
					UINT8 data;

                    uiNode = eDATA_NODE_PROJECTORINFO;				//A65_OPTOMA_Doulas_0033 Modify
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[ePI_CUSTOM_DEFAULT_LOGO].cParaValue, "%d", data);	//A65_OPTOMA_Doulas_0033 Modify

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

#if (ENABLE_COLOR_UNIFORMITY == TRUE)               //G100_Tim_0012, add, start
            case eDF_ACU_FILE_VALID:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_ACU;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eACU_FILE_VALID].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACU_DISPLAY_MODE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_ACU;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eACU_DISPLAY_MODE].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACU_TARGET_SELECT: //G100_Tim_0048, add, start
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_ACU;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eACU_TARGET_SELECT].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;                  //G100_Tim_0048, add, end
#endif //ENABLE_COLOR_UNIFORMITY                    //G100_Tim_0012, add, end

			case eDF_ACU_DATA_ENABLE: //A35G2_Alan_0007
				{
					UINT8 data;

					uiNode = eDATA_NODE_ACU;
					psPara = utilDataMgr_ParaTableGet(uiNode);

					data= *((UINT8 *)pcData);
					sprintf(psPara[eACU_DATA_ENABLE].cParaValue, "%d", data);

					m_sDataNodeCtrl[uiNode].cFlag = 1;
				}
				break;

			case eDF_MODEL_SWITCH_ADJUST: //A65_OPTOMA_Julie_0064
				{
					UINT8 data;
					uiNode = eDATA_NODE_PROJECTORINFO;
					psPara = utilDataMgr_ParaTableGet(uiNode);

					data= *((UINT8 *)pcData);
					sprintf(psPara[ePI_UCMODEL_SWITCH].cParaValue, "%d", data);

					utilDataMgr_NodeUpdateFlag(uiNode);
				}
				break;

            case eDF_GEOMETRYENABLE:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_WARPING;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eWI_UCGEOMETRYENABLE].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_0].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_1].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_2:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_2].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_3:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_3].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_4:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_4].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_5:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_5].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_6:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_6].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_7:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_7].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_8:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_8].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_9:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_9].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_10:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_10].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_11:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_11].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_12:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_12].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_13:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_13].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_14:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_14].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

            case eDF_3DSYNC_DELAY_TIMING_15:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eCG_UI3DSYNC_DELAY_TIMING_15].cParaValue, "%d", data);

                    utilDataMgr_NodeUpdateFlag(uiNode);
                }
                break;

			 case eDF_AUDIO_VOLUME:// R70K_Bruce_0002
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCAUDIO_VOLUME].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_AUDIO_MUTE:// R70K_Bruce_0002
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCAUDIO_MUTE].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_DAC_AWC0:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eACT_DAC_AWC0].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_SFDELAY_AWC0:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eACT_SFDELAY_AWC0].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_SEGMENTLEN_AWC0:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eACT_SEGMENTLEN_AWC0].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_DAC_AWC1:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eACT_DAC_AWC1].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_SFDELAY_AWC1:
                {
                    UINT32 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT32 *)pcData);
                    sprintf(psPara[eACT_SFDELAY_AWC1].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_ACTUATOR_SEGMENTLEN_AWC1:
                {
                    UINT16 data;

                    uiNode = eDATA_NODE_ACTUATOR;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT16 *)pcData);
                    sprintf(psPara[eACT_SEGMENTLEN_AWC1].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
                break;

            case eDF_UST_LENS_SPEED:
                {
                    UINT8 data;

                    uiNode = eDATA_NODE_COMMONGUI;
                    psPara = utilDataMgr_ParaTableGet(uiNode);

                    data= *((UINT8 *)pcData);
                    sprintf(psPara[eCG_UCLENSPEED].cParaValue, "%d", data);

                    m_sDataNodeCtrl[uiNode].cFlag = 1;
                }
            	break;

            case eDF_CUSTOMEDID_HDMI1_STATUS: //A35G2_Simon_0091
				{
					UINT8 data;
					uiNode = eDATA_NODE_COMMONGUI;
					psPara = utilDataMgr_ParaTableGet(uiNode);

					data= *((UINT8 *)pcData);
					sprintf(psPara[eCG_CUSTOMEDID_HDMI1_STATUS].cParaValue, "%d", data);

					m_sDataNodeCtrl[uiNode].cFlag = 1;
				}
				break;

			case eDF_CUSTOMEDID_HDMI2_STATUS: //A35G2_Simon_0091
				{
					UINT8 data;
					uiNode = eDATA_NODE_COMMONGUI;
					psPara = utilDataMgr_ParaTableGet(uiNode);

					data= *((UINT8 *)pcData);
					sprintf(psPara[eCG_CUSTOMEDID_HDMI2_STATUS].cParaValue, "%d", data);

					m_sDataNodeCtrl[uiNode].cFlag = 1;
				}
				break;

            default:
                LOG_MSG(db_ALWAYS, "(func:%s, line:%d)uiIndex %d not found\r\n", __FUNCTION__, __LINE__, uiIndex);
                break;
        }

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}
#endif

UINT8 utilDataMgr_SourceParaSet(UINT16 uiIndex, UINT16 uiNode, sPARA_FORMAT *psPara, UINT8 *pcData)
{
    switch(uiIndex)
    {
        case eDFS_SOURCENAME:
            {
                sprintf(psPara[eSCM_CSOURCENAME].cParaValue, "%s", pcData);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_ASPECTRATIO:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCASPECTRATIO].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_ASPECTRATIO_ADD219:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCASPECTRATIO219].cParaValue, "%d", data);// x35G2_Bruce_0004

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_OVERSCAN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCOVERSCAN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_PHASE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCPHASE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_TRACKING:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCTRACKING].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HORZPOSITION:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCHORZPOSITION].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_VERTPOSITION:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCVERTPOSITION].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_DIGITALHORZZOOM:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UIDIGITALHORZZOOM].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_DIGITALVERTZOOM:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UIDIGITALVERTZOOM].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_DIGITALHORZSHIFT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UIDIGITALHORZSHIFT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_DIGITALVERTSHIFT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UIDIGITALVERTSHIFT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_CUSTOMDIGITALHORZZOOM:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UICUSTOMDIGITALHORZZOOM].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_CUSTOMDIGITALVERTZOOM:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UICUSTOMDIGITALVERTZOOM].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_CUSTOMDIGITALHORZSHIFT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UICUSTOMDIGITALHORZSHIFT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_CUSTOMDIGITALVERTSHIFT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UICUSTOMDIGITALVERTSHIFT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_PRESETMODE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCPRESETMODE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_BACKUPPRESET:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCBACKUPPRESET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_SAVEPRESET:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UCSAVEPRESET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_PREUSERMODE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCPREUSERMODE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_ENABLE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_ENABLE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_INVERT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_INVERT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_SYNCOUT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_SYNCOUT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_SYNCIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_SYNCIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_REFERENCE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_REFERENCE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_2D:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_2D_VIEW].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_EDGEMASK:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCEDGEMASK].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_MODE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_MODE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_3D_TECH:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UC3D_TECH].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_AUTOIMAGE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCM_UCAUTOIMAGE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_DIGITALZOOMPROP:
            {
                UINT16 data;
                data= *((UINT16 *)pcData);
                sprintf(psPara[eSCM_UCDIGITALZOOMPROP].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_R_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_R_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_R_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_R_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_R_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_R_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_G_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_G_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_G_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_G_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_G_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_G_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_B_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_B_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_B_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_B_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_B_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_B_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_C_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_C_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_C_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_C_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_C_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_C_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_M_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_M_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_M_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_M_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_M_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_M_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_Y_HUE:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_Y_HUE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_Y_SAT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_Y_SAT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_Y_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_Y_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_W_R_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_W_R_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_W_G_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_W_G_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_HSG_W_B_GAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eHSG_W_B_GAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_CS:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCCS].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_CT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCCT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_GAMMA:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCGAMMA].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_BRILLIENTCOLOR:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_WHITEPEAKING:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCWHITEPEAKING].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_COLORENHANCEMENT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

#if 0
        case eDFS_COLOR_CWSPEED:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCCWSPEED].cParaValue, "%d", data);

                psNode[uiNode].cFlag = 1;
            }
            break;
#endif /* 0 */

        case eDFS_COLOR_SKINCOLOR:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCSKINCOLOR].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_SHARPNESS:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCSHARPNESS].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_BRIGHTNESS:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCBRIGHTNESS].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_CONTRAST:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCCONTRAST].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_TINT:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCTINT].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_SATURATION:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCSATURATION].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_REDGAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCREDGAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_GREENGAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCGREENGAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_BLUEGAIN:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCBLUEGAIN].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_REDOFFSET:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCREDOFFSET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_GREENOFFSET:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCGREENOFFSET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_COLOR_BLUEOFFSET:
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCBLUEOFFSET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        case eDFS_WALL_COLORSET:  //G100_Steven_0047
            {
                UINT8 data;
                data= *((UINT8 *)pcData);
                sprintf(psPara[eSCR_UCWALLCOLORSET].cParaValue, "%d", data);

                utilDataMgr_NodeUpdateFlag(uiNode);
            }
            break;

        default:
            return DATA_MGR_FAIL;
    }

    return DATA_MGR_PASS;
}

#if 0
UINT8 utilDataMgr_SourceColorSet(UINT16 uiIndex, UINT8 cSource, UINT8 cPictureMode, UINT8 *pcData)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        sPARA_FORMAT *psPara = NULL;
        sDATA_NODE_CTRL *psNode = m_sSourceDataNodeCtrl;
        UINT16 uiNode = eDATA_NODE_NUMBER;
        UINT16 cCount = 0;
        UINT16 uiSourceNode = 0;

        //LOG_MSG(db_ALWAYS, "(func:%s, line:%d) %d\r\n", __FUNCTION__, __LINE__, uiIndex);

        if(cSource >= eGUI_SOURCE_ID_NUMBER || cPictureMode >= eGUI_PICTURE_SETTINGS_NUMBER)
        {
            LOG_MSG(db_HAL_EEP, "\n%s fail %d %d %d \n", __FUNCTION__ , uiIndex, cSource, cPictureMode);
            utilDataMgr_MutexGive(__FUNCTION__);
            return DATA_MGR_OVER_RANGE;
        }

        if((cSource < eGUI_SOURCE_ID_NUMBER) && (cPictureMode < eGUI_PICTURE_SETTINGS_NUMBER))
        {
        	if((eDFS_HSG_R_HUE <= uiIndex) && (eDFS_HSG_W_B_GAIN >= uiIndex))
        	{
        		uiNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_HSG, cSource, cPictureMode);
        	}
        	else if((eDFS_COLOR_CS <= uiIndex) && (eDFS_WALL_COLORSET >= uiIndex))  //G100_Steven_0047
        	{
        		uiNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_COLOR, cSource, cPictureMode);
        	}
        	else if(uiIndex <= eDFS_DIGITALZOOMPROP)
        	{
        		uiNode = utilDataMgr_SourceCommonTablerGet(cSource);
        	}

            for(UINT16 cCount = 0; cCount < SOURCE_DATA_NODE_NUMBER; cCount++)
            {
                if(psNode[cCount].uiNode == uiNode)
                {
                    uiNode = cCount;
                    break;
                }
            }

            if(cCount == SOURCE_DATA_NODE_NUMBER)
            {
                ASSERT_ALWAYS();
                utilDataMgr_MutexGive(__FUNCTION__);
                return DATA_MGR_FILE_NOT_FOUND;
            }
        }

        psPara = utilDataMgr_ParaTableGet(psNode[uiNode].uiNode);

        if(psPara == NULL)
        {
            utilDataMgr_MutexGive(__FUNCTION__);
            return DATA_MGR_OVER_RANGE;
        }

        utilDataMgr_SourceParaSet(uiIndex, psNode[uiNode].uiNode, psPara, pcData);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

    return DATA_MGR_PASS;
}
#endif

//G100_Steven_0016 start
#if 0
UINT8 utilDataMgr_SourceColorUserModeSet(UINT16 uiIndex, UINT8 cSource, UINT8 cPictureMode, UINT8 cPreUserMode, UINT8 *pcData)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        sPARA_FORMAT *psPara = NULL;
        sDATA_NODE_CTRL *psNode = m_sSourceDataNodeCtrl;
        UINT16 uiNode = eDATA_NODE_NUMBER;
        UINT16 cCount = 0;

        //LOG_MSG(db_ALWAYS, "\n Pic mode:%d Pre_mode:%d Index:%d value:%d\n",cPictureMode,cPreUserMode,uiIndex,*(UINT8 *)pcData);
        //LOG_MSG(db_ALWAYS, "(func:%s, line:%d) %d\r\n", __FUNCTION__, __LINE__, uiIndex);

        if(cSource >= eGUI_SOURCE_ID_NUMBER || cPictureMode >= eGUI_PICTURE_SETTINGS_NUMBER)
        {
            LOG_MSG(db_HAL_EEP, "\n%s fail %d %d %d \n", __FUNCTION__ , uiIndex, cSource, cPictureMode);
            utilDataMgr_MutexGive(__FUNCTION__);
            return 0;
        }

        if((cSource < eGUI_SOURCE_ID_NUMBER) && (cPictureMode < eGUI_PICTURE_SETTINGS_NUMBER))
        {
        	if(cPictureMode != eGUI_PICTURE_SETTINGS_USER)
        	{
        		if((eDFS_HSG_R_HUE <= uiIndex) && (eDFS_HSG_W_B_GAIN >= uiIndex))
        		{
        			uiNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_HSG, cSource, cPictureMode);
        		}
        		else if((eDFS_COLOR_CS <= uiIndex) && (eDFS_WALL_COLORSET >= uiIndex))  //G100_Steven_0047
        		{
        			uiNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_COLOR, cSource, cPictureMode);
        		}
        		else if(uiIndex <= eDFS_DIGITALZOOMPROP)
        		{
        			uiNode = utilDataMgr_SourceCommonTablerGet(cSource);
        		}
        	}
        	else
        	{
        		if((eDFS_HSG_R_HUE <= uiIndex) && (eDFS_HSG_W_B_GAIN >= uiIndex))
        		{
        			uiNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_HSG, cSource, cPreUserMode);
        		}
        		else if((eDFS_COLOR_CS <= uiIndex) && (eDFS_WALL_COLORSET >= uiIndex))  //G100_Steven_0047
        		{
        			uiNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_COLOR, cSource, cPreUserMode);
        		}
        		else if(uiIndex <= eDFS_DIGITALZOOMPROP)
        		{
        			uiNode = utilDataMgr_SourceCommonTablerGet(cSource);
        		}
        	}

            for(cCount = 0; cCount < SOURCE_DATA_NODE_NUMBER; cCount++)
            {
                if(psNode[cCount].uiNode == uiNode)
                {
                    uiNode = cCount;
                    break;
                }
            }

            if(cCount == SOURCE_DATA_NODE_NUMBER)
            {
                ASSERT_ALWAYS();
                utilDataMgr_MutexGive(__FUNCTION__);
                return DATA_MGR_FILE_NOT_FOUND;
            }
        }


        psPara = utilDataMgr_ParaTableGet(psNode[uiNode].uiNode);

        if(psPara == NULL)
        {
            utilDataMgr_MutexGive(__FUNCTION__);
            return DATA_MGR_OVER_RANGE;
        }

        utilDataMgr_SourceParaSet(uiIndex, psNode[uiNode].uiNode, psPara, pcData);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

    return DATA_MGR_PASS;
}
#endif


#ifdef CONF_BACKUP
static UINT8 utilDataMgr_ConfigBackup(eDATA_NODE eNode, const char *psPath)
{
    sDATA_NODE_CTRL *psNode = NULL;
    UINT16  uiNodeSize = 0;
    UINT16 ulIndexCount = 0;
    BOOL bCheckIndexFail = TRUE;

    for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
    {
        psNode = m_sDataNodeBakGroup[uiGroup].psNode;
        uiNodeSize = m_sDataNodeBakGroup[uiGroup].uiSize;

        for(ulIndexCount = 0; ulIndexCount < uiNodeSize; ulIndexCount++ )
    	{
    		if(psNode[ulIndexCount].uiNode == eNode)
    		{
    			bCheckIndexFail = FALSE;
                uiGroup = MAX_NODE_GROUP_NUMBER;
    			break;
    		}
    	}
    }

	if(bCheckIndexFail)
	{
		return DATA_MGR_FILE_NOT_FOUND;
	}

    //printf("cp %s %s\n", psPath, psNode[ulIndexCount].cNodeFileName);

    SYSTEM_CALL("cp %s %s", psPath, psNode[ulIndexCount].cNodeFileName);

    return DATA_MGR_PASS;
}
#endif /* CONF_BACKUP */


static UINT8 utilDataMgr_Initial(sDATA_NODE_CTRL *psNode, UINT16 uiIndex)
{
    //FILE *pFile = NULL;

    UINT32 ulCount = 0;
    UINT32 ulSize = 0;
    sPARA_FORMAT *psPara = NULL;
    char *conf_argv[1024][2];

    psPara = utilDataMgr_ParaTableGet(psNode[uiIndex].uiNode);
    ulSize = utilDataMgr_ParaTableSizeGet(psNode[uiIndex].uiNode);

    if(psPara == NULL)
    {
        printf("psPara is null %s\n", psNode[uiIndex].cNodeFileName);
        return DATA_MGR_OVER_RANGE;
    }

    for(ulCount = 0; ulCount < ulSize; ulCount++)
    {
       conf_argv[ulCount][0] = psPara[ulCount].cParaName;
       conf_argv[ulCount][1] = psPara[ulCount].cParaValue;
    }

    writeConf(psNode[uiIndex].cNodeFileName, conf_argv, ulSize);

    return DATA_MGR_PASS;
}

static UINT8 utilDataMgr_Reload(sDATA_NODE_CTRL *psNode, UINT16 uiIndex)
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulParaCount = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;
    UINT8  ucCheckSumFail = 0;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue, *pcGetName;
	char *pcNull="";	//ProAV_Doulas_0001

    pFile = fopen(psNode[uiIndex].cNodeFileName, "r");

    if(pFile != NULL)  //G100_Simon_0092
    {
        fseek(pFile, 0, SEEK_END);
        ulSize = ftell(pFile);
        fclose(pFile);
    }
    else
    {
        return DATA_MGR_FILE_NOT_FOUND;
    }

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(psNode[uiIndex].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = utilDataMgr_ParaTableGet(psNode[uiIndex].uiNode);
    ulParaCount = utilDataMgr_ParaTableSizeGet(psNode[uiIndex].uiNode);

    if(psPara == NULL || (INT32)FileLine <= 0)  //A70LK_Larry_0113 //G100_Simon_0092
    {
        free(pcBuffer);
        return DATA_MGR_OVER_RANGE;
    }

    pcGetValue = findArgValue("uiCheckSum", conf_argv, FileLine);

    //if(pcGetValue != "")                  //ProAV_Doulas_0001 remove
    if(strcmp(pcGetValue, pcNull) != 0)		//ProAV_Doulas_0001 Modify
    {
        uiCheckSum = (UINT16)atol(pcGetValue);
        uiCheckSum = (~uiCheckSum) + 1;
    }

#if 0
    //check data check sum
    for(ulCount = 0; ulCount < ulParaCount; ulCount++)
    {
        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

        //if(pcGetValue == "")	                //ProAV_Doulas_0001 remove
        if(strcmp(pcGetValue, pcNull) == 0)     //ProAV_Doulas_0001 Modify
        {
            //文件裡找不到，需要寫入文件裡
            //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, psPara[ulCount].cParaName, psPara[ulCount].cParaValue);
        }
        else
        {
            uiStrlen = strlen(pcGetValue);

            if(strcmp(psPara[ulCount].cParaName, "uiCheckSum") != 0)
            {
                for(uiCount = 0; uiCount < uiStrlen; uiCount++)
                {
                    //reference ascii printable characters (without space key)
                    if((pcGetValue[uiCount] > 0x20) && (pcGetValue[uiCount] < 0x7F))
                    {
                        uiCheckSum += pcGetValue[uiCount];
                    }
                }
            }
        }
    }
#else
    //check data check sum
    for(ulCount = 0; ulCount < FileLine; ulCount++)
    {
        pcGetValue = conf_argv[ulCount][1];
        pcGetName = conf_argv[ulCount][0];
        uiStrlen = strlen(pcGetValue);

        if(strcmp(pcGetName, "uiCheckSum") != 0)
        {
            for(uiCount = 0; uiCount < uiStrlen; uiCount++)
            {
                //reference ascii printable characters (without space key)
                if((pcGetValue[uiCount] > 0x20) && (pcGetValue[uiCount] < 0x7F))
                {
                    uiCheckSum += pcGetValue[uiCount];
                }
            }
        }
    }
#endif /* 0 */

    if((uiCheckSum & 0xFFFF) == 0)
    {
        LOG_MSG(db_HAL_EEP,"file %s, checksum pass!\n", psNode[uiIndex].cNodeFileName);
    }
    else
    {
        sPARA_FORMAT *psParaDefault = NULL;
        UINT32 ulTableSize = utilDataMgr_ParaTableSizeGet(psNode[uiIndex].uiNode);
        UINT32 ulDefaultSize = 0;

        psParaDefault = utilDataMgr_ParaTableDefaultGet(psNode[uiIndex].uiNode, &ulDefaultSize);

        memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulTableSize*sizeof(sPARA_FORMAT));

        LOG_MSG(db_HAL_EEP,"file %s, checksum fail!\n", psNode[uiIndex].cNodeFileName);

        printf("file %s, checksum fail!\n", psNode[uiIndex].cNodeFileName);
        psNode[uiIndex].cFlag = 1;
        ucCheckSumFail = 1;

        //free(pcBuffer);
        //return DATA_MGR_FIAL_CHECKSUM;
    }

    for(ulCount = 0; ulCount < ulParaCount; ulCount++)
    {
        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

		if(strcmp(pcGetValue, pcNull) == 0)	//ProAV_Doulas_0001 Modify.//pcGetValue is Null
        {
            //文件裡找不到，需要寫入文件裡
            LOG_MSG(db_HAL_EEP,"%s error (line=%d) value=%s\n",psPara[ulCount].cParaName,ulCount,psPara[ulCount].cParaValue);
            //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, psPara[ulCount].cParaName, psPara[ulCount].cParaValue);
            psNode[uiIndex].cFlag = 1;
        }
        else
        {
            memset(psPara[ulCount].cParaValue,  '\0', DATA_MGR_VALUE_LEN);
            strcpy(psPara[ulCount].cParaValue, pcGetValue);
        }
        //strcpy
    }

    if(psNode[uiIndex].cFlag)
    {
        UINT32 ulTableSize = utilDataMgr_ParaTableSizeGet(psNode[uiIndex].uiNode);
        sprintf(psPara[ulTableSize-1].cParaValue, "0"); //ulTableSize-1 is check sum
    }

	if(ulParaCount != FileLine)	//ProAV_Doulas_0001 Line error
    {
		LOG_MSG(db_HAL_EEP,"Line error (%d,%d)\n",FileLine, ulParaCount);
		if(remove(psNode[uiIndex].cNodeFileName) == 0)		//remove file
		{
			LOG_MSG(db_HAL_EEP,"Removed %s.\n", psNode[uiIndex].cNodeFileName);
		}
		psNode[uiIndex].cFlag = 1;
    }

    free(pcBuffer);

    if(ucCheckSumFail)
    {
        return DATA_MGR_FIAL_CHECKSUM;
    }
    else
    {
        return DATA_MGR_PASS;
    }
}

#ifdef CONF_BACKUP
static UINT8 utilDataMgr_ReloadBackup(eDATA_NODE eNode)
{
    UINT8 cResult = DATA_MGR_PASS;
    sDATA_NODE_CTRL *psNode = NULL;
    UINT16  uiNodeSize = 0;
    UINT16 ulIndexCount = 0;
    BOOL bCheckIndexFail = TRUE;

    for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
    {
        psNode = m_sDataNodeBakGroup[uiGroup].psNode;
        uiNodeSize = m_sDataNodeBakGroup[uiGroup].uiSize;

        for(ulIndexCount = 0; ulIndexCount < uiNodeSize; ulIndexCount++ )
    	{
    		if(psNode[ulIndexCount].uiNode == eNode)
    		{
    			bCheckIndexFail = FALSE;
                uiGroup = MAX_NODE_GROUP_NUMBER;
    			break;
    		}
    	}
    }

	if(bCheckIndexFail)
	{
		return DATA_MGR_FILE_NOT_FOUND;
	}

    //printf("(%s, %d)load backup %s\n", __FUNCTION__, __LINE__, psNode[ulIndexCount].cNodeFileName);
    cResult = utilDataMgr_Reload(psNode, ulIndexCount);

    return cResult;
}
#endif /* CONF_BACKUP */


static UINT8 utilDataMgr_Update(UINT16 uiNode)
{
    UINT32 ulCount = 0;
    UINT32 ulSize = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;
    UINT16 ulIndexCount = 0;       //G100_Steven_0016
    BOOL bCheckIndexFail = TRUE;  //G100_Steven_0016
    UINT16 uiStoreCheckSum = 0;
    sDATA_NODE_CTRL *psNode = NULL;
    UINT16  uiNodeSize = 0;

    sPARA_FORMAT *psPara;
    char *conf_argv[1024][2];

#if 0 //G100_Steven_0016
    if(uiIndex > MAX_DATA_NODE)
    {
        return 0;
    }
	//if(uiIndex == (MAX_DATA_NODE-1))	//G100_Doulas_0002
	LOG_MSG(db_ALWAYS,"Update %s(%d,%d)\r\n",m_sDataNodeCtrl[uiIndex].cNodeFileName,MAX_DATA_NODE,uiIndex);	//G100_Doulas_0002
#endif

    for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
    {
        psNode = m_sDataNodeGroup[uiGroup].psNode;
        uiNodeSize = m_sDataNodeGroup[uiGroup].uiSize;

        for(ulIndexCount = 0; ulIndexCount < uiNodeSize; ulIndexCount++ )
    	{
    		if(psNode[ulIndexCount].uiNode == uiNode)
    		{
    			bCheckIndexFail = FALSE;
                uiGroup = MAX_NODE_GROUP_NUMBER;
    			break;
    		}
    	}
    }

	if(bCheckIndexFail) //G100_Steven_0016
	{
		return DATA_MGR_FILE_NOT_FOUND;
	}

	//LOG_MSG(db_HAL_EEP,"Update %s(%d,%d)\r\n",m_sDataNodeCtrl[uiIndex].cNodeFileName,MAX_DATA_NODE,uiIndex);

	psPara = utilDataMgr_ParaTableGet(psNode[ulIndexCount].uiNode);
    ulSize = utilDataMgr_ParaTableSizeGet(psNode[ulIndexCount].uiNode);

    if(psPara == NULL)
    {
        return DATA_MGR_OVER_RANGE;
    }

    for(ulCount = 0; ulCount < ulSize; ulCount++)
    {
        if(strcmp(psPara[ulCount].cParaName, "uiCheckSum") != 0)
        {
            uiStrlen = strlen(psPara[ulCount].cParaValue);

            for(uiCount = 0; uiCount < uiStrlen; uiCount++)
            {
                //reference ascii printable characters (without space key)
                if((psPara[ulCount].cParaValue[uiCount] > 0x20) && (psPara[ulCount].cParaValue[uiCount] < 0x7F))
                {
                    uiCheckSum += psPara[ulCount].cParaValue[uiCount];
                }
            }
            //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, psPara[ulCount].cParaName, psPara[ulCount].cParaValue);
        }
    }

    uiStoreCheckSum = (UINT16)atol(psPara[ulSize - 1].cParaValue);

    if((uiStoreCheckSum != uiCheckSum) || (psNode[ulIndexCount].cFlag))
    {
        // ulSize - 1 is checksum
        sprintf(psPara[ulSize - 1].cParaValue, "%d", uiCheckSum);

        //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, "uiCheckSum", psPara[ulSize - 1].cParaValue);

        for(ulCount = 0; ulCount < ulSize; ulCount++)
        {
           conf_argv[ulCount][0] = psPara[ulCount].cParaName;
           conf_argv[ulCount][1] = psPara[ulCount].cParaValue;
        }

        writeConf(psNode[ulIndexCount].cNodeFileName, conf_argv, ulSize);

        psNode[ulIndexCount].cFlag = 0;

#ifdef CONF_BACKUP
        utilDataMgr_ConfigBackup(psNode[ulIndexCount].uiNode, psNode[ulIndexCount].cNodeFileName);
#endif /* CONF_BACKUP */

        LOG_MSG(db_HAL_EEP,"Update file %s, ulCheckSum %04x\n", psNode[ulIndexCount].cNodeFileName, uiCheckSum);
    }

    return DATA_MGR_PASS;
}

void utilDataMgr_UpdateProcuss(void)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
        {
            sDATA_NODE_CTRL *psNode = m_sDataNodeGroup[uiGroup].psNode;
            UINT16 uiNodeSize = m_sDataNodeGroup[uiGroup].uiSize;

            for(UINT16 uiCount = 0; uiCount < uiNodeSize; uiCount++)
            {
                if(psNode[uiCount].cFlag)
                {
                    utilDataMgr_Update(psNode[uiCount].uiNode);

                    psNode[uiCount].cFlag = 0;
                }
            }
        }

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

static void utilDataMgr_CustomerVersionSet(void)
{
    FILE    *pFile = NULL;
    UINT8   ucCount = 0;
    UINT32  ulSize = 0;
    UINT32  FileLine = 0;
    char    *cBuf;
    char    *pcBuffer;
    char    *conf_argv[eCUSTOMER_VERSION_NUMBER][2];

    pFile = fopen(CUSTOMER_VERSION_CONF, "r");

    sprintf(m_sCustomer_Version[eCUSTOMER_VERSION_STAGE].cParaValue,  "%d", VERSTAGE);
    sprintf(m_sCustomer_Version[eCUSTOMER_VERSION_MAJOR].cParaValue,  "%d", VERMAJOR);
    sprintf(m_sCustomer_Version[eCUSTOMER_VERSION_MINOR].cParaValue,  "%d", VERMINOR);
    sprintf(m_sCustomer_Version[eCUSTOMER_VERSION_CODE].cParaValue,   "%d", PROJECTOR_IDENTIFY);

    if(pFile == NULL)  //initial
    {
        printf("Customer Version file not found\n");

        for(ucCount = 0; ucCount < eCUSTOMER_VERSION_NUMBER; ucCount++)
        {
            setArgValue(CUSTOMER_VERSION_CONF, m_sCustomer_Version[ucCount].cParaName, m_sCustomer_Version[ucCount].cParaValue);
        }
    }
    else
    {
        fseek(pFile, 0, SEEK_END);
        ulSize = ftell(pFile);
        fclose(pFile);

        pcBuffer = (char*)malloc(ulSize+1);
        FileLine = (uint32)readConf(CUSTOMER_VERSION_CONF, conf_argv, eCUSTOMER_VERSION_NUMBER, pcBuffer, ulSize);

        for(ucCount = 0; ucCount < eCUSTOMER_VERSION_NUMBER; ucCount++)
        {
            cBuf = findArgValue(m_sCustomer_Version[ucCount].cParaName, conf_argv, FileLine);

            if(strcmp(cBuf, m_sCustomer_Version[ucCount].cParaValue) != 0)
            {
                setArgValue(CUSTOMER_VERSION_CONF, m_sCustomer_Version[ucCount].cParaName, m_sCustomer_Version[ucCount].cParaValue);
            }
        }

        free(pcBuffer);
    }
}

void utilDataMgr_NodeReset(eDATA_NODE eNode, sEEPROM_SETTINGS *psEEP)
{
    switch(eNode)
    {
        case eDATA_NODE_PROJECTORINFO:
            //utilDataMgr_RAMToFileProjectorInfo(psEEP, eNode);
            break;

        case eDATA_NODE_SYSTEMCAL:
            //utilDataMgr_RAMToFileSystemCal(psEEP, uiNode);
            break;

        case eDATA_NODE_BURNIN:
            utilDataMgr_RAMToFileBurnin(psEEP, eNode);
            break;

        case eDATA_NODE_STARTUP:
            utilDataMgr_RAMToFileStartup(psEEP, eNode);
            break;

        case eDATA_NODE_AUTOBRIGHTNESS:
            utilDataMgr_RAMToFileAutoBrightness(psEEP, eNode);
            break;

        case eDATA_NODE_COMMONGUI:
            utilDataMgr_RAMToFileCommonGui(psEEP, eNode);
            break;

        case eDATA_NODE_WARPING:
            utilDataMgr_RAMToFileWarping(psEEP, eNode);
            break;

        case eDATA_NODE_TEC_GATING_INFO:
            utilDataMgr_Update(eNode);
            break;

        case eDATA_NODE_ACTUATOR:
            break;

        case eDATA_NODE_WAP_CALIBRATION_TAG:
            utilDataMgr_RAMToFileWAPFlag(psEEP, eNode);
            break;

        case eDATA_NODE_ACU:
        case eDATA_NODE_NUMBER:
            break;

        default:
            utilDataMgr_RAMToFileSourceTableCommon(psEEP, eNode);
            utilDataMgr_RAMToFileSourceTableColor(psEEP, eNode);
            utilDataMgr_RAMToFileSourceTableHSG(psEEP, eNode);
            utilDataMgr_RAMToFileSourceTableColorUser(psEEP, eNode);
            utilDataMgr_RAMToFileSourceTableHSGUser(psEEP, eNode);
            utilDataMgr_RAMToFileWAP(psEEP, eNode);
            break;
    }
}


void utilDataMgr_Initialization(sEEPROM_SETTINGS *psEEP)
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psParaDefault = NULL;
    sPARA_FORMAT *psPara = NULL;
    UINT32 ulSize = 0;
    UINT32 ulDefaultSize = 0;
    UINT8 cResult = DATA_MGR_PASS;
    sSOURCE_PARA_TABLE sSourceTable;

    if(pthread_mutex_init(&m_xutilDataMgrTaskMutex, NULL) != 0)
    {
        LOG_MSG(db_ALWAYS, "(func:%s, line:%d): Create xTaskMutex Fail!\r\n", __FUNCTION__, __LINE__);
    }

    if(access(CONF_PATH, 0) == -1)
    {
        mkdir(CONF_PATH, 0777);
    }

    if(access(SYSLOG_LOG_PATH, 0) == -1)
    {
        mkdir(SYSLOG_LOG_PATH, 0777);
    }

    if(access(CONF_SCALER_PATH, 0) == -1)
    {
        mkdir(CONF_SCALER_PATH, 0777);
    }

	if(access(CONF_SCALER_SYSTEM_PATH, 0) == -1)
	{
	    mkdir(CONF_SCALER_SYSTEM_PATH, 0777);
	}

    if(access(CONF_SCALER_GUI_PATH, 0) == -1)
    {
        mkdir(CONF_SCALER_GUI_PATH, 0777);
    }

    if(access(CONF_SCALER_SOURCE_PATH, 0) == -1)
    {
        mkdir(CONF_SCALER_SOURCE_PATH, 0777);
    }

	if(access(CONF_SCALER_WAP_PATH, 0) == -1)  //G100_Steven_0011
	{
		mkdir(CONF_SCALER_WAP_PATH, 0777);
	}

#ifdef CONF_BACKUP
    if(access(CONF_BAK_PATH, 0) == -1)
    {
        mkdir(CONF_BAK_PATH, 0777);
    }

    if(access(CONF_BAK_SYSTEM_PATH, 0) == -1)
    {
        mkdir(CONF_BAK_SYSTEM_PATH, 0777);
    }

    if(access(CONF_BAK_GUI_PATH, 0) == -1)
    {
        mkdir(CONF_BAK_GUI_PATH, 0777);
    }

    if(access(CONF_BAK_SOURCE_PATH, 0) == -1)
    {
        mkdir(CONF_BAK_SOURCE_PATH, 0777);
    }

    if(access(CONF_BAK_WAP_PATH, 0) == -1)
    {
        mkdir(CONF_BAK_WAP_PATH, 0777);
    }
#endif /* CONF_BACKUP */

    if(access(ERROR_LOG_PATH, 0) == -1)
    {
        mkdir(ERROR_LOG_PATH, 0777);
    }

    if(access(SST_INFO_PATH, 0) == -1)
    {
        mkdir(SST_INFO_PATH, 0777);
    }

	if(access(UPGRADE_LOG_PATH, 0) == -1)  //G100_Julie_0040
	{
		mkdir(UPGRADE_LOG_PATH, 0777);
	}

	if(access(IMXAP_LOG_PATH, 0) == -1)  //G100_Julie_0042
	{
		mkdir(IMXAP_LOG_PATH, 0777);
	}

	if(access(LOGO_PICTURE_PATH, 0) == -1)
	{
		mkdir(LOGO_PICTURE_PATH, 0777);
	}

	if(access(COLOR_UNIFORMITY_PATH, 0) == -1)
	{
		mkdir(COLOR_UNIFORMITY_PATH, 0777);
	}

	if(access(OMS_DATA_PATH, 0) == -1)
	{
		mkdir(OMS_DATA_PATH, 0777);
	}

#ifdef CONF_BACKUP
    if(access(COLOR_BAK_UNIFORMITY_PATH, 0) == -1)
    {
        mkdir(COLOR_BAK_UNIFORMITY_PATH, 0777);
    }

    if(access(OMS_BAK_DATA_PATH, 0) == -1)
    {
        mkdir(OMS_BAK_DATA_PATH, 0777);
    }
#endif /* CONF_BACKUP */

    if(access(MODEL_CHANGE_LOG_PATH, 0) == -1)
    {
        mkdir(MODEL_CHANGE_LOG_PATH, 0777);
    }

    if(access(ADV_WAPR_PATH, 0) == -1)
    {
        mkdir(ADV_WAPR_PATH, 0777);
    }

    if(access(BLENDING_FILE_PATH, 0) == -1)
    {
        mkdir(BLENDING_FILE_PATH, 0777);
    }

    if(access(BLENDING_AP_SAVING_PATH, 0) == -1)
    {
        mkdir(BLENDING_AP_SAVING_PATH, 0777);
    }

#if (ENABLE_COLOR_UNIFORMITY == TRUE)   //G100_Tim_0012, add, start
    if(access(COLOR_UNIFORMITY_PATH, 0) == -1)
    {
        mkdir(COLOR_UNIFORMITY_PATH, 0777);
    }
#endif //ENABLE_COLOR_UNIFORMITY        //G100_Tim_0012, add, end
    sSourceTable.p_sSourceData        = &m_sSourceData[0];
    sSourceTable.p_sWAP_RatioData     = &m_sWAP_RatioData[0];
    sSourceTable.p_sWAP_OffsetData    = &m_sWAP_OffsetData[0];
    sSourceTable.p_sWAP_PWMData       = &m_sWAP_PWMData[0];

    utilDataMgrSourceInit(sSourceTable);

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        utilDataMgr_CustomerVersionSet();

        utilDataMgr_MutexGive(__FUNCTION__);
    }

    for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
    {
        sDATA_NODE_CTRL *psNode = m_sDataNodeGroup[uiGroup].psNode;
        UINT16          uiNodeSize = m_sDataNodeGroup[uiGroup].uiSize;

        for(UINT16 uiCount = 0; uiCount < uiNodeSize; uiCount++)
        {
            pFile = fopen(psNode[uiCount].cNodeFileName, "rb");

            if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
            {
                psParaDefault = utilDataMgr_ParaTableDefaultGet(psNode[uiCount].uiNode, &ulDefaultSize);
                psPara = utilDataMgr_ParaTableGet(psNode[uiCount].uiNode);
                ulSize = utilDataMgr_ParaTableSizeGet(psNode[uiCount].uiNode);

                if((psParaDefault != NULL) && (psPara != NULL))
                {
                    if(ulDefaultSize != ulSize)
                    {
                        UINT16 uiCount2;
                        UINT16 uiCount3;

                        LOG_MSG(db_ALWAYS,"Initial %s table is not matched %d %d\n", psNode[uiCount].cNodeFileName, ulDefaultSize, ulSize);
                        printf("Initial %s table is not matched %d %d\n", psNode[uiCount].cNodeFileName, ulDefaultSize, ulSize);

                        for(uiCount2 = 0; uiCount2 < ulSize; uiCount2++)
                        {
                            for(uiCount3 = 0; uiCount3 < ulDefaultSize; uiCount3++)
                            {
                                if(psParaDefault[uiCount3].uiItem == uiCount2)
                                {
                                    break;
                                }
                            }

                            if(psParaDefault[uiCount3].uiItem != uiCount2)
                            {
                                LOG_MSG(db_ALWAYS, "item %d not found \n", uiCount2);
                                printf("item %d not found \n", uiCount2);
                            }
                        }

                        exit(EXIT_SUCCESS);
                    }

                    memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulSize*sizeof(sPARA_FORMAT));
                }

                if(pFile == NULL) //initial
                {
                    LOG_MSG(db_HAL_EEP,"file %s null\n", psNode[uiCount].cNodeFileName);

                    cResult = utilDataMgr_Initial(psNode, uiCount);
                    utilDataMgr_MutexGive(__FUNCTION__);

                    utilDataMgr_NodeReset(psNode[uiCount].uiNode, psEEP);

                    //printf("file %s null\n", psNode[uiCount].cNodeFileName);

                    psNode[uiCount].cFlag = 1;
                }
                else
                {
                    fclose(pFile);

                    cResult = utilDataMgr_Reload(psNode, uiCount);

#ifdef CONF_BACKUP
                    if(cResult != DATA_MGR_PASS)
                    {
                        cResult = utilDataMgr_ReloadBackup(psNode[uiCount].uiNode);
                    }
#endif /* CONF_BACKUP */
                }

                utilDataMgr_MutexGive(__FUNCTION__);
            }


            if(cResult != DATA_MGR_PASS) //A70LK_Larry_0113 (cResult == DATA_MGR_FIAL_CHECKSUM) -> (cResult != DATA_MGR_PASS)
            {
                utilDataMgr_NodeReset(psNode[uiCount].uiNode, psEEP);
                utilDataMgr_Update(psNode[uiCount].uiNode);
                psNode[uiCount].cFlag = 0;
            }

        }
    }
}

void utilDataMgr_ResetToDefault(eNVRAM_EVENT eEvent)
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psParaDefault;
    sPARA_FORMAT *psPara;
    UINT32 ulSize = 0;
    UINT32 ulDefaultSize = 0;
    UINT8  ucReset = 0;

    if(eEvent == eNVRAM_EVENT_RESETALL)
    {
        printf("Reset RESETALL\n");
    }
    else
    {
        printf("Reset INITIALIZE\n");
    }

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
        {
            sDATA_NODE_CTRL *psNode = m_sDataNodeGroup[uiGroup].psNode;
            UINT16          uiNodeSize = m_sDataNodeGroup[uiGroup].uiSize;

            for(UINT16 uiCount = 0; uiCount < uiNodeSize; uiCount++)
            {
                ucReset = 0;

                if((psNode[uiCount].uiNode == eDATA_NODE_PROJECTORINFO) ||
                   (psNode[uiCount].uiNode == eDATA_NODE_SYSTEMCAL) ||
                   (psNode[uiCount].uiNode == eDATA_NODE_SYSTEMHOURS) ||  //G100_Steven_0013 start
    			   ((psNode[uiCount].uiNode >= eDATA_NODE_WAP_CALIBRATION_TAG) &&
    			    (psNode[uiCount].uiNode <= eDATA_NODE_WAP_2D_HIGH_SPEED_PWM) ||
					(psNode[uiCount].uiNode <= eDATA_NODE_WAP_3D_PWM) || //G100_Steven_0013 end
    			    (psNode[uiCount].uiNode == eDATA_NODE_TEC_GATING_INFO))) //G100_Steven_0013 end
                {
                    if(eEvent == eNVRAM_EVENT_RESETALL)
                    {
                        ucReset = 1;
                    }
                }
                else if(psNode[uiCount].uiNode == eDATA_NODE_ACTUATOR)
                {
                    // don't clear
                    ucReset = 0;
                }
                else
                {
                    ucReset = 1;
                }

                if(ucReset)
                {
                    if(remove(psNode[uiCount].cNodeFileName) == 0)
                    {
                        LOG_MSG(db_HAL_EEP,"Removed %s.\n", psNode[uiCount].cNodeFileName);
                    }

                    psParaDefault = utilDataMgr_ParaTableDefaultGet(psNode[uiCount].uiNode, &ulDefaultSize);
                    psPara = utilDataMgr_ParaTableGet(psNode[uiCount].uiNode);
                    ulSize = utilDataMgr_ParaTableSizeGet(psNode[uiCount].uiNode);

                    if((psParaDefault != NULL) && (psPara != NULL))
                    {
                        if(ARRAY_SIZE(psParaDefault) != ulSize)
                        {
                            LOG_MSG(db_HAL_EEP,"Reset To Default %s table is not matched\n", psNode[uiCount].cNodeFileName);
                        }
                        memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulSize*sizeof(sPARA_FORMAT));
                    }

                    utilDataMgr_Initial(psNode, uiCount);
                }
            }
        }
        remove(ERROR_LOG_TXT);
        remove(SST_INFO_TXT);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_FileToRAM(sEEPROM_SETTINGS *psEEP)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        UINT16 iCount = 0, iCount2 = 0, uiSourceNode = 0;
        sPARA_FORMAT *psPara;

        //Projector Info
        snprintf(psEEP->sUserSystemSetting.sCommonSetting.ucModelName,  15, "%s", m_sProjectorInfo[ePI_UCMODELNAME].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sCommonSetting.ucCustomCode,  15, "%s", m_sProjectorInfo[ePI_UCCUSTOM_CODE].cParaValue);

        //System Cal
        psEEP->sADC_cal_values.uiRGBOffset[0]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_0].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset[0]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_0].cParaValue);
        psEEP->sADC_cal_values.uiRGBOffset2[0]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset2[0]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue);
        psEEP->sADC_cal_values.uiRGBOffset[1]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_1].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset[1]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_1].cParaValue);
        psEEP->sADC_cal_values.uiRGBOffset2[1]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset2[1]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue);
        psEEP->sADC_cal_values.uiRGBOffset[2]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_2].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset[2]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_2].cParaValue);
        psEEP->sADC_cal_values.uiRGBOffset2[2]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue);
        psEEP->sADC_cal_values.uiYUVOffset2[2]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain[0]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_0].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain[1]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_1].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain[2]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_2].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain[0]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_0].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain[1]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_1].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain[2]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_2].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain2[0]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_0].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain2[1]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_1].cParaValue);
        psEEP->sADC_cal_values.uiRGBGain2[2]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_2].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain2[0]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_0].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain2[1]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_1].cParaValue);
        psEEP->sADC_cal_values.uiYUVGain2[2]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_2].cParaValue);

        //Burnin
        psEEP->sBurin_Information.ucBurnInEnable    = (UINT8)atol(m_sBurnin[eBI_URNINENABLE].cParaValue);
        psEEP->sBurin_Information.ucLampOn          = (UINT8)atol(m_sBurnin[eBI_UCLAMPON].cParaValue);
        psEEP->sBurin_Information.ucLampOff         = (UINT8)atol(m_sBurnin[eBI_UCLAMPOFF].cParaValue);
        psEEP->sBurin_Information.uiBurnInCycle     = (UINT16)atol(m_sBurnin[eBI_UIBURNINCYCLE].cParaValue);
        psEEP->sBurin_Information.ucBurnInMode      = (UINT8)atol(m_sBurnin[eBI_UCBURNINMODE].cParaValue);
        psEEP->sBurin_Information.ucBurnInAlwaysOn  = (UINT8)atol(m_sBurnin[eBI_UCBURNINALWAYSON].cParaValue);

        //sLayoutVersion
        psEEP->sLayoutVersion.ucSubminor    = (UINT8)atol(m_sProjectorInfo[ePI_UCSUBMINOR].cParaValue);
        psEEP->sLayoutVersion.ucMinor       = (UINT8)atol(m_sProjectorInfo[ePI_UCMINOR].cParaValue);
        psEEP->sLayoutVersion.ucMajor       = (UINT8)atol(m_sProjectorInfo[ePI_UCMAJOR].cParaValue);

		//m_sAutoBrightness   	//G100_Doulas_0010 Add
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_Y].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_R].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_B].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_G].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[4]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_Y].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[5]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_R].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[6]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_B].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[7]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_G].cParaValue);

		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_Y].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_R].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_B].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_G].cParaValue);

		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_Y].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_R].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_B].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_G].cParaValue);

		//G100_Doulas_0023 Add
		psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_Y].cParaValue);
		psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_R].cParaValue);
		psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_B].cParaValue);
		psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_G].cParaValue);

		psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_Y].cParaValue);
		psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_R].cParaValue);
		psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_B].cParaValue);
		psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_G].cParaValue);

		psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_Y].cParaValue);
		psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_R].cParaValue);
		psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_B].cParaValue);
		psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_G].cParaValue);

		psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_Y].cParaValue);
		psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_R].cParaValue);
		psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_B].cParaValue);
		psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_G].cParaValue);


        //System Default
        sprintf(psEEP->sSystemDefault.ucSerialNumber, "%s\0", m_sProjectorInfo[ePI_UCSERIALNUMBER].cParaValue);
        psEEP->sSystemDefault.ucFirstStartupFlag    =   (UINT8)atol(m_sStartup[eSU_UCFIRSTSTARTUPFLAG].cParaValue);
        psEEP->sSystemDefault.ucUSTFirstStartup     =   (UINT8)atol(m_sStartup[eSU_UCUSTFIRSTSTARTUP].cParaValue);
        psEEP->sSystemDefault.ucPINProtect          =   (UINT8)atol(m_sStartup[eSU_UCPINPROTECT].cParaValue);
        psEEP->sSystemDefault.ucOPFU_Check          =   (UINT8)atol(m_sStartup[eSU_OPFU_CHECK].cParaValue); //G100_Simon_0064
        psEEP->sSystemDefault.ucRegion              =   (UINT8)atol(m_sProjectorInfo[ePI_CUSTOM_REGION].cParaValue);			//A65_OPTOMA_Doulas_0033 Modify//A65_OPTOMA_Doulas_0027
		psEEP->sSystemDefault.ucDefaultLogo         =   (UINT8)atol(m_sProjectorInfo[ePI_CUSTOM_DEFAULT_LOGO].cParaValue);	//A65_OPTOMA_Doulas_0033 Modify//A65_OPTOMA_Doulas_0027

        strncpy(&psEEP->sSystemDefault.ucPassWord[0], m_sStartup[eSU_UCPASSWORD_0].cParaValue, 1);
        strncpy(&psEEP->sSystemDefault.ucPassWord[1], m_sStartup[eSU_UCPASSWORD_1].cParaValue, 1);
        strncpy(&psEEP->sSystemDefault.ucPassWord[2], m_sStartup[eSU_UCPASSWORD_2].cParaValue, 1);
        strncpy(&psEEP->sSystemDefault.ucPassWord[3], m_sStartup[eSU_UCPASSWORD_3].cParaValue, 1);
        strncpy(&psEEP->sSystemDefault.ucPassWord[4], m_sStartup[eSU_UCPASSWORD_4].cParaValue, 1);

        psEEP->sSystemDefault.uiFWIndex[0] = (UINT16)atol(m_sSystemCal[eSC_UIFWINDEX_0].cParaValue);
        psEEP->sSystemDefault.uiFWIndex[1] = (UINT16)atol(m_sSystemCal[eSC_UIFWINDEX_1].cParaValue);
        psEEP->sSystemDefault.uiPWIndex[0] = (UINT16)atol(m_sSystemCal[eSC_UIPWINDEX_0].cParaValue);
        psEEP->sSystemDefault.uiPWIndex[1] = (UINT16)atol(m_sSystemCal[eSC_UIPWINDEX_1].cParaValue);


        psEEP->sSystemDefault.ulTotalProjectorMinute                    = (UINT32)atol(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_BLD]    = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTE_B].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_RLD]    = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTE_R].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinuteNormal                 = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTENORMAL].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinuteEco                    = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTEECO].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinuteQuiet                  = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTEQUIET].cParaValue);
        psEEP->sSystemDefault.ulLightSourceMinuteCustom                 = (UINT32)atol(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTECUSTOM].cParaValue);

        psEEP->sSystemDefault.ucPOWER_OFFSET = (UINT8)atol(m_sSystemCal[eSC_UCPOWER_OFFSET].cParaValue);
        psEEP->sSystemDefault.ucCOLOR_OFFSET = (UINT8)atol(m_sSystemCal[eSC_UCCOLOR_OFFSET].cParaValue);

        //psEEP->sSystemDefault.ucUST_LensInstallType = (UINT8)atol(m_sSystemCal[eSC_UCPOWER_OFFSET].cParaValue);
        psEEP->sSystemDefault.ucLensType  = (UINT8)atol(m_sCommonGui[eCG_UCLENSTYPE].cParaValue);

        psEEP->sSystemDefault.ulDbMask  = (UINT64)atoll(m_sCommonGui[eCG_ULDBMASK].cParaValue);
        //psEEP->sSystemDefault.ucUpgradeCheck;

        psEEP->sSystemDefault.ucPanel = (UINT8)atol(m_sCommonGui[eCG_UCPANEL].cParaValue);

        psEEP->sSystemDefault.ucEQ_HDMI1 = (UINT8)atol(m_sCommonGui[eCG_UCEQMODE_HDMI1].cParaValue);
        psEEP->sSystemDefault.ucEQ_HDMI2 = (UINT8)atol(m_sCommonGui[eCG_UCEQMODE_HDMI2].cParaValue);
        psEEP->sSystemDefault.ucEQ_DVI = (UINT8)atol(m_sCommonGui[eCG_UCEQMODE_DVI].cParaValue);

        psEEP->sSystemDefault.ucABP_CalibrateFlag = (UINT8)atol(m_sSystemCal[eSC_UCABP_CALIBRATEFLAG].cParaValue);

        psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_Y]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_R]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_B]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_G]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_Y]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_R]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_B]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_G]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_Y]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_R]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_B]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_G]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_B]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_G]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_Y]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_R]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_B]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_G]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_Y]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_R]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_B]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_G]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_Y]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_R]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_B]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_G]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_G].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_Y].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_R].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_B]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_B].cParaValue);
        psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_G]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_G].cParaValue);
        psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_Y]     = (UINT8)atol(m_sSystemCal[eSC_UCLIGHTSENSORTIME_Y].cParaValue);				//A65_OPTOMA_Doulas_0105 start
        psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_R]     = (UINT8)atol(m_sSystemCal[eSC_UCLIGHTSENSORTIME_R].cParaValue);
        psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_B]     = (UINT8)atol(m_sSystemCal[eSC_UCLIGHTSENSORTIME_B].cParaValue);
        psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_G]     = (UINT8)atol(m_sSystemCal[eSC_UCLIGHTSENSORTIME_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_B]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_G]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTargetRLD[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_RY].cParaValue);
        psEEP->sSystemDefault.uiLightSensorTargetRLD[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORTARGET_RR].cParaValue);	//A65_OPTOMA_Doulas_0105 end
        psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_Y]     = (float)atof(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_Y].cParaValue);    //A70G2_Owen_0002 Start
        psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_R]     = (float)atof(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_R].cParaValue);
        psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_B]     = (float)atof(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_B].cParaValue);
        psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_G]     = (float)atof(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_G].cParaValue);
        psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_Y]    = (UINT16)atol(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_Y].cParaValue);
        psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_R]    = (UINT16)atol(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_R].cParaValue);
        psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_B]    = (UINT16)atol(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_B].cParaValue);
        psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_G]    = (UINT16)atol(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_G].cParaValue); //A70G2_Owen_0002 End
        psEEP->sSystemDefault.ucUST_LensInstallType                  = (UINT8)atol(m_sSystemCal[eSC_UCUST].cParaValue); //A35G2_BRC_Casper_0089

        //psEEP->sSystemDefault.ucLensCalibrationStatus           = (UINT8)atol(m_sSystemCal[eSC_LENS_CALIBRATION_STATUS].cParaValue); //R70G2_AC_0032

        #if (ENABLE_COLOR_UNIFORMITY == TRUE)                   //G100_Tim_0012, add, start
        psEEP->sSystemDefault.ucACU_File_Valid                  = (UINT8)atol(m_sACU_DATA[eACU_FILE_VALID].cParaValue);
        psEEP->sSystemDefault.ucACU_Display_Mode                = (UINT8)atol(m_sACU_DATA[eACU_DISPLAY_MODE].cParaValue);
        psEEP->sSystemDefault.ucACU_Target_Select                = (UINT8)atol(m_sACU_DATA[eACU_TARGET_SELECT].cParaValue); //G100_Tim_0048, add
        #endif //ENABLE_COLOR_UNIFORMITY                        //G100_Tim_0012, add, end
		psEEP->sSystemDefault.ucACU_Data_Enable					= (UINT8)atol(m_sACU_DATA[eACU_DATA_ENABLE].cParaValue); //A35G2_Alan_0007

		psEEP->sSystemDefault.ucModelSwitchAdjust				= (UINT8)atol(m_sProjectorInfo[ePI_UCMODEL_SWITCH].cParaValue);  //A65_OPTOMA_Julie_0064
        //Gui
        psEEP->sUserSystemSetting.sLightSetting.ucPowerMode             = (UINT8)GUI2CM(edcPOWER_MODE, (UINT8)atol(m_sCommonGui[eCG_UCPOWERMODE].cParaValue));
        psEEP->sUserSystemSetting.sLightSetting.ucWaveformGain          = (UINT8)atol(m_sCommonGui[eCG_UCWAVEFORMGAIN].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucIRWaveformGain        = (UINT8)atol(m_sCommonGui[eCG_UCIRWAVEFORMGAIN].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucIRMode_WaveformGain   = (UINT8)atol(m_sCommonGui[eCG_UCIRMODE_WAVEFORMGAIN].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucIRMode_IRWaveformGain = (UINT8)atol(m_sCommonGui[eCG_UCIRMODE_IRWAVEFORMGAIN].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucIRLD                  = (UINT8)atol(m_sCommonGui[eCG_UCIRLD].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucIRBLD                 = (UINT8)atol(m_sCommonGui[eCG_UCIRBLD].cParaValue);
        psEEP->sUserSystemSetting.sLightSetting.ucLightCalibrationMode  = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTCALIBRATIONMODE].cParaValue);
		psEEP->sUserSystemSetting.sLightSetting.ucConstantBrightness    = (UINT8)atol(m_sCommonGui[eCG_CONSTANT_BRIGHTNESS].cParaValue);		//G100_Doulas_0008

        psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLocation       = (UINT8)GUI2CM(edcMENU_LOCATION, (UINT8)atol(m_sCommonGui[eCG_UCMENULOCATION].cParaValue));
        psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTranslucency    = (UINT8)atol(m_sCommonGui[eCG_UCOSDTRANSLUCENCY].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTimeout         = (UINT8)GUI2CM(edcMENU_TIME_OUT, (UINT8)atol(m_sCommonGui[eCG_UCOSDTIMEOUT].cParaValue));
        psEEP->sUserSystemSetting.sOSD_Setting.ucShowMessages       = (UINT8)atol(m_sCommonGui[eCG_UCSHOWMESSAGES].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX        = (UINT8)atol(m_sCommonGui[eCG_UCMENUOFFSETX].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY        = (UINT8)atol(m_sCommonGui[eCG_UCMENUOFFSETY].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLockout        = (UINT8)atol(m_sCommonGui[eCG_UCMENULOCKOUT].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucMenuTransparency   = (UINT8)atol(m_sCommonGui[eCG_UCMENUTRANSPARENCY].cParaValue);
        psEEP->sUserSystemSetting.sOSD_Setting.ucSearchScreen       = (UINT8)atol(m_sCommonGui[eCG_UCSEARCHSCREEN].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable   = (UINT8)atol(m_sCommonGui[eCG_UCHSGADJUSTMENTENABLE].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern= (UINT8)atol(m_sCommonGui[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucHSGSelected = (UINT8)atol(m_sCommonGui[eCG_UCHSGSELECTED].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucCustomizeEDID_HDMI1 = (UINT8)atol(m_sCommonGui[eCG_CUSTOMEDID_HDMI1_STATUS].cParaValue);  //A35G2_SImon_0091
        psEEP->sUserSystemSetting.sImageSetting.ucCustomizeEDID_HDMI2 = (UINT8)atol(m_sCommonGui[eCG_CUSTOMEDID_HDMI2_STATUS].cParaValue);  //A35G2_SImon_0091

        psEEP->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch   = (UINT8)atol(m_sCommonGui[eCG_UCBLANKONSIGNALSWITCH].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucSyncThreshold         = (UINT8)atol(m_sCommonGui[eCG_UCSYNCTHRESHOLD].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucContrastEnhancement   = (UINT8)atol(m_sCommonGui[eCG_UCCONTRASTENHANCEMENT].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucFilm                  = (UINT8)atol(m_sCommonGui[eCG_UCFILM].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucWallColor             = (UINT8)GUI2CM(edcWALL_COLOR, (UINT8)atol(m_sCommonGui[eCG_UCWALLCOLOR].cParaValue));
        psEEP->sUserSystemSetting.sImageSetting.ucImageFreeze           = (UINT8)atol(m_sCommonGui[eCG_UCIMAGEFREEZE].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ucCeilingMount          = (UINT8)GUI2CM(edcCEILING_MOUNT, (UINT8)atol(m_sCommonGui[eCG_UCCEILINGMOUNT].cParaValue));
        psEEP->sUserSystemSetting.sImageSetting.ucRearProject           = (UINT8)GUI2CM(edcREAR_PROJECTION, (UINT8)atol(m_sCommonGui[eCG_UCREARPROJECT].cParaValue));

        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D] = (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_0].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D] =         (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_1].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120] =       (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_2].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER] =     (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_3].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER]  =       (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_4].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D_P] = (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_5].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D_P] =         (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_6].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120_P] =       (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_7].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER_P] =     (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_8].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER_P]  =       (UINT16)atol(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_9].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D] = (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_0].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D] =         (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_1].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120]  =      (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_2].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER]  =    (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_3].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER]  =       (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_4].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D_P] = (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_5].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D_P] =         (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_6].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120_P]  =      (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_7].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER_P]  =    (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_8].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER_P]  =       (UINT16)atol(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_9].cParaValue);

        psEEP->sUserSystemSetting.sImageSetting.ucLightsOutTimer        = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTSOUTTIMER].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel  = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTSOUTSIGNALLEVEL].cParaValue);
		psEEP->sUserSystemSetting.sImageSetting.ucLightsOnThreshold     = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTS_ON_THRESHOLD].cParaValue);	//A70Gen2_Doulas_0044
        psEEP->sUserSystemSetting.sImageSetting.ucCompatible_4K         = (UINT8)atol(m_sCommonGui[eCG_UCCOMPATIBLE_4K].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1           = (UINT8)GUI2CM(edcHDMI_EDID_1, (UINT8)atol(m_sCommonGui[eCG_UCHDMI_EDID_1].cParaValue));
        psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2           = (UINT8)GUI2CM(edcHDMI_EDID_2, (UINT8)atol(m_sCommonGui[eCG_UCHDMI_EDID_2].cParaValue));
        psEEP->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID          = (UINT8)GUI2CM(edcHDBASET_EDID, (UINT8)atol(m_sCommonGui[eCG_UCHDBaseT_EDID].cParaValue)); //G100_Steven_0005
		psEEP->sUserSystemSetting.sImageSetting.ucHDMI_OUT              = (UINT8)GUI2CM(edcHDMI_OUT, (UINT8)atol(m_sCommonGui[eCG_UCHDMI_OUT].cParaValue));
		psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern_2= (UINT8)atol(m_sCommonGui[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN_2].cParaValue);	//G100_Coda_00109

        psEEP->sUserSystemSetting.sImageSetting.ucHDRLevel              = (UINT8)GUI2CM(edcHDR_LEVEL, (UINT8)atol(m_sCommonGui[eCG_UCHDRLEVEL].cParaValue));
        psEEP->sUserSystemSetting.sImageSetting.ucHDREnable             = (UINT8)atol(m_sCommonGui[eCG_UCHDRENABLE].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucCW_Speed              = (UINT8)atol(m_sCommonGui[eCG_UCCW_SPEED].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucDBSpeed               = (UINT8)atol(m_sCommonGui[eCG_UCDBSPEED].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucDBStrength            = (UINT8)atol(m_sCommonGui[eCG_UCDBSTRENGTH].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucDBLightLevel          = (UINT8)atol(m_sCommonGui[eCG_UCDBLIGHTLEVEL].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable     = (UINT8)atol(m_sCommonGui[eCG_UCDBREALBLACKENABLE].cParaValue);
        psEEP->sUserSystemSetting.sImageSetting.ucDBSpeedControl        = (UINT8)atol(m_sCommonGui[eCG_UCDBSPEED_CONTROL].cParaValue);

        psEEP->sUserSystemSetting.sWarpSetting.ucWarpMode                   = (UINT8)atol(m_sWarping[eWI_UCWARPMODE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone           = (UINT8)atol(m_sWarping[eWI_UCWARPHORZKEYSTONE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone           = (UINT8)atol(m_sWarping[eWI_UCWARPVERTKEYSTONE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion         = (UINT8)atol(m_sWarping[eWI_UCWARPHORZPINCUSHION].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion         = (UINT8)atol(m_sWarping[eWI_UCWARPVERTPINCUSHION].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel       = (UINT8)atol(m_sWarping[eWI_UCWARPPINCUSHIONBARREL].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucGeometryPCMode             = (UINT8)atol(m_sWarping[eWI_UCGEOMETRYPCMODE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz         = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPLEFTHORZ].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert         = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPLEFTVERT].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz        = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPRIGHTHORZ].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert        = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPRIGHTVERT].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz      = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMLEFTHORZ].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert      = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMLEFTVERT].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz     = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTHORZ].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert     = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTVERT].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter             = (UINT8)atol(m_sWarping[eWI_UCWARPAUTOFILTER].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterH                = (UINT8)atol(m_sWarping[eWI_UCWARPFILTERH].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterV                = (UINT8)atol(m_sWarping[eWI_UCWARPFILTERV].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucMovePitchMode              = (UINT8)atol(m_sWarping[eWI_UCMOVEPITCHMODE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable          = (UINT8)atol(m_sWarping[eWI_UCBLENDINGTOPENABLE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel      = (UINT16)atol(m_sWarping[eWI_UIBLENDINGTOPSTARTPIXEL].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth      = (UINT16)atol(m_sWarping[eWI_UIBLENDINGTOPPIXELWIDTH].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable       = (UINT8)atol(m_sWarping[eWI_UCBLENDINGBOTTOMENABLE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel   = (UINT16)atol(m_sWarping[eWI_UIBLENDINGBOTTOMSTARTPIXEL].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth   = (UINT16)atol(m_sWarping[eWI_UIBLENDINGBOTTOMPIXELWIDTH].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable         = (UINT8)atol(m_sWarping[eWI_UCBLENDINGLEFTENABLE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel     = (UINT16)atol(m_sWarping[eWI_UIBLENDINGLEFTSTARTPIXEL].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth     = (UINT16)atol(m_sWarping[eWI_UIBLENDINGLEFTPIXELWIDTH].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable        = (UINT8)atol(m_sWarping[eWI_UCBLENDINGRIGHTENABLE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel    = (UINT16)atol(m_sWarping[eWI_UIBLENDINGRIGHTSTARTPIXEL].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth    = (UINT16)atol(m_sWarping[eWI_UIBLENDINGRIGHTPIXELWIDTH].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode         = (UINT8)atol(m_sWarping[eWI_UCAUTOADJUSTMENTMODE].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting        = (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLYSETTING].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting         = (UINT8)atol(m_sWarping[eWI_UCWARPINGSAVESETTING].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucWarpingLastSaved           = (UINT8)atol(m_sWarping[eWI_UCWARPINGLASTSAVED].cParaValue);  //A35G2_CDS_Simon_0008
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendingGamma              = (UINT8)GUI2CM(edcBLENDING_GAMMA, (UINT8)atol(m_sWarping[eWI_UCBLENDINGGAMMA].cParaValue));
        psEEP->sUserSystemSetting.sWarpSetting.ucGeometryEnable             = (UINT8)atol(m_sWarping[eWI_UCGEOMETRYENABLE].cParaValue);

        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_0].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_0].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_0].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_0].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_1].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_1].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_1].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_1].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_2].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_2].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_2].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_2].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_3].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_3].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_3].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_3].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_4].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_4].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_4].cParaValue);
        snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_4].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendApplySetting          = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLYSETTING].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting           = (UINT8)atol(m_sWarping[eWI_UCBLENDSAVESETTING].cParaValue);
        psEEP->sUserSystemSetting.sWarpSetting.ucBlendLastSaved             = (UINT8)atol(m_sWarping[eWI_UCBLENDLASTSAVED].cParaValue);     //A35G2_CDS_Simon_0008
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl           		= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_CONTROL].cParaValue);		//G100_Doulas_0027
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDPOINTS].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner           		= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_INNER].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_SHARPNESS].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDCOLOR].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor         = (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDBACKGROUND].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber   = (UINT8)atol(m_sWarping[eWI_UCADV_BLEND_OVERLAP_GRIDNUMBER].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma           	= (UINT8)atol(m_sWarping[eWI_UCADV_BLEND_GAMMA].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft           		= (UINT16)atol(m_sWarping[eWI_UIADV_BLEND_LEFT].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight           	= (UINT16)atol(m_sWarping[eWI_UIADV_BLEND_RIGHT].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop           		= (UINT16)atol(m_sWarping[eWI_UIADV_BLEND_TOP].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom           	= (UINT16)atol(m_sWarping[eWI_UIADV_BLEND_BOTTOM].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner_LastValue         = (UINT8)atol(m_sWarping[eWI_UCADV_WARP_INNER_LAST_VALUE].cParaValue);  //G100_Tim_0055, add //A35G2_BRC_Casper_0051

		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelArea           	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_AREA].cParaValue);							//A65_OPTOMA_Doulas_0020
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__TOP]   	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_ENABLE_TOP].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__BOTTOM]   = (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_ENABLE_BOTTOM].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__TOP]   		= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_RED_TOP].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__BOTTOM]   	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_RED_BOTTOM].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__TOP]   	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_GREEN_TOP].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__BOTTOM]   	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_GREEN_BOTTOM].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__TOP]   		= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_BLUE_TOP].cParaValue);
		psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__BOTTOM]   	= (UINT8)atol(m_sWarping[eWI_UCADV_BLACK_LEVEL_BLUE_BOTTOM].cParaValue);

        psEEP->sUserSystemSetting.sCommonSetting.ucLanguage                 = (UINT8)GUI2CM(edcLANGUAGE, (UINT8)atol(m_sCommonGui[eCG_UCLANGUAGE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucACPowerOn                = (UINT8)atol(m_sCommonGui[eCG_UCACPOWERON].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave         = (UINT8)GUI2CM(edcSTANDBY_MODE, (UINT8)atol(m_sCommonGui[eCG_UCSTANDBYPOWERSAVE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucProjectorAddress         = (UINT8)atol(m_sCommonGui[eCG_UCPROJECTORADDRESS].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucProjectorID              = (UINT8)atol(m_sCommonGui[eCG_UCPROJECTORID].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucKeypadBacklight          = (UINT8)atol(m_sCommonGui[eCG_UCKEYPADBACKLIGHT].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucStatusLED                = (UINT8)atol(m_sCommonGui[eCG_UCSTATUSLED].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucAutoOffTime              = (UINT8)atol(m_sCommonGui[eCG_UCAUTOOFFTIME].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucScreenSaveTime           = (UINT8)atol(m_sCommonGui[eCG_UCSCREENSAVETIME].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucSleepTimer               = (UINT8)atol(m_sCommonGui[eCG_UCSLEEPTIMER].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucChangePIN                = (UINT8)atol(m_sCommonGui[eCG_UCCHANGEPIN].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate       = (UINT8)GUI2CM(edcSERIAL_PORT_BAUD_RATE, (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTBAUDRATE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortEcho           = (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTECHO].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortPath           = (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTPATH].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Top            = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_TOP].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Front          = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_FRONT].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT        = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_HDBASET].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable            = (UINT8)atol(m_sCommonGui[eCG_UCHDBASETENABLE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucSysErrCode               = (UINT8)atol(m_sCommonGui[eCG_UCSYSERRCODE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.uc12VTrigge                = (UINT8)atol(m_sCommonGui[eCG_UC12VTRIGGE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLensAdjust               = (UINT8)atol(m_sCommonGui[eCG_UCLENSADJUST].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLensShift                = (UINT8)atol(m_sCommonGui[eCG_UCLENSSHIFT].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLensMemoryApply          = (UINT8)GUI2CM(edcLENS_APPLY_POSITION, (UINT8)atol(m_sCommonGui[eCG_UCLENSMEMORYAPPLY].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucLensMemorySave           = (UINT8)GUI2CM(edcLENS_SAVE_CURRENT_POSITION, (UINT8)atol(m_sCommonGui[eCG_UCLENSMEMORYSAVE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucHighAltitude             = (UINT8)atol(m_sCommonGui[eCG_UCHIGHALTITUDE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern       = (UINT8)atol(m_sCommonGui[eCG_UCFACTORYTESTPATTERN].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern   = (UINT8)GUI2CM(edcSERVICE_TEST_PATTERN, (UINT8)atol(m_sCommonGui[eCG_UCSERVICEMENUTESTPATTERN].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern = (UINT8)atol(m_sCommonGui[eCG_UCFACTORYMENUCUSTOMPATTERN].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable      = (UINT8)GUI2CM(edcSPLASH_STARTUP, (UINT8)atol(m_sCommonGui[eCG_UCSPLASHSTARTUPENABLE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucActuatorSwitch           = (UINT8)atol(m_sCommonGui[eCG_UCACTUATORSWITCH].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucCoolingDown              = (UINT8)atol(m_sCommonGui[eCG_UCCOOLINGDOWN].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucOSDTestPattern           = (UINT8)GUI2CM(edcOSDTEST_PATTERN, (UINT8)atol(m_sCommonGui[eCG_UCOSDTESTPATTERN].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucUartSwitch               = (UINT8)atol(m_sCommonGui[eCG_UCUARTSWITCH].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave        = (UINT8)atol(m_sCommonGui[eCG_UCBACKUPRESTORESAVE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore     = (UINT8)atol(m_sCommonGui[eCG_UCBACKUPRESTORERESTORE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLensDetection            = (UINT8)atol(m_sCommonGui[eCG_UCLENSDETECTION].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLowLatency               = (UINT8)GUI2CM(edcLOW_LATENCY_MODE, (UINT8)atol(m_sCommonGui[eCG_UCLOWLATENCY].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch         = (UINT8)atol(m_sCommonGui[eCG_BACKUP_INPUT_SWITCH].cParaValue);

        psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput       = (UINT8)atol(m_sCommonGui[eCG_BACKUP_PRIMARY_INPUT].cParaValue); //G100_Steven_0028
        psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput     = (UINT8)atol(m_sCommonGui[eCG_BACKUP_SECONDARY_INPUT].cParaValue);

        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput       = (UINT8)GUI2CM(edcMAIN_INPUT, (UINT8)atol(m_sCommonGui[eCG_BACKUP_PRIMARY_INPUT].cParaValue));
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput     = (UINT8)GUI2CM(edcSUB_INPUT,  (UINT8)atol(m_sCommonGui[eCG_BACKUP_SECONDARY_INPUT].cParaValue)); //G100_Steven_0028
        psEEP->sUserSystemSetting.sCommonSetting.ucBackgroundColor          = (UINT8)GUI2CM(edcBACKGROUND_COLOR,  (UINT8)atol(m_sCommonGui[eCG_BACKGROUND_COLOR].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucSignalPowerOn            = (UINT8)atol(m_sCommonGui[eCG_SIGNAL_POWERON].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin  = (UINT32)atol(m_sCommonGui[eCG_SECURITY_TOTALREMAINMIN].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucStartupShutter           = (UINT8)atol(m_sCommonGui[eCG_STARTUP_SHUTTER].cParaValue);
		psEEP->sUserSystemSetting.sCommonSetting.ucAutoSourceResync         = (UINT8)atol(m_sCommonGui[eCG_AUTO_SOURCE_RESYNC].cParaValue);	//G100_Doulas_0006
        psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortOut_BaudRate   = (UINT8)GUI2CM(edcSERIAL_PORT_OUT_BAUD_RATE, (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTOUT_BAUDRATE].cParaValue));
        psEEP->sUserSystemSetting.sCommonSetting.ucFadeIn_Time              = (UINT8)atol(m_sCommonGui[eCG_UCFADEIN_TIME].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucFadeOut_Time             = (UINT8)atol(m_sCommonGui[eCG_UCFADEOUT_TIME].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucPwrKeyBacklight          = (UINT8)atol(m_sCommonGui[eCG_UCPWRKEYBACKLIGHT].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucLogoChange               = (UINT8)atol(m_sCommonGui[eCG_UCLOGOCHANGE].cParaValue);
        psEEP->sUserSystemSetting.sCommonSetting.ucFast_Power_On            = (UINT8)atol(m_sCommonGui[eCG_UCFAST_POWER_ON].cParaValue);	//G100_Clare_0055

        psEEP->sUserSystemSetting.sCommonSetting.ucAuto_HDMI_Switch         = (UINT8)atol(m_sCommonGui[eCG_AUTO_HDMI_SWITCH].cParaValue);   //G100_Tim_0057, add, start //A35G2_BRC_Casper_0060
        psEEP->sUserSystemSetting.sCommonSetting.ucInput_Key_Last_Value     = (UINT8)atol(m_sCommonGui[eCG_INPUT_KEY_LAST_VALUE].cParaValue); //A35G2_BRC_Casper_0060
        psEEP->sUserSystemSetting.sCommonSetting.uc3D_Mode_Last_Value       = (UINT8)atol(m_sCommonGui[eCG_3D_MODE_LAST_VALUE].cParaValue); //G100_Tim_0057, add, end //A35G2_BRC_Casper_0060
        psEEP->sUserSystemSetting.sCommonSetting.ucProj_Native_Timing       = (UINT8)atol(m_sCommonGui[eCG_PROJ_NATIVE_TIMING].cParaValue); //G100_Tim_0058, add //A35G2_BRC_Casper_0060
        psEEP->sUserSystemSetting.sCommonSetting.ucLensSpeed                = (UINT8)atol(m_sCommonGui[eCG_UCLENSPEED].cParaValue);

        psEEP->sUserSystemSetting.sCommonSetting.ucAudioVolume              = (UINT8)atol(m_sCommonGui[eCG_UCAUDIO_VOLUME].cParaValue);// R70K_Bruce_0002
        psEEP->sUserSystemSetting.sCommonSetting.ucAudioMute                = (UINT8)atol(m_sCommonGui[eCG_UCAUDIO_MUTE].cParaValue);// R70K_Bruce_0002

        psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceMain          = (UINT8)GUI2CM(edcMAIN_INPUT, (UINT8)atol(m_sCommonGui[eCG_UCINPUTSOURCEMAIN].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceSub           = (UINT8)GUI2CM(edcSUB_INPUT,  (UINT8)atol(m_sCommonGui[eCG_UCINPUTSOURCESUB].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucPIPEnable                = (UINT8)GUI2CM(edcPIP_PBP_ENABLE, (UINT8)atol(m_sCommonGui[eCG_UCPIPENABLE].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucMainLayout                = (UINT8)GUI2CM(edcMAIN_LAYOUT, (UINT8)atol(m_sCommonGui[eCG_UCMAINLAYOUT].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucPIPLayout                = (UINT8)GUI2CM(edcMAIN_LAYOUT, (UINT8)atol(m_sCommonGui[eCG_UCPIPLAYOUT].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucPBPLayout                = (UINT8)GUI2CM(edcMAIN_LAYOUT, (UINT8)atol(m_sCommonGui[eCG_UCPBPLAYOUT].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucPIPSize                  = (UINT8)GUI2CM(edcSIZE, (UINT8)atol(m_sCommonGui[eCG_UCPIPSIZE].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucSourceKeyOption          = (UINT8)atol(m_sCommonGui[eCG_UCSOURCEKEYOPTION].cParaValue);
        psEEP->sUserSystemSetting.sSourceSetting.uiSourceInfo               = (UINT16)atol(m_sCommonGui[eCG_UISOURCEINFO].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucPowerUpSource            = (UINT8)atol(m_sCommonGui[eCG_UCPOWERUPSOURCE].cParaValue);
        psEEP->sUserSystemSetting.sSourceSetting.ucSourceLock               = (UINT8)atol(m_sCommonGui[eCG_UCSOURCELOCK].cParaValue);
        psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey                = (UINT8)GUI2CM(edcHOT_KEY_SETTINGS, (UINT8)atol(m_sCommonGui[eCG_UCCUSTOMKEY].cParaValue));
        psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey2               = (UINT8)GUI2CM(edcHOT_KEY2_SETTINGS, (UINT8)atol(m_sCommonGui[eCG_UCCUSTOMKEY2].cParaValue));  //G100_Wilsonj_0053
        psEEP->sUserSystemSetting.sSourceSetting.ucBlankKey                 = (UINT8)atol(m_sCommonGui[eCG_UCBLANKKEY].cParaValue);
        psEEP->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable       = (UINT8)atol(m_sCommonGui[eCG_UCSOURCEHOTKEYENABLE].cParaValue);

        psEEP->sUserSystemSetting.sNetworkSetting.ucShowNetworkMessages     = (UINT8)atol(m_sCommonGui[eCG_UCSHOWNETWORKMESSAGES].cParaValue);  //A70LK_Jacky_0011

        //Actuator
        psEEP->sActuatorSetting.ucDAC_AWC0              = (UINT8)atol(m_sActuator[eACT_DAC_AWC0].cParaValue);
        psEEP->sActuatorSetting.ulSubframeDelay_AWC0    = (UINT32)atol(m_sActuator[eACT_SFDELAY_AWC0].cParaValue);
        psEEP->sActuatorSetting.uiSegmentLength_AWC0    = (UINT16)atol(m_sActuator[eACT_SEGMENTLEN_AWC0].cParaValue);
        psEEP->sActuatorSetting.ucDAC_AWC1              = (UINT8)atol(m_sActuator[eACT_DAC_AWC1].cParaValue);
        psEEP->sActuatorSetting.ulSubframeDelay_AWC1    = (UINT32)atol(m_sActuator[eACT_SFDELAY_AWC1].cParaValue);
        psEEP->sActuatorSetting.uiSegmentLength_AWC1    = (UINT16)atol(m_sActuator[eACT_SEGMENTLEN_AWC1].cParaValue);


        for(iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
        {
            UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

            uiSourceNode = utilDataMgr_SourceCommonTablerGet(iCount);

            if(uiSourceNode != eDATA_NODE_NUMBER)
            {
                psPara = utilDataMgr_ParaTableGet(uiSourceNode);

                sprintf(psEEP->sUserSystemSetting.sSourceSetting.cSourceName[uiSrcIndex], "%s\0", psPara[eSCM_CSOURCENAME].cParaValue);

                //psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio        = (UINT8)GUI2CM(edcSIZE_PRESETS, (UINT8)atol(psPara[eSCM_UCASPECTRATIO].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio        = (UINT8)GUI2CM(edcSIZE_PRESETS, (UINT8)atol(psPara[eSCM_UCASPECTRATIO219].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucOverScan           = (UINT8)atol(psPara[eSCM_UCOVERSCAN].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPhase              = (UINT8)atol(psPara[eSCM_UCPHASE].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucTracking           = (UINT8)atol(psPara[eSCM_UCTRACKING].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucHorzPosition       = (UINT8)atol(psPara[eSCM_UCHORZPOSITION].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucVertPosition       = (UINT8)atol(psPara[eSCM_UCVERTPOSITION].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzZoom    = (UINT16)atol(psPara[eSCM_UIDIGITALHORZZOOM].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertZoom    = (UINT16)atol(psPara[eSCM_UIDIGITALVERTZOOM].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzShift   = (UINT8)atol(psPara[eSCM_UIDIGITALHORZSHIFT].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertShift   = (UINT8)atol(psPara[eSCM_UIDIGITALVERTSHIFT].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzZoom  = (UINT16)atol(psPara[eSCM_UICUSTOMDIGITALHORZZOOM].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertZoom  = (UINT16)atol(psPara[eSCM_UICUSTOMDIGITALVERTZOOM].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzShift = (UINT8)atol(psPara[eSCM_UICUSTOMDIGITALHORZSHIFT].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertShift = (UINT8)atol(psPara[eSCM_UICUSTOMDIGITALVERTSHIFT].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPresetMode         = (UINT8)GUI2CM(edcPICTURE_SETTINGS, atol(psPara[eSCM_UCPRESETMODE].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucBackupPreset       = (UINT8)atol(psPara[eSCM_UCBACKUPPRESET].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucSavePreset         = (UINT8)atol(psPara[eSCM_UCSAVEPRESET].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode        = (UINT8)GUI2CM(edcPICTURE_SETTINGS, atol(psPara[eSCM_UCPREUSERMODE].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Enable          = (UINT8)GUI2CM(edc3D_ENABLE, atol(psPara[eSCM_UC3D_ENABLE].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Invert          = (UINT8)atol(psPara[eSCM_UC3D_INVERT].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncOut         = (UINT8)GUI2CM(edc3D_SYNC_OUT, atol(psPara[eSCM_UC3D_SYNCOUT].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncIn          = (UINT8)GUI2CM(edc3D_SYNC_TYPE, atol(psPara[eSCM_UC3D_SYNCIN].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Reference       = (UINT8)GUI2CM(edc3D_LR_REFERENCE, atol(psPara[eSCM_UC3D_REFERENCE].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_2D_View         = (UINT8)GUI2CM(edc3D_2D, (UINT8)atol(psPara[eSCM_UC3D_2D_VIEW].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucEdgeMask           = (UINT8)atol(psPara[eSCM_UCEDGEMASK].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Mode            = (UINT8)GUI2CM(edc3D_MODE, atol(psPara[eSCM_UC3D_MODE].cParaValue));
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Tech            = (UINT8)atol(psPara[eSCM_UC3D_TECH].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAutoImage          = (UINT8)atol(psPara[eSCM_UCAUTOIMAGE].cParaValue);
                psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucDigitalZoomProp    = (UINT8)atol(psPara[eSCM_UCDIGITALZOOMPROP].cParaValue);
            }
        }

        for(iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
        {
            UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);  //for  psEEP->sUserSystemSetting  source index

            for(iCount2 = 0; iCount2 < eGUI_PICTURE_SETTINGS_NUMBER; iCount2++)
            {
                UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcPICTURE_SETTINGS, iCount2);

                uiSourceNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_COLOR, iCount, iCount2);

                if(uiSourceNode != eDATA_NODE_NUMBER)
                {
                    psPara = utilDataMgr_ParaTableGet(uiSourceNode);

                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS                      = (UINT8)GUI2CM(edcCOLOR_SPACE, (UINT8)atol(psPara[eSCR_UCCS].cParaValue));
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT                      = (UINT8)GUI2CM(edcCOLOR_TEMPERATURE, (UINT8)atol(psPara[eSCR_UCCT].cParaValue));
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma                   = (UINT8)GUI2CM(edcGAMMA, (UINT8)atol(psPara[eSCR_UCGAMMA].cParaValue));
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled   = (UINT8)atol(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking            = (UINT8)atol(psPara[eSCR_UCWHITEPEAKING].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement        = (UINT8)atol(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor               = (UINT8)atol(psPara[eSCR_UCSKINCOLOR].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness               = (UINT8)atol(psPara[eSCR_UCSHARPNESS].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness              = (UINT8)atol(psPara[eSCR_UCBRIGHTNESS].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast                = (UINT8)atol(psPara[eSCR_UCCONTRAST].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint                    = (UINT8)atol(psPara[eSCR_UCTINT].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation              = (UINT8)atol(psPara[eSCR_UCSATURATION].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain                 = (UINT8)atol(psPara[eSCR_UCREDGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain               = (UINT8)atol(psPara[eSCR_UCGREENGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain                = (UINT8)atol(psPara[eSCR_UCBLUEGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset               = (UINT8)atol(psPara[eSCR_UCREDOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset             = (UINT8)atol(psPara[eSCR_UCGREENOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset              = (UINT8)atol(psPara[eSCR_UCBLUEOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet            = (UINT8)GUI2CM(edcWALL_COLOR, (UINT8)atol(psPara[eSCR_UCWALLCOLORSET].cParaValue));  //G100_Steven_0047
                }

                uiSourceNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_HSG, iCount, iCount2);

                if(uiSourceNode != eDATA_NODE_NUMBER)
                {
                    psPara = utilDataMgr_ParaTableGet(uiSourceNode);

                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE       = (UINT8)atol(psPara[eHSG_R_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT       = (UINT8)atol(psPara[eHSG_R_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN      = (UINT8)atol(psPara[eHSG_R_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE       = (UINT8)atol(psPara[eHSG_G_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT       = (UINT8)atol(psPara[eHSG_G_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN      = (UINT8)atol(psPara[eHSG_G_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE       = (UINT8)atol(psPara[eHSG_B_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT       = (UINT8)atol(psPara[eHSG_B_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN      = (UINT8)atol(psPara[eHSG_B_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE       = (UINT8)atol(psPara[eHSG_C_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT       = (UINT8)atol(psPara[eHSG_C_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN      = (UINT8)atol(psPara[eHSG_C_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE       = (UINT8)atol(psPara[eHSG_M_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT       = (UINT8)atol(psPara[eHSG_M_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN      = (UINT8)atol(psPara[eHSG_M_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE       = (UINT8)atol(psPara[eHSG_Y_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT       = (UINT8)atol(psPara[eHSG_Y_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN      = (UINT8)atol(psPara[eHSG_Y_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN    = (UINT8)atol(psPara[eHSG_W_R_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN    = (UINT8)atol(psPara[eHSG_W_G_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN    = (UINT8)atol(psPara[eHSG_W_B_GAIN].cParaValue);
                }
                //G100_Steven_0016 start
                if(iCount2 >= eGUI_PRE_USERS_NUMBER)		//G100_Doulas_0066
				{
					continue;
				}
                uiPresetModeIndex = (UINT16)GUI2CM(edcUSER_COLOR_MODE, iCount2);	//G100_Doulas_0066 Add

                uiSourceNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_COLOR, iCount, iCount2);
                if(uiSourceNode != eDATA_NODE_NUMBER)
                {
                    psPara = utilDataMgr_ParaTableGet(uiSourceNode);

                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS                      = (UINT8)GUI2CM(edcCOLOR_SPACE, (UINT8)atol(psPara[eSCR_UCCS].cParaValue));
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT                      = (UINT8)GUI2CM(edcCOLOR_TEMPERATURE, (UINT8)atol(psPara[eSCR_UCCT].cParaValue));
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma                   = (UINT8)GUI2CM(edcGAMMA, (UINT8)atol(psPara[eSCR_UCGAMMA].cParaValue));
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled   = (UINT8)atol(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking            = (UINT8)atol(psPara[eSCR_UCWHITEPEAKING].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement        = (UINT8)atol(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor               = (UINT8)atol(psPara[eSCR_UCSKINCOLOR].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness               = (UINT8)atol(psPara[eSCR_UCSHARPNESS].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness              = (UINT8)atol(psPara[eSCR_UCBRIGHTNESS].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast                = (UINT8)atol(psPara[eSCR_UCCONTRAST].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint                    = (UINT8)atol(psPara[eSCR_UCTINT].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation              = (UINT8)atol(psPara[eSCR_UCSATURATION].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain                 = (UINT8)atol(psPara[eSCR_UCREDGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain               = (UINT8)atol(psPara[eSCR_UCGREENGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain                = (UINT8)atol(psPara[eSCR_UCBLUEGAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset               = (UINT8)atol(psPara[eSCR_UCREDOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset             = (UINT8)atol(psPara[eSCR_UCGREENOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset              = (UINT8)atol(psPara[eSCR_UCBLUEOFFSET].cParaValue);
                    psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet            = (UINT8)GUI2CM(edcWALL_COLOR, (UINT8)atol(psPara[eSCR_UCWALLCOLORSET].cParaValue));  //G100_Steven_0047
                } //G100_Steven_0016 end
 //G100_Steven_0020 start

                uiSourceNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_HSG, iCount, iCount2);
                if(uiSourceNode != eDATA_NODE_NUMBER) //G100_Steven_0037
                {
                    psPara = utilDataMgr_ParaTableGet(uiSourceNode); //G100_Steven_0035

                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE       = (UINT8)atol(psPara[eHSG_R_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT       = (UINT8)atol(psPara[eHSG_R_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN      = (UINT8)atol(psPara[eHSG_R_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE       = (UINT8)atol(psPara[eHSG_G_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT       = (UINT8)atol(psPara[eHSG_G_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN      = (UINT8)atol(psPara[eHSG_G_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE       = (UINT8)atol(psPara[eHSG_B_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT       = (UINT8)atol(psPara[eHSG_B_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN      = (UINT8)atol(psPara[eHSG_B_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE       = (UINT8)atol(psPara[eHSG_C_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT       = (UINT8)atol(psPara[eHSG_C_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN      = (UINT8)atol(psPara[eHSG_C_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE       = (UINT8)atol(psPara[eHSG_M_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT       = (UINT8)atol(psPara[eHSG_M_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN      = (UINT8)atol(psPara[eHSG_M_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE       = (UINT8)atol(psPara[eHSG_Y_HUE].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT       = (UINT8)atol(psPara[eHSG_Y_SAT].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN      = (UINT8)atol(psPara[eHSG_Y_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN    = (UINT8)atol(psPara[eHSG_W_R_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN    = (UINT8)atol(psPara[eHSG_W_G_GAIN].cParaValue);
                    psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN    = (UINT8)atol(psPara[eHSG_W_B_GAIN].cParaValue);
                }  //G100_Steven_0020 end
            }
        }

        //Tec Gating info
        psEEP->sTecGating.ucTEC_GATING_CNT = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CNT].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[0] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE0].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[1] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE1].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[2] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE2].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[3] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE3].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[4] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE4].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[5] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE5].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[6] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE6].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[7] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE7].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[8] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE8].cParaValue);
        psEEP->sTecGating.ucTEC_GATING_CYCLE[9] = (UINT32)atol(m_sTEC_GATING[eTEC_GATING_CYCLE9].cParaValue);

        //WAP
        psEEP->uCCT_Table.sDataStruct.ulCCT_Tag = (UINT32)atol(m_sWAP_Calibration_Tag[eWAP_CALIBRATION_TAG].cParaValue);
        psEEP->uCCT_Table.sDataStruct.uiCCT_CRC = (UINT16)atol(m_sWAP_Calibration_Tag[eWAP_CRC].cParaValue);

        for(iCount = 0; iCount < eWAP_UICHECKSUM; iCount++)
        {
            for(iCount2 = 0; iCount2 < eIFC_WAP_NUMBER; iCount2++)
            {
                psEEP->uCCT_Table.sDataStruct.ucRatioData[iCount2][iCount+1] = (UINT8)atol(m_sWAP_RatioData[iCount2].sPresetMode[iCount].cParaValue);
                psEEP->uCCT_Table.sDataStruct.ucOffsetData[iCount2][iCount+1] = (UINT8)atol(m_sWAP_OffsetData[iCount2].sPresetMode[iCount].cParaValue);
                psEEP->uCCT_Table.sDataStruct.uiPWMData[iCount2][iCount] = (UINT16)atol(m_sWAP_PWMData[iCount2].sPresetMode[iCount].cParaValue);
            }
        }

		utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileSystemCal(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_SYSTEMCAL == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_SYSTEMCAL == eNode))
    {
        //System Cal
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET_0].cParaValue,  "%d", psEEP->sADC_cal_values.uiRGBOffset[0]);
        sprintf(m_sSystemCal[eSC_UIYUVOFFSET_0].cParaValue,  "%d", psEEP->sADC_cal_values.uiYUVOffset[0]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue, "%d", psEEP->sADC_cal_values.uiRGBOffset2[0]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue, "%d", psEEP->sADC_cal_values.uiYUVOffset2[0]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET_1].cParaValue,  "%d", psEEP->sADC_cal_values.uiRGBOffset[1]);
        sprintf(m_sSystemCal[eSC_UIYUVOFFSET_1].cParaValue,  "%d", psEEP->sADC_cal_values.uiYUVOffset[1]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue, "%d", psEEP->sADC_cal_values.uiRGBOffset2[1]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue, "%d", psEEP->sADC_cal_values.uiYUVOffset2[1]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET_2].cParaValue,  "%d", psEEP->sADC_cal_values.uiRGBOffset[2]);
        sprintf(m_sSystemCal[eSC_UIYUVOFFSET_2].cParaValue,  "%d", psEEP->sADC_cal_values.uiYUVOffset[2]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue, "%d", psEEP->sADC_cal_values.uiRGBOffset2[2]);
        sprintf(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue, "%d", psEEP->sADC_cal_values.uiYUVOffset2[2]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN_0].cParaValue,    "%d", psEEP->sADC_cal_values.uiRGBGain[0]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN_1].cParaValue,    "%d", psEEP->sADC_cal_values.uiRGBGain[1]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN_2].cParaValue,    "%d", psEEP->sADC_cal_values.uiRGBGain[2]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN_0].cParaValue,    "%d", psEEP->sADC_cal_values.uiYUVGain[0]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN_1].cParaValue,    "%d", psEEP->sADC_cal_values.uiYUVGain[1]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN_2].cParaValue,    "%d", psEEP->sADC_cal_values.uiYUVGain[2]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN2_0].cParaValue,   "%d", psEEP->sADC_cal_values.uiRGBGain2[0]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN2_1].cParaValue,   "%d", psEEP->sADC_cal_values.uiRGBGain2[1]);
        sprintf(m_sSystemCal[eSC_UIRGBGAIN2_2].cParaValue,   "%d", psEEP->sADC_cal_values.uiRGBGain2[2]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN2_0].cParaValue,   "%d", psEEP->sADC_cal_values.uiYUVGain2[0]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN2_1].cParaValue,   "%d", psEEP->sADC_cal_values.uiYUVGain2[1]);
        sprintf(m_sSystemCal[eSC_UIYUVGAIN2_2].cParaValue,   "%d", psEEP->sADC_cal_values.uiYUVGain2[2]);

        sprintf(m_sSystemCal[eSC_UIFWINDEX_0].cParaValue, "%d", psEEP->sSystemDefault.uiFWIndex[0]);
        sprintf(m_sSystemCal[eSC_UIFWINDEX_1].cParaValue, "%d", psEEP->sSystemDefault.uiFWIndex[1]);
        sprintf(m_sSystemCal[eSC_UIPWINDEX_0].cParaValue, "%d", psEEP->sSystemDefault.uiPWIndex[0]);
        sprintf(m_sSystemCal[eSC_UIPWINDEX_1].cParaValue, "%d", psEEP->sSystemDefault.uiPWIndex[1]);

        sprintf(m_sSystemCal[eSC_UCPOWER_OFFSET].cParaValue, "%d",psEEP->sSystemDefault.ucPOWER_OFFSET);
        sprintf(m_sSystemCal[eSC_UCCOLOR_OFFSET].cParaValue, "%d",psEEP->sSystemDefault.ucCOLOR_OFFSET);

        sprintf(m_sSystemCal[eSC_UCABP_CALIBRATEFLAG].cParaValue, "%d", psEEP->sSystemDefault.ucABP_CalibrateFlag);

        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue, "%d",  psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_R].cParaValue, "%d",  psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_B].cParaValue, "%d",  psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_G].cParaValue, "%d",  psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue,   "%d",  psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_R].cParaValue,   "%d",  psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_B].cParaValue,   "%d",  psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_G].cParaValue,   "%d",  psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_Y].cParaValue,    "%d",  psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_R].cParaValue,    "%d",  psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_B].cParaValue,    "%d",  psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_G].cParaValue,    "%d",  psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue,  "%d", psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_R].cParaValue,  "%d", psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_B].cParaValue,  "%d", psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_G].cParaValue,  "%d", psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_R].cParaValue,  "%d",   psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_B].cParaValue,  "%d",   psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_G].cParaValue,  "%d",   psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_Y].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_R].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_B].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_G].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORTIME_Y].cParaValue,   "%d",   psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_Y]);         //A65_OPTOMA_Doulas_0105 start
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORTIME_R].cParaValue,   "%d",   psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORTIME_B].cParaValue,   "%d",   psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORTIME_G].cParaValue,   "%d",   psEEP->sSystemDefault.ucLightSensorTime[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_Y].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_R].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_B].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_G].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTarget[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_RY].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTargetRLD[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UILIGHTSENSORTARGET_RR].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorTargetRLD[eLD_SEQ_R]);    //A65_OPTOMA_Doulas_0105 end
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_Y].cParaValue,   "%f",   psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_Y]);       //A70G2_Owen_0002 Start
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_R].cParaValue,   "%f",   psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_B].cParaValue,   "%f",   psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSORGAIN_G].cParaValue,   "%f",   psEEP->sSystemDefault.afiLightSensorGain[eLD_SEQ_G]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_Y].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_Y]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_R].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_R]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_B].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_B]);
        sprintf(m_sSystemCal[eSC_UCLIGHTSENSOROFFSET_G].cParaValue,   "%d",   psEEP->sSystemDefault.uiLightSensorOffset[eLD_SEQ_G]);    //A70G2_Owen_0002 End
        sprintf(m_sSystemCal[eSC_UCUST].cParaValue,   "%d",   psEEP->sSystemDefault.ucUST_LensInstallType); //A35G2_BRC_Casper_0089
        //sprintf(m_sSystemCal[eSC_LENS_CALIBRATION_STATUS].cParaValue, "%d", psEEP->sSystemDefault.ucLensCalibrationStatus); //R70G2_AC_0032

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

}

void utilDataMgr_RAMToFileBurnin(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_BURNIN == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_BURNIN == eNode))
    {
        //Burnin
        sprintf(m_sBurnin[eBI_URNINENABLE].cParaValue,      "%d", psEEP->sBurin_Information.ucBurnInEnable);
        sprintf(m_sBurnin[eBI_UCLAMPON].cParaValue,         "%d", psEEP->sBurin_Information.ucLampOn);
        sprintf(m_sBurnin[eBI_UCLAMPOFF].cParaValue,        "%d", psEEP->sBurin_Information.ucLampOff);
        sprintf(m_sBurnin[eBI_UIBURNINCYCLE].cParaValue,    "%d", psEEP->sBurin_Information.uiBurnInCycle);
        sprintf(m_sBurnin[eBI_UCBURNINMODE].cParaValue,     "%d", psEEP->sBurin_Information.ucBurnInMode);
        sprintf(m_sBurnin[eBI_UCBURNINALWAYSON].cParaValue, "%d", psEEP->sBurin_Information.ucBurnInAlwaysOn);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileProjectorInfo(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_PROJECTORINFO == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_PROJECTORINFO == eNode))
    {
        //sLayoutVersion
        //sprintf(m_sProjectorInfo[ePI_UCMODELNAME].cParaValue, "%s\0", psEEP->sUserSystemSetting.sCommonSetting.ucModelName);
        //sprintf(m_sProjectorInfo[ePI_UCCUSTOM_CODE].cParaValue, "%s\0", psEEP->sUserSystemSetting.sCommonSetting.ucCustomCode);
        //sprintf(m_sProjectorInfo[ePI_UCSERIALNUMBER].cParaValue, "%s\0", psEEP->sSystemDefault.ucSerialNumber);

        sprintf(m_sProjectorInfo[ePI_UCSUBMINOR].cParaValue, "%d", psEEP->sLayoutVersion.ucSubminor);
        sprintf(m_sProjectorInfo[ePI_UCMINOR].cParaValue,    "%d", psEEP->sLayoutVersion.ucMinor);
        sprintf(m_sProjectorInfo[ePI_UCMAJOR].cParaValue,    "%d", psEEP->sLayoutVersion.ucMajor);
		sprintf(m_sProjectorInfo[ePI_UCMODEL_SWITCH].cParaValue, "%d\0", psEEP->sSystemDefault.ucModelSwitchAdjust);   //A65_OPTOMA_Julie_0064

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileAutoBrightness(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_AUTOBRIGHTNESS == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_AUTOBRIGHTNESS == eNode))
    {
        //m_sAutoBrightness     //G100_Doulas_0010 Add
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_Y].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_R].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_B].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_G].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_Y].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[4]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_R].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[5]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_B].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[6]);
        sprintf(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_G].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[7]);

        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_Y].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_R].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_B].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_G].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G]);

        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_Y].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_R].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_B].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_G].cParaValue, "%d", psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G]);

        //G100_Doulas_0023 Add
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G]);

        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G]);

        sprintf(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G]);

        sprintf(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_Y].cParaValue, "%d", psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_R].cParaValue, "%d", psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_B].cParaValue, "%d", psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B]);
        sprintf(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_G].cParaValue, "%d", psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G]);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

}

void utilDataMgr_RAMToFileStartup(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_STARTUP == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_STARTUP == eNode))
    {
        //System Default
        sprintf(m_sStartup[eSU_UCFIRSTSTARTUPFLAG].cParaValue, "%d\0",  psEEP->sSystemDefault.ucFirstStartupFlag);
        sprintf(m_sStartup[eSU_UCPINPROTECT].cParaValue, "%d\0",  psEEP->sSystemDefault.ucPINProtect );

        strncpy(m_sStartup[eSU_UCPASSWORD_0].cParaValue, &psEEP->sSystemDefault.ucPassWord[0], 1);
        strncpy(m_sStartup[eSU_UCPASSWORD_1].cParaValue, &psEEP->sSystemDefault.ucPassWord[1], 1);
        strncpy(m_sStartup[eSU_UCPASSWORD_2].cParaValue, &psEEP->sSystemDefault.ucPassWord[2], 1);
        strncpy(m_sStartup[eSU_UCPASSWORD_3].cParaValue, &psEEP->sSystemDefault.ucPassWord[3], 1);
        strncpy(m_sStartup[eSU_UCPASSWORD_4].cParaValue, &psEEP->sSystemDefault.ucPassWord[4], 1);

        sprintf(m_sStartup[eSU_OPFU_CHECK].cParaValue, "%d\0",  psEEP->sSystemDefault.ucOPFU_Check );   //G100_Simon_0064

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileSystemHours(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_SYSTEMHOURS == eNode);

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        //SystemHours
        sprintf(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue, "%d", psEEP->sSystemDefault.ulTotalProjectorMinute);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTE_B].cParaValue,  "%d", psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_BLD]);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTE_R].cParaValue,  "%d", psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_RLD]);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTENORMAL].cParaValue,   "%d", psEEP->sSystemDefault.ulLightSourceMinuteNormal);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTEECO].cParaValue,      "%d", psEEP->sSystemDefault.ulLightSourceMinuteEco);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTEQUIET].cParaValue,    "%d", psEEP->sSystemDefault.ulLightSourceMinuteQuiet);
        sprintf(m_sSystemHours[eSH_ULLIGHTSOURCEMINUTECUSTOM].cParaValue,   "%d", psEEP->sSystemDefault.ulLightSourceMinuteCustom);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

#if 0
void utilDataMgr_RAMToFileCommonGui(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_COMMONGUI == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_COMMONGUI == eNode))
    {
        //Gui
        sprintf(m_sCommonGui[eCG_UCLENSTYPE].cParaValue, "%d",psEEP->sSystemDefault.ucLensType);

        sprintf(m_sCommonGui[eCG_ULDBMASK].cParaValue, "%llu", psEEP->sSystemDefault.ulDbMask);

        sprintf(m_sCommonGui[eCG_UCPANEL].cParaValue, "%d", psEEP->sSystemDefault.ucPanel);

        sprintf(m_sCommonGui[eCG_UCEQMODE_HDMI1].cParaValue, "%d", psEEP->sSystemDefault.ucEQ_HDMI1);
        sprintf(m_sCommonGui[eCG_UCEQMODE_HDMI2].cParaValue, "%d", psEEP->sSystemDefault.ucEQ_HDMI2);
        sprintf(m_sCommonGui[eCG_UCEQMODE_DVI].cParaValue, "%d", psEEP->sSystemDefault.ucEQ_DVI);

        sprintf(m_sCommonGui[eCG_UCPOWERMODE].cParaValue,               "%d",  CM2GUI(edcPOWER_MODE, psEEP->sUserSystemSetting.sLightSetting.ucPowerMode));
        sprintf(m_sCommonGui[eCG_UCWAVEFORMGAIN].cParaValue,            "%d",  psEEP->sUserSystemSetting.sLightSetting.ucWaveformGain);
        sprintf(m_sCommonGui[eCG_UCIRWAVEFORMGAIN].cParaValue,          "%d",  psEEP->sUserSystemSetting.sLightSetting.ucIRWaveformGain);
        sprintf(m_sCommonGui[eCG_UCIRMODE_WAVEFORMGAIN].cParaValue,     "%d",  psEEP->sUserSystemSetting.sLightSetting.ucIRMode_WaveformGain);
        sprintf(m_sCommonGui[eCG_UCIRMODE_IRWAVEFORMGAIN].cParaValue,   "%d",  psEEP->sUserSystemSetting.sLightSetting.ucIRMode_IRWaveformGain);
        sprintf(m_sCommonGui[eCG_UCIRLD].cParaValue,                    "%d",  psEEP->sUserSystemSetting.sLightSetting.ucIRLD);
        sprintf(m_sCommonGui[eCG_UCIRBLD].cParaValue,                   "%d",  psEEP->sUserSystemSetting.sLightSetting.ucIRBLD);
        sprintf(m_sCommonGui[eCG_UCLIGHTCALIBRATIONMODE].cParaValue,    "%d",  psEEP->sUserSystemSetting.sLightSetting.ucLightCalibrationMode);
        sprintf(m_sCommonGui[eCG_CONSTANT_BRIGHTNESS].cParaValue,       "%d",  psEEP->sUserSystemSetting.sLightSetting.ucConstantBrightness);       //G100_Doulas_0008

        sprintf(m_sCommonGui[eCG_UCMENULOCATION].cParaValue ,"%d",  CM2GUI(edcMENU_LOCATION, psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLocation));
        sprintf(m_sCommonGui[eCG_UCOSDTRANSLUCENCY].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTranslucency);
        sprintf(m_sCommonGui[eCG_UCOSDTIMEOUT].cParaValue   ,"%d",  CM2GUI(edcMENU_TIME_OUT, psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTimeout));
        sprintf(m_sCommonGui[eCG_UCSHOWMESSAGES].cParaValue ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucShowMessages);
        sprintf(m_sCommonGui[eCG_UCMENUOFFSETX].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX);
        sprintf(m_sCommonGui[eCG_UCMENUOFFSETY].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY);
        sprintf(m_sCommonGui[eCG_UCMENULOCKOUT].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLockout);
        sprintf(m_sCommonGui[eCG_UCMENUTRANSPARENCY].cParaValue ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucMenuTransparency);
        sprintf(m_sCommonGui[eCG_UCSEARCHSCREEN].cParaValue ,"%d",  psEEP->sUserSystemSetting.sOSD_Setting.ucSearchScreen);

        sprintf(m_sCommonGui[eCG_UCHSGADJUSTMENTENABLE].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable);
        sprintf(m_sCommonGui[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN].cParaValue ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern);
        sprintf(m_sCommonGui[eCG_UCHSGSELECTED].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucHSGSelected);
        sprintf(m_sCommonGui[eCG_CUSTOMEDID_HDMI1_STATUS].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucCustomizeEDID_HDMI1);  //A35G2_SImon_0091
        sprintf(m_sCommonGui[eCG_CUSTOMEDID_HDMI2_STATUS].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucCustomizeEDID_HDMI2);  //A35G2_SImon_0091

        sprintf(m_sCommonGui[eCG_UCBLANKONSIGNALSWITCH].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch);
        sprintf(m_sCommonGui[eCG_UCSYNCTHRESHOLD].cParaValue    ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucSyncThreshold);
        sprintf(m_sCommonGui[eCG_UCCONTRASTENHANCEMENT].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucContrastEnhancement);
        sprintf(m_sCommonGui[eCG_UCFILM].cParaValue ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucFilm);
        sprintf(m_sCommonGui[eCG_UCWALLCOLOR].cParaValue    ,"%d",  CM2GUI(edcWALL_COLOR, psEEP->sUserSystemSetting.sImageSetting.ucWallColor));
        sprintf(m_sCommonGui[eCG_UCIMAGEFREEZE].cParaValue  ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucImageFreeze);

        sprintf(m_sCommonGui[eCG_UCCEILINGMOUNT].cParaValue ,"%d",  CM2GUI(edcCEILING_MOUNT, psEEP->sUserSystemSetting.sImageSetting.ucCeilingMount));
        sprintf(m_sCommonGui[eCG_UCREARPROJECT].cParaValue  ,"%d",  CM2GUI(edcREAR_PROJECTION, psEEP->sUserSystemSetting.sImageSetting.ucRearProject));

        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_0].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_1].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_2].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_3].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_4].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_5].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D_P]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_6].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D_P]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_7].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120_P]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_8].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER_P]);
        sprintf(m_sCommonGui[eCG_UI3DFRAME_DELAY_TIMING_9].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER_P]);

        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_0].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_1].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_2].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_3].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_4].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_5].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D_P]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_6].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D_P]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_7].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120_P]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_8].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER_P]);
        sprintf(m_sCommonGui[eCG_UI3DSYNC_DELAY_TIMING_9].cParaValue,  "%d",  psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER_P]);


        sprintf(m_sCommonGui[eCG_UCLIGHTSOUTTIMER].cParaValue,      "%d",  psEEP->sUserSystemSetting.sImageSetting.ucLightsOutTimer);
        sprintf(m_sCommonGui[eCG_UCLIGHTSOUTSIGNALLEVEL].cParaValue,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel);
		sprintf(m_sCommonGui[eCG_UCLIGHTS_ON_THRESHOLD].cParaValue, "%d",  psEEP->sUserSystemSetting.sImageSetting.ucLightsOnThreshold);	//A70Gen2_Doulas_0044
        sprintf(m_sCommonGui[eCG_UCCOMPATIBLE_4K].cParaValue,       "%d",  psEEP->sUserSystemSetting.sImageSetting.ucCompatible_4K);
        sprintf(m_sCommonGui[eCG_UCHDMI_EDID_1].cParaValue,         "%d",  CM2GUI(edcHDMI_EDID_1, psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1));
        sprintf(m_sCommonGui[eCG_UCHDMI_EDID_2].cParaValue,         "%d",  CM2GUI(edcHDMI_EDID_2, psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2));
        sprintf(m_sCommonGui[eCG_UCHDBaseT_EDID].cParaValue,        "%d",  CM2GUI(edcHDBASET_EDID, psEEP->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID)); //G100_Steven_0005
        sprintf(m_sCommonGui[eCG_UCHDMI_OUT].cParaValue,            "%d",  CM2GUI(edcHDMI_OUT, psEEP->sUserSystemSetting.sImageSetting.ucHDMI_OUT));
        sprintf(m_sCommonGui[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN_2].cParaValue ,"%d",  psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern_2);	//G100_Coda_00109

        sprintf(m_sCommonGui[eCG_UCHDRLEVEL].cParaValue,            "%d",  CM2GUI(edcHDR_LEVEL, psEEP->sUserSystemSetting.sImageSetting.ucHDRLevel));
        sprintf(m_sCommonGui[eCG_UCHDRENABLE].cParaValue,           "%d",  psEEP->sUserSystemSetting.sImageSetting.ucHDREnable);
        sprintf(m_sCommonGui[eCG_UCCW_SPEED].cParaValue,            "%d",  psEEP->sUserSystemSetting.sImageSetting.ucCW_Speed);
        sprintf(m_sCommonGui[eCG_UCDBSPEED].cParaValue,             "%d",  psEEP->sUserSystemSetting.sImageSetting.ucDBSpeed);
        sprintf(m_sCommonGui[eCG_UCDBSTRENGTH].cParaValue,          "%d",  psEEP->sUserSystemSetting.sImageSetting.ucDBStrength);
        sprintf(m_sCommonGui[eCG_UCDBLIGHTLEVEL].cParaValue,        "%d",  psEEP->sUserSystemSetting.sImageSetting.ucDBLightLevel);
        sprintf(m_sCommonGui[eCG_UCDBREALBLACKENABLE].cParaValue,   "%d",  psEEP->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable);
        sprintf(m_sCommonGui[eCG_UCDBSPEED_CONTROL].cParaValue,     "%d",  psEEP->sUserSystemSetting.sImageSetting.ucDBSpeedControl);

        sprintf(m_sCommonGui[eCG_UCLANGUAGE].cParaValue , "%d", CM2GUI(edcLANGUAGE, psEEP->sUserSystemSetting.sCommonSetting.ucLanguage));
        sprintf(m_sCommonGui[eCG_UCACPOWERON].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucACPowerOn);
        sprintf(m_sCommonGui[eCG_UCSTANDBYPOWERSAVE].cParaValue , "%d", CM2GUI(edcSTANDBY_MODE, psEEP->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave));
        sprintf(m_sCommonGui[eCG_UCPROJECTORADDRESS].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucProjectorAddress);
        sprintf(m_sCommonGui[eCG_UCPROJECTORID].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucProjectorID);
        sprintf(m_sCommonGui[eCG_UCKEYPADBACKLIGHT].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucKeypadBacklight);
        sprintf(m_sCommonGui[eCG_UCSTATUSLED].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucStatusLED);
        sprintf(m_sCommonGui[eCG_UCAUTOOFFTIME].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucAutoOffTime);
        sprintf(m_sCommonGui[eCG_UCSCREENSAVETIME].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucScreenSaveTime);
        sprintf(m_sCommonGui[eCG_UCSLEEPTIMER].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucSleepTimer);
        sprintf(m_sCommonGui[eCG_UCCHANGEPIN].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucChangePIN);
        sprintf(m_sCommonGui[eCG_UCSERIALPORTBAUDRATE].cParaValue   , "%d", CM2GUI(edcSERIAL_PORT_BAUD_RATE, psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate));
        sprintf(m_sCommonGui[eCG_UCSERIALPORTECHO].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortEcho);
        sprintf(m_sCommonGui[eCG_UCSERIALPORTPATH].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortPath);
        sprintf(m_sCommonGui[eCG_UCIRCONTROL_TOP].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Top);
        sprintf(m_sCommonGui[eCG_UCIRCONTROL_FRONT].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Front);
        sprintf(m_sCommonGui[eCG_UCIRCONTROL_HDBASET].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT);
        sprintf(m_sCommonGui[eCG_UCHDBASETENABLE].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable);
        sprintf(m_sCommonGui[eCG_UCSYSERRCODE].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucSysErrCode);
        sprintf(m_sCommonGui[eCG_UC12VTRIGGE].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.uc12VTrigge);
        sprintf(m_sCommonGui[eCG_UCLENSADJUST].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucLensAdjust);
        sprintf(m_sCommonGui[eCG_UCLENSSHIFT].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucLensShift);
        sprintf(m_sCommonGui[eCG_UCLENSMEMORYAPPLY].cParaValue  , "%d", CM2GUI(edcLENS_APPLY_POSITION, psEEP->sUserSystemSetting.sCommonSetting.ucLensMemoryApply));
        sprintf(m_sCommonGui[eCG_UCLENSMEMORYSAVE].cParaValue   , "%d", CM2GUI(edcLENS_SAVE_CURRENT_POSITION, psEEP->sUserSystemSetting.sCommonSetting.ucLensMemorySave));
        sprintf(m_sCommonGui[eCG_UCHIGHALTITUDE].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucHighAltitude);
        sprintf(m_sCommonGui[eCG_UCFACTORYTESTPATTERN].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern);
        sprintf(m_sCommonGui[eCG_UCSERVICEMENUTESTPATTERN].cParaValue   , "%d", CM2GUI(edcSERVICE_TEST_PATTERN, psEEP->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern));
        sprintf(m_sCommonGui[eCG_UCFACTORYMENUCUSTOMPATTERN].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern);
        sprintf(m_sCommonGui[eCG_UCSPLASHSTARTUPENABLE].cParaValue  , "%d", CM2GUI(edcSPLASH_STARTUP, psEEP->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable));
        sprintf(m_sCommonGui[eCG_UCACTUATORSWITCH].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucActuatorSwitch);
        sprintf(m_sCommonGui[eCG_UCCOOLINGDOWN].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucCoolingDown);
        sprintf(m_sCommonGui[eCG_UCOSDTESTPATTERN].cParaValue   , "%d", CM2GUI(edcOSDTEST_PATTERN, psEEP->sUserSystemSetting.sCommonSetting.ucOSDTestPattern));
        sprintf(m_sCommonGui[eCG_UCUARTSWITCH].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucUartSwitch);
        sprintf(m_sCommonGui[eCG_UCBACKUPRESTORESAVE].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave);
        sprintf(m_sCommonGui[eCG_UCBACKUPRESTORERESTORE].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore);
        sprintf(m_sCommonGui[eCG_UCLENSDETECTION].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucLensDetection);
        sprintf(m_sCommonGui[eCG_UCLOWLATENCY].cParaValue   , "%d", CM2GUI(edcLOW_LATENCY_MODE, psEEP->sUserSystemSetting.sCommonSetting.ucLowLatency));
        sprintf(m_sCommonGui[eCG_BACKUP_INPUT_SWITCH].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch);
        sprintf(m_sCommonGui[eCG_BACKUP_PRIMARY_INPUT].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput); //G100_Steven_0028
        sprintf(m_sCommonGui[eCG_BACKUP_SECONDARY_INPUT].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput); //G100_Steven_0028
        sprintf(m_sCommonGui[eCG_BACKGROUND_COLOR].cParaValue , "%d", CM2GUI(edcBACKGROUND_COLOR,  psEEP->sUserSystemSetting.sCommonSetting.ucBackgroundColor));
        sprintf(m_sCommonGui[eCG_SIGNAL_POWERON].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucSignalPowerOn);
        sprintf(m_sCommonGui[eCG_SECURITY_TOTALREMAINMIN].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin);
        sprintf(m_sCommonGui[eCG_STARTUP_SHUTTER].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucStartupShutter);
        sprintf(m_sCommonGui[eCG_AUTO_SOURCE_RESYNC].cParaValue , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucAutoSourceResync);   //G100_Doulas_0006
        sprintf(m_sCommonGui[eCG_UCSERIALPORTOUT_BAUDRATE].cParaValue   , "%d", CM2GUI(edcSERIAL_PORT_OUT_BAUD_RATE, psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortOut_BaudRate));
        sprintf(m_sCommonGui[eCG_UCFADEIN_TIME].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucFadeIn_Time);
        sprintf(m_sCommonGui[eCG_UCFADEOUT_TIME].cParaValue   , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucFadeOut_Time);
        sprintf(m_sCommonGui[eCG_UCPWRKEYBACKLIGHT].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucPwrKeyBacklight);
        sprintf(m_sCommonGui[eCG_UCLOGOCHANGE].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucLogoChange);
        sprintf(m_sCommonGui[eCG_UCFAST_POWER_ON].cParaValue  , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucFast_Power_On);	//G100_Clare_0055

        sprintf(m_sCommonGui[eCG_AUTO_HDMI_SWITCH].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucAuto_HDMI_Switch);      //G100_Tim_0057, add, start //A35G2_BRC_Casper_0060
        sprintf(m_sCommonGui[eCG_INPUT_KEY_LAST_VALUE].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucInput_Key_Last_Value); //A35G2_BRC_Casper_0060
        sprintf(m_sCommonGui[eCG_3D_MODE_LAST_VALUE].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.uc3D_Mode_Last_Value);  //G100_Tim_0057, add, end //A35G2_BRC_Casper_0060
        sprintf(m_sCommonGui[eCG_PROJ_NATIVE_TIMING].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucProj_Native_Timing);  //G100_Tim_0058, add //A35G2_BRC_Casper_0060
        sprintf(m_sCommonGui[eCG_UCLENSPEED].cParaValue    , "%d", psEEP->sUserSystemSetting.sCommonSetting.ucLensSpeed);

		sprintf(m_sCommonGui[eCG_UCAUDIO_VOLUME].cParaValue, "%d", psEEP->sUserSystemSetting.sCommonSetting.ucAudioVolume);// R70K_Bruce_0002
        sprintf(m_sCommonGui[eCG_UCAUDIO_MUTE].cParaValue, "%d", psEEP->sUserSystemSetting.sCommonSetting.ucAudioMute);// R70K_Bruce_0002

        sprintf(m_sCommonGui[eCG_UCINPUTSOURCEMAIN].cParaValue  , "%d", CM2GUI(edcMAIN_INPUT, psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceMain));
        sprintf(m_sCommonGui[eCG_UCINPUTSOURCESUB].cParaValue   , "%d", CM2GUI(edcSUB_INPUT,  psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceSub));
        sprintf(m_sCommonGui[eCG_UCPIPENABLE].cParaValue    , "%d", CM2GUI(edcPIP_PBP_ENABLE, psEEP->sUserSystemSetting.sSourceSetting.ucPIPEnable));
        sprintf(m_sCommonGui[eCG_UCMAINLAYOUT].cParaValue    , "%d", CM2GUI(edcMAIN_LAYOUT, psEEP->sUserSystemSetting.sSourceSetting.ucMainLayout));
        sprintf(m_sCommonGui[eCG_UCPIPLAYOUT].cParaValue    , "%d", CM2GUI(edcMAIN_LAYOUT, psEEP->sUserSystemSetting.sSourceSetting.ucPIPLayout));
        sprintf(m_sCommonGui[eCG_UCPBPLAYOUT].cParaValue    , "%d", CM2GUI(edcMAIN_LAYOUT, psEEP->sUserSystemSetting.sSourceSetting.ucPBPLayout));
        sprintf(m_sCommonGui[eCG_UCPIPSIZE].cParaValue  , "%d", CM2GUI(edcSIZE, psEEP->sUserSystemSetting.sSourceSetting.ucPIPSize));
        sprintf(m_sCommonGui[eCG_UCSOURCEKEYOPTION].cParaValue  , "%d", psEEP->sUserSystemSetting.sSourceSetting.ucSourceKeyOption);
        sprintf(m_sCommonGui[eCG_UISOURCEINFO].cParaValue   , "%d", psEEP->sUserSystemSetting.sSourceSetting.uiSourceInfo);

        sprintf(m_sCommonGui[eCG_UCSOURCELOCK].cParaValue,  "%d", psEEP->sUserSystemSetting.sSourceSetting.ucSourceLock);
        sprintf(m_sCommonGui[eCG_UCCUSTOMKEY].cParaValue,   "%d", CM2GUI(edcHOT_KEY_SETTINGS, psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey));
        sprintf(m_sCommonGui[eCG_UCCUSTOMKEY2].cParaValue,  "%d", CM2GUI(edcHOT_KEY2_SETTINGS, psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey2));  //G100_Wilsonj_0053
        sprintf(m_sCommonGui[eCG_UCBLANKKEY].cParaValue,    "%d", psEEP->sUserSystemSetting.sSourceSetting.ucBlankKey);
        sprintf(m_sCommonGui[eCG_UCSOURCEHOTKEYENABLE].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable);

		sprintf(m_sCommonGui[eCG_ACU_DATA_ENABLE].cParaValue, "%d", psEEP->sSystemDefault.ucACU_Data_Enable);//A35G2_Alan_0007

        sprintf(m_sCommonGui[eCG_UCSHOWNETWORKMESSAGES].cParaValue ,"%d",  psEEP->sUserSystemSetting.sNetworkSetting.ucShowNetworkMessages); //A70LK_Jacky_0011
        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}
#endif

void utilDataMgr_RAMToFileWarping(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_WARPING == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_WARPING == eNode))
    {
        sprintf(m_sWarping[eWI_UCWARPMODE].cParaValue,          "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpMode);
        sprintf(m_sWarping[eWI_UCWARPHORZKEYSTONE].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone);
        sprintf(m_sWarping[eWI_UCWARPVERTKEYSTONE].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone);
        sprintf(m_sWarping[eWI_UCWARPHORZPINCUSHION].cParaValue,"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion);
        sprintf(m_sWarping[eWI_UCWARPVERTPINCUSHION].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion);
        sprintf(m_sWarping[eWI_UCWARPPINCUSHIONBARREL].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel);
        sprintf(m_sWarping[eWI_UCGEOMETRYPCMODE].cParaValue,        "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucGeometryPCMode);
        sprintf(m_sWarping[eWI_UI4CORNERTOPLEFTHORZ].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz);
        sprintf(m_sWarping[eWI_UI4CORNERTOPLEFTVERT].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert);
        sprintf(m_sWarping[eWI_UI4CORNERTOPRIGHTHORZ].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz);
        sprintf(m_sWarping[eWI_UI4CORNERTOPRIGHTVERT].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert);
        sprintf(m_sWarping[eWI_UI4CORNERBOTTOMLEFTHORZ].cParaValue, "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz);
        sprintf(m_sWarping[eWI_UI4CORNERBOTTOMLEFTVERT].cParaValue, "%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert);
        sprintf(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTHORZ].cParaValue,"%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz);
        sprintf(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTVERT].cParaValue,"%d",  psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert);
        sprintf(m_sWarping[eWI_UCWARPAUTOFILTER].cParaValue,        "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter);
        sprintf(m_sWarping[eWI_UCWARPFILTERH].cParaValue,           "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterH);
        sprintf(m_sWarping[eWI_UCWARPFILTERV].cParaValue,           "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterV);
        sprintf(m_sWarping[eWI_UCMOVEPITCHMODE].cParaValue,         "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucMovePitchMode);
        sprintf(m_sWarping[eWI_UCBLENDINGTOPENABLE].cParaValue,     "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable);
        sprintf(m_sWarping[eWI_UIBLENDINGTOPSTARTPIXEL].cParaValue,     "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel);
        sprintf(m_sWarping[eWI_UIBLENDINGTOPPIXELWIDTH].cParaValue,     "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth);
        sprintf(m_sWarping[eWI_UCBLENDINGBOTTOMENABLE].cParaValue,      "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable);
        sprintf(m_sWarping[eWI_UIBLENDINGBOTTOMSTARTPIXEL].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel);
        sprintf(m_sWarping[eWI_UIBLENDINGBOTTOMPIXELWIDTH].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth);
        sprintf(m_sWarping[eWI_UCBLENDINGLEFTENABLE].cParaValue,        "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable);
        sprintf(m_sWarping[eWI_UIBLENDINGLEFTSTARTPIXEL].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel);
        sprintf(m_sWarping[eWI_UIBLENDINGLEFTPIXELWIDTH].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth);
        sprintf(m_sWarping[eWI_UCBLENDINGRIGHTENABLE].cParaValue,       "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable);
        sprintf(m_sWarping[eWI_UIBLENDINGRIGHTSTARTPIXEL].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel);
        sprintf(m_sWarping[eWI_UIBLENDINGRIGHTPIXELWIDTH].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth);
        sprintf(m_sWarping[eWI_UCAUTOADJUSTMENTMODE].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode);
        sprintf(m_sWarping[eWI_UCWARPINGAPPLYSETTING].cParaValue,   "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting);
        sprintf(m_sWarping[eWI_UCWARPINGSAVESETTING].cParaValue,    "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting);
        sprintf(m_sWarping[eWI_UCWARPINGLASTSAVED].cParaValue,      "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucWarpingLastSaved);  //A35G2_CDS_Simon_0008
        sprintf(m_sWarping[eWI_UCBLENDINGGAMMA].cParaValue,         "%d",  CM2GUI(edcBLENDING_GAMMA, psEEP->sUserSystemSetting.sWarpSetting.ucBlendingGamma));
        sprintf(m_sWarping[eWI_UCGEOMETRYENABLE].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucGeometryEnable);

        sprintf(m_sWarping[eWI_UCWARPINGAPPLY_0].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply);
        sprintf(m_sWarping[eWI_UCBLENDAPPLY_0].cParaValue,   "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply);
        sprintf(m_sWarping[eWI_UCWARPINGNAME_0].cParaValue,  "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingName);
        sprintf(m_sWarping[eWI_UCBLENDINGNAME_0].cParaValue, "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendingName);

        sprintf(m_sWarping[eWI_UCWARPINGAPPLY_1].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingApply);
        sprintf(m_sWarping[eWI_UCBLENDAPPLY_1].cParaValue,   "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendApply);
        sprintf(m_sWarping[eWI_UCWARPINGNAME_1].cParaValue,  "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingName);
        sprintf(m_sWarping[eWI_UCBLENDINGNAME_1].cParaValue, "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendingName);

        sprintf(m_sWarping[eWI_UCWARPINGAPPLY_2].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingApply);
        sprintf(m_sWarping[eWI_UCBLENDAPPLY_2].cParaValue ,  "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendApply);
        sprintf(m_sWarping[eWI_UCWARPINGNAME_2].cParaValue,  "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingName);
        sprintf(m_sWarping[eWI_UCBLENDINGNAME_2].cParaValue, "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendingName);

        sprintf(m_sWarping[eWI_UCWARPINGAPPLY_3].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingApply);
        sprintf(m_sWarping[eWI_UCBLENDAPPLY_3].cParaValue,   "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendApply);
        sprintf(m_sWarping[eWI_UCWARPINGNAME_3].cParaValue,  "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingName);
        sprintf(m_sWarping[eWI_UCBLENDINGNAME_3].cParaValue, "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendingName);

        sprintf(m_sWarping[eWI_UCWARPINGAPPLY_4].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucWarpingApply);
        sprintf(m_sWarping[eWI_UCBLENDAPPLY_4].cParaValue,   "%d", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucBlendApply);
        sprintf(m_sWarping[eWI_UCWARPINGNAME_4].cParaValue,  "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucWarpingName);
        sprintf(m_sWarping[eWI_UCBLENDINGNAME_4].cParaValue, "%s", psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[4].ucBlendingName);

        sprintf(m_sWarping[eWI_UCBLENDAPPLYSETTING].cParaValue, "%d", psEEP->sUserSystemSetting.sWarpSetting.ucBlendApplySetting);
        sprintf(m_sWarping[eWI_UCBLENDSAVESETTING].cParaValue,  "%d", psEEP->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting);
        sprintf(m_sWarping[eWI_UCBLENDLASTSAVED].cParaValue,    "%d", psEEP->sUserSystemSetting.sWarpSetting.ucBlendLastSaved);  //A35G2_CDS_Simon_0008

		sprintf(m_sWarping[eWI_UCADV_WARP_CONTROL].cParaValue,  			"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl);	//G100_Doulas_0027
		sprintf(m_sWarping[eWI_UCADV_WARP_GRIDPOINTS].cParaValue,  			"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints);
		sprintf(m_sWarping[eWI_UCADV_WARP_INNER].cParaValue,  				"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner);
		sprintf(m_sWarping[eWI_UCADV_WARP_SHARPNESS].cParaValue,  			"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness);
		sprintf(m_sWarping[eWI_UCADV_WARP_GRIDCOLOR].cParaValue,  			"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor);
		sprintf(m_sWarping[eWI_UCADV_WARP_GRIDBACKGROUND].cParaValue,  		"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor);
		sprintf(m_sWarping[eWI_UCADV_BLEND_OVERLAP_GRIDNUMBER].cParaValue,  "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber);
		sprintf(m_sWarping[eWI_UCADV_BLEND_GAMMA].cParaValue,  				"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma);
		sprintf(m_sWarping[eWI_UIADV_BLEND_LEFT].cParaValue,  				"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft);
		sprintf(m_sWarping[eWI_UIADV_BLEND_RIGHT].cParaValue,  				"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight);
		sprintf(m_sWarping[eWI_UIADV_BLEND_TOP].cParaValue,  				"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop);
		sprintf(m_sWarping[eWI_UIADV_BLEND_BOTTOM].cParaValue,  			"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom);
		sprintf(m_sWarping[eWI_UCADV_WARP_INNER_LAST_VALUE].cParaValue,     "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner_LastValue);    //G100_Tim_0055, add //A35G2_BRC_Casper_0051

		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_AREA].cParaValue,  		"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelArea);						//A65_OPTOMA_Doulas_0020
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_ENABLE_TOP].cParaValue,  	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__TOP]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_ENABLE_BOTTOM].cParaValue, "%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__BOTTOM]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_RED_TOP].cParaValue,  		"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__TOP]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_RED_BOTTOM].cParaValue, 	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__BOTTOM]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_GREEN_TOP].cParaValue,  	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__TOP]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_GREEN_BOTTOM].cParaValue, 	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__BOTTOM]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_BLUE_TOP].cParaValue,  	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__TOP]);
		sprintf(m_sWarping[eWI_UCADV_BLACK_LEVEL_BLUE_BOTTOM].cParaValue, 	"%d",  psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__BOTTOM]);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileActuator(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_ACTUATOR == eNode);

    if((utilDataMgr_MutexTake(__FUNCTION__) == TRUE) && (eDATA_NODE_ACTUATOR == eNode))
    {

        sprintf(m_sActuator[eACT_DAC_AWC0].cParaValue,          "%d",   psEEP->sActuatorSetting.ucDAC_AWC0);
        sprintf(m_sActuator[eACT_SFDELAY_AWC0].cParaValue,      "%d",   psEEP->sActuatorSetting.ulSubframeDelay_AWC0);
        sprintf(m_sActuator[eACT_SEGMENTLEN_AWC0].cParaValue,   "%d",   psEEP->sActuatorSetting.uiSegmentLength_AWC0);
        sprintf(m_sActuator[eACT_DAC_AWC1].cParaValue,          "%d",   psEEP->sActuatorSetting.ucDAC_AWC1);
        sprintf(m_sActuator[eACT_SFDELAY_AWC1].cParaValue,      "%d",   psEEP->sActuatorSetting.ulSubframeDelay_AWC1);
        sprintf(m_sActuator[eACT_SEGMENTLEN_AWC1].cParaValue,   "%d",   psEEP->sActuatorSetting.uiSegmentLength_AWC1);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileSourceTableCommon(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    UINT16 uiSourceNode = 0;

    for(UINT16 iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
    {
        UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);
        sPARA_FORMAT *psPara = NULL;

        uiSourceNode = utilDataMgr_SourceCommonTablerGet(iCount);
        psPara = utilDataMgr_ParaTableGet(uiSourceNode);

        if((uiSourceNode != eDATA_NODE_NUMBER && eNode == eDATA_NODE_NUMBER && psPara != NULL) ||
           (uiSourceNode == eNode))
        {
            if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
            {
                sprintf(psPara[eSCM_CSOURCENAME].cParaValue, "%s\0", psEEP->sUserSystemSetting.sSourceSetting.cSourceName[uiSrcIndex]);
                //sprintf(psPara[eSCM_UCASPECTRATIO].cParaValue,  "%d", CM2GUI(edcSIZE_PRESETS, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio));
                sprintf(psPara[eSCM_UCASPECTRATIO219].cParaValue,  "%d", CM2GUI(edcSIZE_PRESETS, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio));
                sprintf(psPara[eSCM_UCOVERSCAN].cParaValue,     "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucOverScan);
                sprintf(psPara[eSCM_UCPHASE].cParaValue,        "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPhase);
                sprintf(psPara[eSCM_UCTRACKING].cParaValue,     "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucTracking);
                sprintf(psPara[eSCM_UCHORZPOSITION].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucHorzPosition);
                sprintf(psPara[eSCM_UCVERTPOSITION].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucVertPosition);
                sprintf(psPara[eSCM_UIDIGITALHORZZOOM].cParaValue,  "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzZoom);
                sprintf(psPara[eSCM_UIDIGITALVERTZOOM].cParaValue,  "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertZoom);
                sprintf(psPara[eSCM_UIDIGITALHORZSHIFT].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzShift);
                sprintf(psPara[eSCM_UIDIGITALVERTSHIFT].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertShift);
                sprintf(psPara[eSCM_UICUSTOMDIGITALHORZZOOM].cParaValue,    "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzZoom);
                sprintf(psPara[eSCM_UICUSTOMDIGITALVERTZOOM].cParaValue,    "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertZoom);
                sprintf(psPara[eSCM_UICUSTOMDIGITALHORZSHIFT].cParaValue,   "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzShift);
                sprintf(psPara[eSCM_UICUSTOMDIGITALVERTSHIFT].cParaValue,   "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertShift);
                sprintf(psPara[eSCM_UCPRESETMODE].cParaValue,   "%d", CM2GUI(edcPICTURE_SETTINGS, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPresetMode));
                sprintf(psPara[eSCM_UCBACKUPPRESET].cParaValue, "%d",  psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucBackupPreset);
                sprintf(psPara[eSCM_UCSAVEPRESET].cParaValue,   "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucSavePreset);
                sprintf(psPara[eSCM_UCPREUSERMODE].cParaValue,  "%d", CM2GUI(edcPICTURE_SETTINGS, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode));
                sprintf(psPara[eSCM_UC3D_ENABLE].cParaValue,    "%d", CM2GUI(edc3D_ENABLE, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Enable));
                sprintf(psPara[eSCM_UC3D_INVERT].cParaValue,    "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Invert);
                sprintf(psPara[eSCM_UC3D_SYNCOUT].cParaValue,   "%d", CM2GUI(edc3D_SYNC_OUT, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncOut));
                sprintf(psPara[eSCM_UC3D_SYNCIN].cParaValue,    "%d", CM2GUI(edc3D_SYNC_TYPE, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncIn));
                sprintf(psPara[eSCM_UC3D_REFERENCE].cParaValue, "%d", CM2GUI(edc3D_LR_REFERENCE, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Reference));
                sprintf(psPara[eSCM_UC3D_2D_VIEW].cParaValue,   "%d", CM2GUI(edc3D_2D, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_2D_View));
                sprintf(psPara[eSCM_UCEDGEMASK].cParaValue,     "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucEdgeMask);
				sprintf(psPara[eSCM_UC3D_MODE].cParaValue,      "%d", CM2GUI(edc3D_MODE, psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Mode));  //A70Gen2_Doulas_0054
                sprintf(psPara[eSCM_UC3D_TECH].cParaValue,      "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Tech);
                sprintf(psPara[eSCM_UCAUTOIMAGE].cParaValue,    "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAutoImage);
                sprintf(psPara[eSCM_UCDIGITALZOOMPROP].cParaValue, "%d", psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucDigitalZoomProp);

                utilDataMgr_Update(uiSourceNode);
                utilDataMgr_MutexGive(__FUNCTION__);
            }
        }
    }
}

void utilDataMgr_RAMToFileSourceTableColor(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{

    UINT16 uiSourceNode = 0;

    for(UINT16 iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
    {
        UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

        for(UINT16 iCount2 = 0; iCount2 < eGUI_PICTURE_SETTINGS_NUMBER; iCount2++)
        {
            UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcPICTURE_SETTINGS, iCount2);
            sPARA_FORMAT *psPara = NULL;

            uiSourceNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_COLOR, iCount, iCount2);
            psPara = utilDataMgr_ParaTableGet(uiSourceNode);

            if((uiSourceNode != eDATA_NODE_NUMBER && eNode == eDATA_NODE_NUMBER && psPara != NULL) ||
               (uiSourceNode == eNode))
            {
                if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
                {
                    sprintf(psPara[eSCR_UCCS].cParaValue, 					"%d", CM2GUI(edcCOLOR_SPACE, psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS));
                    sprintf(psPara[eSCR_UCCT].cParaValue, 					"%d", CM2GUI(edcCOLOR_TEMPERATURE, psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT));
                    sprintf(psPara[eSCR_UCGAMMA].cParaValue, 				"%d", CM2GUI(edcGAMMA, psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma));
                    sprintf(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue, "%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled );
                    sprintf(psPara[eSCR_UCWHITEPEAKING].cParaValue, 		"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking);
                    sprintf(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue, 	"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement);
                    sprintf(psPara[eSCR_UCSKINCOLOR].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor);
                    sprintf(psPara[eSCR_UCSHARPNESS].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness);
                    sprintf(psPara[eSCR_UCBRIGHTNESS].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness);
                    sprintf(psPara[eSCR_UCCONTRAST].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast);
                    sprintf(psPara[eSCR_UCTINT].cParaValue, 				"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint);
                    sprintf(psPara[eSCR_UCSATURATION].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation);
                    sprintf(psPara[eSCR_UCREDGAIN].cParaValue, 				"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain);
                    sprintf(psPara[eSCR_UCGREENGAIN].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain);
                    sprintf(psPara[eSCR_UCBLUEGAIN].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain);
                    sprintf(psPara[eSCR_UCREDOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset);
                    sprintf(psPara[eSCR_UCGREENOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset);
                    sprintf(psPara[eSCR_UCBLUEOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset);
                    sprintf(psPara[eSCR_UCWALLCOLORSET].cParaValue, 		"%d", CM2GUI(edcWALL_COLOR, psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet));  //G100_Steven_0047

                    utilDataMgr_Update(uiSourceNode);
                    utilDataMgr_MutexGive(__FUNCTION__);
                }
            }
        }
    }
}

void utilDataMgr_RAMToFileSourceTableHSG(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{

    UINT16 uiSourceNode = 0;

    for(UINT16 iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
    {
        UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

        for(UINT16 iCount2 = 0; iCount2 < eGUI_PICTURE_SETTINGS_NUMBER; iCount2++)
        {
            UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcPICTURE_SETTINGS, iCount2);
            sPARA_FORMAT *psPara = NULL;

            uiSourceNode = utilDataMgr_SourceColorTableGet(eSOURCE_TYPE_HSG, iCount, iCount2);
            psPara = utilDataMgr_ParaTableGet(uiSourceNode);

            if((uiSourceNode != eDATA_NODE_NUMBER && eNode == eDATA_NODE_NUMBER && psPara != NULL) ||
               (uiSourceNode == eNode))
            {
                if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
                {
                    sprintf(psPara[eHSG_R_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE);
                    sprintf(psPara[eHSG_R_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT);
                    sprintf(psPara[eHSG_R_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN);
                    sprintf(psPara[eHSG_G_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE);
                    sprintf(psPara[eHSG_G_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT);
                    sprintf(psPara[eHSG_G_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN);
                    sprintf(psPara[eHSG_B_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE);
                    sprintf(psPara[eHSG_B_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT);
                    sprintf(psPara[eHSG_B_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN);
                    sprintf(psPara[eHSG_C_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE);
                    sprintf(psPara[eHSG_C_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT);
                    sprintf(psPara[eHSG_C_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN);
                    sprintf(psPara[eHSG_M_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE);
                    sprintf(psPara[eHSG_M_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT);
                    sprintf(psPara[eHSG_M_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN);
                    sprintf(psPara[eHSG_Y_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE);
                    sprintf(psPara[eHSG_Y_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT);
                    sprintf(psPara[eHSG_Y_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN);
                    sprintf(psPara[eHSG_W_R_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN);
                    sprintf(psPara[eHSG_W_G_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN);
                    sprintf(psPara[eHSG_W_B_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN);

                    utilDataMgr_Update(uiSourceNode);
                    utilDataMgr_MutexGive(__FUNCTION__);
                }
            }
        }
    }
}
 //G100_Steven_0020 start
void utilDataMgr_RAMToFileSourceTableHSGUser(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{

    UINT16 uiSourceNode = 0;

    for(UINT16 iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
    {
        UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

        for(UINT16 iCount2 = 0; iCount2 < eGUI_PRE_USERS_NUMBER; iCount2++)		//G100_Doulas_0066 Modify
        {
            UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcUSER_COLOR_MODE, iCount2);	//G100_Doulas_0066 Modify
            sPARA_FORMAT *psPara = NULL;

            uiSourceNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_HSG, iCount, iCount2);
            psPara = utilDataMgr_ParaTableGet(uiSourceNode);

            if((uiSourceNode != eDATA_NODE_NUMBER && eNode == eDATA_NODE_NUMBER && psPara != NULL)  ||
               (uiSourceNode == eNode))
            {
                if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
                {
                    sprintf(psPara[eHSG_R_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE);
                    sprintf(psPara[eHSG_R_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT);
                    sprintf(psPara[eHSG_R_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN);
                    sprintf(psPara[eHSG_G_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE);
                    sprintf(psPara[eHSG_G_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT);
                    sprintf(psPara[eHSG_G_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN);
                    sprintf(psPara[eHSG_B_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE);
                    sprintf(psPara[eHSG_B_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT);
                    sprintf(psPara[eHSG_B_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN);
                    sprintf(psPara[eHSG_C_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE);
                    sprintf(psPara[eHSG_C_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT);
                    sprintf(psPara[eHSG_C_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN);
                    sprintf(psPara[eHSG_M_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE);
                    sprintf(psPara[eHSG_M_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT);
                    sprintf(psPara[eHSG_M_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN);
                    sprintf(psPara[eHSG_Y_HUE].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE);
                    sprintf(psPara[eHSG_Y_SAT].cParaValue,    "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT);
                    sprintf(psPara[eHSG_Y_GAIN].cParaValue,   "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN);
                    sprintf(psPara[eHSG_W_R_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN);
                    sprintf(psPara[eHSG_W_G_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN);
                    sprintf(psPara[eHSG_W_B_GAIN].cParaValue, "%d",psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN);

                    utilDataMgr_Update(uiSourceNode);
                    utilDataMgr_MutexGive(__FUNCTION__);
                }
            }
        }
    }
}
 //G100_Steven_0020 end
void utilDataMgr_RAMToFileSourceTableColorUser(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    UINT16 uiSourceNode = 0;

    for(UINT16 iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
    {
        UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

        for(UINT16 iCount2 = 0; iCount2 < eGUI_PRE_USERS_NUMBER; iCount2++)		//G100_Doulas_0066 Modify
        {
            UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcUSER_COLOR_MODE, iCount2);	//G100_Doulas_0066 Modify
            sPARA_FORMAT *psPara = NULL;

            uiSourceNode = utilDataMgr_SourceColorTableUserGet(eSOURCE_TYPE_COLOR, iCount, iCount2);
            psPara = utilDataMgr_ParaTableGet(uiSourceNode);

            if((uiSourceNode != eDATA_NODE_NUMBER && eNode == eDATA_NODE_NUMBER && psPara != NULL)||
               (uiSourceNode == eNode))
            {
                if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
                {
                    sprintf(psPara[eSCR_UCCS].cParaValue, 					"%d", CM2GUI(edcCOLOR_SPACE, psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS));
                    sprintf(psPara[eSCR_UCCT].cParaValue, 					"%d", CM2GUI(edcCOLOR_TEMPERATURE, psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT));
                    sprintf(psPara[eSCR_UCGAMMA].cParaValue, 				"%d", CM2GUI(edcGAMMA, psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma));
                    sprintf(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue, "%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled );
                    sprintf(psPara[eSCR_UCWHITEPEAKING].cParaValue, 		"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking);
                    sprintf(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue, 	"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement);
                    sprintf(psPara[eSCR_UCSKINCOLOR].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor);
                    sprintf(psPara[eSCR_UCSHARPNESS].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness);
                    sprintf(psPara[eSCR_UCBRIGHTNESS].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness);
                    sprintf(psPara[eSCR_UCCONTRAST].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast);
                    sprintf(psPara[eSCR_UCTINT].cParaValue, 				"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint);
                    sprintf(psPara[eSCR_UCSATURATION].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation);
                    sprintf(psPara[eSCR_UCREDGAIN].cParaValue, 				"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain);
                    sprintf(psPara[eSCR_UCGREENGAIN].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain);
                    sprintf(psPara[eSCR_UCBLUEGAIN].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain);
                    sprintf(psPara[eSCR_UCREDOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset);
                    sprintf(psPara[eSCR_UCGREENOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset);
                    sprintf(psPara[eSCR_UCBLUEOFFSET].cParaValue, 			"%d", psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset);
                    sprintf(psPara[eSCR_UCWALLCOLORSET].cParaValue, 	    "%d", CM2GUI(edcWALL_COLOR, psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet));  //G100_Steven_0047

                    utilDataMgr_Update(uiSourceNode);
                    utilDataMgr_MutexGive(__FUNCTION__);
                }
            }
        }
    }
}

void utilDataMgr_RAMToFileWAPFlag(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    ASSERT(eDATA_NODE_WAP_CALIBRATION_TAG == eNode);

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        //Wap tag
        sprintf(m_sWAP_Calibration_Tag[eWAP_CALIBRATION_TAG].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ulCCT_Tag);
        sprintf(m_sWAP_Calibration_Tag[eWAP_CRC].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiCCT_CRC);

        utilDataMgr_Update(eNode);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileWAP(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
    UINT16 uiPara = 0;
    UINT16 uiMode = 0;
    UINT16 iCount = 0;
    sPARA_FORMAT *psPara;

    for(uiPara = 0; uiPara < eWAP_PARA_NUMBERS; uiPara++)
    {
        for(uiMode = 0; uiMode < eIFC_WAP_NUMBER; uiMode++)
        {
            if(eNode == utilDataMgr_WapTableGet(uiPara, uiMode))
            {
                break;
            }
        }
    }

    if((uiMode >= eIFC_WAP_NUMBER) || (uiPara >= eWAP_PARA_NUMBERS))
    {
        return;
    }

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        psPara = utilDataMgr_ParaTableGet(eNode);

        if(uiPara == eWAP_PARA_RATIO)
        {
            sprintf(psPara[eWAP_LD_SEG_BLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_BLD_R+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_G].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_BLD_G+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_B].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_BLD_B+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_BLD_Y+1]);
            sprintf(psPara[eWAP_LD_SEG_RLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_RLD_R+1]);
            sprintf(psPara[eWAP_LD_SEG_RLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucRatioData[uiMode][eWAP_LD_SEG_RLD_Y+1]);
        }
        else if(uiPara == eWAP_PARA_OFFSET)
        {
            sprintf(psPara[eWAP_LD_SEG_BLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_BLD_R+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_G].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_BLD_G+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_B].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_BLD_B+1]);
            sprintf(psPara[eWAP_LD_SEG_BLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_BLD_Y+1]);
            sprintf(psPara[eWAP_LD_SEG_RLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_RLD_R+1]);
            sprintf(psPara[eWAP_LD_SEG_RLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.ucOffsetData[uiMode][eWAP_LD_SEG_RLD_Y+1]);
        }
        else if(uiPara == eWAP_PARA_PWM)
        {
            sprintf(psPara[eWAP_LD_SEG_BLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_BLD_R]);
            sprintf(psPara[eWAP_LD_SEG_BLD_G].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_BLD_G]);
            sprintf(psPara[eWAP_LD_SEG_BLD_B].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_BLD_B]);
            sprintf(psPara[eWAP_LD_SEG_BLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_BLD_Y]);
            sprintf(psPara[eWAP_LD_SEG_RLD_R].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_RLD_R]);
            sprintf(psPara[eWAP_LD_SEG_RLD_Y].cParaValue, "%d", psEEP->uCCT_Table.sDataStruct.uiPWMData[uiMode][eWAP_LD_SEG_RLD_Y]);
        }

        utilDataMgr_Update(eNode);
        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileWAPAll(sEEPROM_SETTINGS *psEEP)
{
    UINT16 uiPara = 0;
    UINT16 uiMode = 0;
    UINT16 uiNode = 0;

    utilDataMgr_RAMToFileWAPFlag(psEEP, eDATA_NODE_WAP_CALIBRATION_TAG);

    for(uiPara = 0; uiPara < eWAP_PARA_NUMBERS; uiPara++)
    {
        for(uiMode = 0; uiMode < eIFC_WAP_NUMBER; uiMode++)
        {
            uiNode = utilDataMgr_WapTableGet(uiPara, uiMode);

            if(uiNode != eDATA_NODE_NUMBER)
            {
                utilDataMgr_RAMToFileWAP(psEEP, uiNode);
            }
        }
    }
}

void utilDataMgr_RAMToFileACUCal(sEEPROM_SETTINGS *psEEP)//A35G2_Alan_0024
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
		#if (ENABLE_COLOR_UNIFORMITY == TRUE)
    	sprintf(m_sACU_DATA[eACU_FILE_VALID].cParaValue, "%d", psEEP->sSystemDefault.ucACU_File_Valid);
    	sprintf(m_sACU_DATA[eACU_DISPLAY_MODE].cParaValue, "%d", psEEP->sSystemDefault.ucACU_Display_Mode);
      	sprintf(m_sACU_DATA[eACU_TARGET_SELECT].cParaValue, "%d", psEEP->sSystemDefault.ucACU_Target_Select);
		#endif
		sprintf(m_sACU_DATA[eACU_DATA_ENABLE].cParaValue, "%d", psEEP->sSystemDefault.ucACU_Data_Enable);

		utilDataMgr_Update(eDATA_NODE_ACU);

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_RAMToFileAll(sEEPROM_SETTINGS *psEEP)
{
#if 0
    utilDataMgr_RAMToFileSystemCal(psEEP, eDATA_NODE_SYSTEMCAL);
    utilDataMgr_RAMToFileBurnin(psEEP, eDATA_NODE_BURNIN);
    utilDataMgr_RAMToFileProjectorInfo(psEEP, eDATA_NODE_PROJECTORINFO);
    utilDataMgr_RAMToFileAutoBrightness(psEEP, eDATA_NODE_AUTOBRIGHTNESS);
    utilDataMgr_RAMToFileStartup(psEEP, eDATA_NODE_STARTUP);
    utilDataMgr_RAMToFileSystemHours(psEEP, eDATA_NODE_SYSTEMHOURS);
	utilDataMgr_RAMToFileACUCal(psEEP);//A35G2_Alan_0024
    utilDataMgr_RAMToFileCommonGui(psEEP, eDATA_NODE_COMMONGUI);
    utilDataMgr_RAMToFileWarping(psEEP, eDATA_NODE_WARPING);
    //utilDataMgr_RAMToFileActuator(psEEP, eDATA_NODE_ACTUATOR);
    utilDataMgr_RAMToFileSourceTableCommon(psEEP, eDATA_NODE_NUMBER);
    utilDataMgr_RAMToFileSourceTableColor(psEEP, eDATA_NODE_NUMBER);
    utilDataMgr_RAMToFileSourceTableHSG(psEEP, eDATA_NODE_NUMBER);
    utilDataMgr_RAMToFileSourceTableColorUser(psEEP, eDATA_NODE_NUMBER);
    utilDataMgr_RAMToFileSourceTableHSGUser(psEEP, eDATA_NODE_NUMBER);  //G100_Steven_0020
    utilDataMgr_RAMToFileWAPAll(psEEP);
#endif
}

void utilDataMgr_LanInit(sLAN_INFO_VALUES *psLanInfo)
{
    FILE *pFile = NULL;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;
    UINT8  cString[DATA_MGR_VALUE_LEN] = {0};

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
    UINT8  ucFileCount = 0;

    char *pcNull="";    //ProAV_Doulas_0001

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        for(ucFileCount = 0; ucFileCount < MAX_LAN_FILE_NODE; ucFileCount++)
        {
            pFile = fopen(m_cLANFileName[ucFileCount], "r");

            if(pFile == NULL) //initial
            {
                continue;
            }

            fseek(pFile, 0, SEEK_END);
            ulSize = ftell(pFile);
            fclose(pFile);

            pcBuffer = (char*)malloc(ulSize+1);

            FileLine = (uint32)readConf(m_cLANFileName[ucFileCount], conf_argv, 1024, pcBuffer, ulSize);

            for(ulCount = 0; ulCount < eLII_NUMBER; ulCount++)
            {
                pcGetValue = findArgValue(m_sLan_Default[ulCount].cParaName, conf_argv, FileLine);

    		    if(strcmp(pcGetValue, pcNull) != 0)		//ProAV_Doulas_0001 Modify
                {
                    memset(m_sLan_Default[ulCount].cParaValue, '\0', DATA_MGR_VALUE_LEN);
                    strcpy(m_sLan_Default[ulCount].cParaValue, pcGetValue);
                }
            }

            free(pcBuffer);
        }

#if 0
        for(ulCount = 0; ulCount < eLII_NUMBER; ulCount++)
        {
            LOG_MSG(db_ALWAYS,"%s %s\n", m_sLan_Default[ulCount].cParaName, m_sLan_Default[ulCount].cParaValue);
        }
#endif /* 0 */

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_IPADDR].cParaValue, strlen((char *)m_sLan_Default[eLII_IPADDR].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucLAN_IP[0], &psLanInfo->ucLAN_IP[1], &psLanInfo->ucLAN_IP[2], &psLanInfo->ucLAN_IP[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_SUBMASK].cParaValue, strlen((char *)m_sLan_Default[eLII_SUBMASK].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucLAN_MASK[0], &psLanInfo->ucLAN_MASK[1], &psLanInfo->ucLAN_MASK[2], &psLanInfo->ucLAN_MASK[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_GATEWAY].cParaValue, strlen((char *)m_sLan_Default[eLII_GATEWAY].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucLAN_GATEWAY[0], &psLanInfo->ucLAN_GATEWAY[1], &psLanInfo->ucLAN_GATEWAY[2], &psLanInfo->ucLAN_GATEWAY[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_PRIMARYDNS].cParaValue, strlen((char *)m_sLan_Default[eLII_PRIMARYDNS].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucLAN_Primary_DNS[0], &psLanInfo->ucLAN_Primary_DNS[1], &psLanInfo->ucLAN_Primary_DNS[2], &psLanInfo->ucLAN_Primary_DNS[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_SECONDDNS].cParaValue, strlen((char *)m_sLan_Default[eLII_SECONDDNS].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucLAN_Secondary_DNS[0], &psLanInfo->ucLAN_Secondary_DNS[1], &psLanInfo->ucLAN_Secondary_DNS[2], &psLanInfo->ucLAN_Secondary_DNS[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_STARTIPADDR].cParaValue, strlen((char *)m_sLan_Default[eLII_STARTIPADDR].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucWLAN_Start_IP[0], &psLanInfo->ucWLAN_Start_IP[1], &psLanInfo->ucWLAN_Start_IP[2], &psLanInfo->ucWLAN_Start_IP[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_ENDIPADDR].cParaValue, strlen((char *)m_sLan_Default[eLII_ENDIPADDR].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucWLAN_End_IP[0], &psLanInfo->ucWLAN_End_IP[1], &psLanInfo->ucWLAN_End_IP[2], &psLanInfo->ucWLAN_End_IP[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_WIFISUBMASK].cParaValue, strlen((char *)m_sLan_Default[eLII_WIFISUBMASK].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucWLAN_MASK[0], &psLanInfo->ucWLAN_MASK[1], &psLanInfo->ucWLAN_MASK[2], &psLanInfo->ucWLAN_MASK[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_WIFIGATEWAY].cParaValue, strlen((char *)m_sLan_Default[eLII_WIFIGATEWAY].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucWLAN_GATEWAY[0], &psLanInfo->ucWLAN_GATEWAY[1], &psLanInfo->ucWLAN_GATEWAY[2], &psLanInfo->ucWLAN_GATEWAY[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_CRESTRONIPADDR].cParaValue, strlen((char *)m_sLan_Default[eLII_CRESTRONIPADDR].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucCrestron_IP[0], &psLanInfo->ucCrestron_IP[1], &psLanInfo->ucCrestron_IP[2], &psLanInfo->ucCrestron_IP[3]);

        //////////////////////////////////////////
        ulCount = 0;
        memset(cString, '\0', DATA_MGR_VALUE_LEN);
        memcpy(cString, m_sLan_Default[eLII_SERVICE].cParaValue, strlen((char *)m_sLan_Default[eLII_SERVICE].cParaValue));

        sscanf((char*)cString, "%d.%d.%d.%d", &psLanInfo->ucPJLink_IP[0], &psLanInfo->ucPJLink_IP[1], &psLanInfo->ucPJLink_IP[2], &psLanInfo->ucPJLink_IP[3]);

        sprintf(psLanInfo->ucLAN_MAC_Address , "%s\0", m_sLan_Default[eLII_MAC].cParaValue);
        sprintf(psLanInfo->ucWLAN_SSID , "%s\0", m_sLan_Default[eLII_WIFISSID].cParaValue);

        psLanInfo->ucCrestronIP_ID   = (UINT16)atol(m_sLan_Default[eLII_CRESTRONIPID].cParaValue);
        psLanInfo->ucCrestronIP_Port = (UINT16)atol(m_sLan_Default[eLII_CRESTRONPORT].cParaValue);

        psLanInfo->ucLAN_DHCP       = (UINT8)atol(m_sLan_Default[eLII_DHCP].cParaValue);
        psLanInfo->ucWLAN_Enable    = (UINT8)atol(m_sLan_Default[eLII_WIFI].cParaValue);
        psLanInfo->ucCrestron_Enable = (UINT8)atol(m_sLan_Default[eLII_CRESTRON].cParaValue);  //G100_Wilsonj_0055
        psLanInfo->ucLAN_Path       = (UINT8)atol(m_sLan_Default[eLII_PORT].cParaValue); //A35G2_CDS_Larry_0028

        if(psLanInfo->ucLAN_Path != 0) //linux device is 1 and 2
        {
            psLanInfo->ucLAN_Path = psLanInfo->ucLAN_Path - 1;
        }

		utilDataMgr_MutexGive(__FUNCTION__);
    }

}

#define MAX_LOG_NUMBER (100)
#define MAX_LOG_LENGHT (128)

void utilOPD_TotalProjectorHour(void) //G100_Julie_0022
{
	UINT8 ucValue[4] = {0};
	UINT32 ulTotalProjectorMinute = (UINT32)atol(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue);

	utilHost_EventWrite(eCMD_MODULE_SYSTEM, eMSG_TYPE_UART_1, eSYSTEM_MSG_SYSTEM_HOURS, eSYSTEM_MSG_SYSTEM_HOURS_SZ, (UINT8 *)&ulTotalProjectorMinute, TRUE);
}

void utilDataMgr_WriteErrorLog(const UINT32 uiErrorIndex, const char *pcString)
{
    char cLog[MAX_LOG_NUMBER + 1][MAX_LOG_LENGHT] = {'\0'};
    FILE *pFile;
    UINT16 uiReadCount = 0;
    UINT16 uiWriteCount = 0;
    char cStrTemp[128] = {'\0'};
    UINT16 uiStrlen = strlen(pcString);
    UINT32 ulTotalProjectorMinute = (UINT32)atol(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue);
    UINT16 wDay = 0, wHour = 0, wMin = 0;
	UINT8 ucValue[4] = {0};

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        pFile = fopen(ERROR_LOG_TXT, "r");

        if(pFile != NULL)
        {
            while(uiReadCount < MAX_LOG_NUMBER)
            {
                if(fgets(cLog[uiReadCount], MAX_LOG_LENGHT, pFile))
                {
                    uiReadCount++;
                }
                else
                {
                    break;
                }
            }
            //rewind(pFile);
			fclose(pFile);
			pFile = fopen(ERROR_LOG_TXT, "w");
        }
        else
        {
            pFile = fopen(ERROR_LOG_TXT, "w");
            uiReadCount++;
        }

        memcpy(cStrTemp, pcString, uiStrlen);

        //確認字串尾是否有\r or \n
        if(cStrTemp[uiStrlen - 1] == '\r' || cStrTemp[uiStrlen - 1] == '\n')
        {
            cStrTemp[uiStrlen - 1] = '\0';
            uiStrlen = strlen(cStrTemp);
        }

        wDay  = ulTotalProjectorMinute / 1440 ;
        wHour = (ulTotalProjectorMinute / 60) % 24;
        wMin  = ulTotalProjectorMinute % 60;

        if(uiReadCount > MAX_LOG_NUMBER)
        {
            uiReadCount = MAX_LOG_NUMBER;
        }

		snprintf((char*)&cLog[uiReadCount], 127, "%04d:%02d:%02d, %s, 0x%08X\n", wDay, wHour, wMin, cStrTemp, uiErrorIndex);

        if(uiReadCount == MAX_LOG_NUMBER)
        {
            uiWriteCount = 1;
        }
        else
        {
            uiWriteCount = 0;
        }

        if(pFile != NULL)  //G100_Simon_0092
        {
            for(uiWriteCount; uiWriteCount <= uiReadCount; uiWriteCount++)
            {
                fprintf(pFile, "%s", cLog[uiWriteCount]);
            }

            fclose(pFile);
        }
        else
        {
            LOG_MSG(db_HAL_EEP, "%s file open fail\n", ERROR_LOG_TXT);
        }

		palLANProcSendLog(uiErrorIndex, ulTotalProjectorMinute);

		utilHost_EventWrite(eCMD_MODULE_SYSTEM, eMSG_TYPE_UART_1, eSYSTEM_MSG_SYSTEM_HOURS, eSYSTEM_MSG_SYSTEM_HOURS_SZ, (UINT8 *)&ulTotalProjectorMinute, FALSE);
		utilHost_EventWrite(eCMD_MODULE_SYSTEM, eMSG_TYPE_UART_1, eSYSTEM_MSG_ERROR_LOG_NOTIFY, 4, (UINT8 *)&uiErrorIndex, FALSE);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

}

void utilDataMgr_WriteGecLog(UINT32 ulIndex)
{
    char cStrTemp[128] = {'\0'};
    UINT16 uiCount = 0;
    UINT16 uiStrlen = 0;
    uOPD_DATA uOPDData = {0};

    for(uiCount = 0; uiCount < eERROR_LIST_INVALID; uiCount++)
    {
        if(sGEC_ERRORCODE_TABLE[uiCount].uiErrorIndex == ulIndex)
        {
            if( strcmp(sGEC_ERRORCODE_TABLE[uiCount].ERROREVENT, "") == 0 ) //G100_Simon_0060
            {
                sprintf(cStrTemp, "Error Code 0x%08x\0", sGEC_ERRORCODE_TABLE[uiCount].uiErrorIndex);
                uiStrlen = strlen(cStrTemp);
            }
            else
            {
                sprintf(cStrTemp, "%s\0", sGEC_ERRORCODE_TABLE[uiCount].ERROREVENT);
                uiStrlen = strlen(cStrTemp);
            }
            break;
        }
    }

    if(uiCount >= eERROR_LIST_INVALID)  //G100_Simon_0060
    {
        return;
    }

    if(sGEC_ERRORCODE_TABLE[uiCount].ucWriteCheck == GEC_ERROR) //A70Gen2_Julie_0049
    {
		if(uiCount < eI2CError || (uiCount > eSPIError && uiCount < eI2Cwarn) || uiCount > eI2Cwarn32)
		{
		    utilDataMgr_WriteErrorLog(ulIndex, cStrTemp);
		}
    }

    uOPDData.sErrorLog.dwGECCode = ulIndex;
    snprintf(uOPDData.sErrorLog.cString, 127, "%s", cStrTemp);

    if(sGEC_ERRORCODE_TABLE[uiCount].ucWriteCheck == GEC_ERROR)
    {
        utilOPD_EventSet(eOPD_ERROR_LOG, &uOPDData);
    }
    else if(sGEC_ERRORCODE_TABLE[uiCount].ucWriteCheck == GEC_WARNING) //A70LK_Larry_0110
    {
        utilOPD_EventSet(eOPD_WARNING_LOG, &uOPDData);
    }
    else if(sGEC_ERRORCODE_TABLE[uiCount].ucWriteCheck == GEC_REMINDER) //A70LK_Larry_0110
    {
        if(uiCount >= eI2CError01 && uiCount <= eI2CError32)
        {
            utilOPD_EventSet(eOPD_ERROR_LOG, &uOPDData);
        }
        else if(uiCount >= eI2Cwarn01 && uiCount <= eI2Cwarn32)
        {
            utilOPD_EventSet(eOPD_WARNING_LOG, &uOPDData);
        }
    }

    if((uiCount >= eFanLock && uiCount <= eFanLock15) || (uiCount >= eAmbientHighTemp && uiCount <= eLightModuleOverTemp15) || (uiCount >= eDMDOverTemp && uiCount <= eWheelStop06)) //G100_Julie_0046
    {
        palDataMgr_OPDSnapshot(eOPD_SNAPSHOT_LOG);
    }
	else if(uiCount == eAmbientHighTemp || uiCount == eSystemHighTemp || (uiCount >= eFanStallWarn && uiCount <= eFanStallWarn15) || uiCount == eLCSStall03 || uiCount == eDMDOverTemp02 || uiCount == eDMDOverTemp03 || uiCount == eTECOverTemp02 || uiCount == eTECOverTemp03) //A70Gen2_Julie_0047
    {
		palDataMgr_OPDSnapshot(eOPD_SNAPSHOT_LOG);
    }

    if(uiCount == eInterLockSwitchFail) //G100_Owen_0064
    {
        palIllumination_InstantOff();
    }

#if defined(CUSTOM_CHRISTIE)
    switch(ulIndex)
    {
        case SystemOverTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_SYS_TEMP_ERROR);
            break;

        case SystemHighTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_SYS_TEMP_WARN);
            break;

        case AmbientOverTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_AMBIENT_TEMP_ERROR);
            break;

        case AmbientHighTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_AMBIENT_TEMP_WARN);
            break;

        case DMDOverTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_DMD_TEMP_ERROR);
            break;

        case DMDOverTemp02:
            appGui_SendWarningMessage(eWARNING_MESSAGE_DMD_TEMP_WARN);
            break;

        case LightModuleOverTemp:
            appGui_SendWarningMessage(eWARNING_MESSAGE_BLD_TEMP_ERROR);
            break;

        case LightModuleWarnTemp01:
        case LightModuleWarnTemp02:
        case LightModuleWarnTemp03:
        case LightModuleWarnTemp04:
        case LightModuleWarnTemp05:
        case LightModuleWarnTemp06:
        case LightModuleWarnTemp07:
        case LightModuleWarnTemp08:
		case LightModuleWarnTemp09:
		case LightModuleWarnTemp10:
            appGui_SendWarningMessage(eWARNING_MESSAGE_BLD_TEMP_WARN);
            break;

		case TECOverTemp01:
            appGui_SendWarningMessage(eWARNING_MESSAGE_RLD_TEMP_ERROR);
			break;

        case LightModuleWarnTemp11:
        case LightModuleWarnTemp12:
        case LightModuleWarnTemp13:
        case LightModuleWarnTemp14:
		case TECOverTemp02:
            appGui_SendWarningMessage(eWARNING_MESSAGE_RLD_TEMP_WARN);
			break;

		case LCSStall01:
            appGui_SendWarningMessage(eWARNING_MESSAGE_PUMP_SPEED_ERROR);
			break;

		case LCSStall03:
            appGui_SendWarningMessage(eWARNING_MESSAGE_PUMP_SPEED_WARN);
			break;

        case FanStallError01:
        case FanStallError02:
        case FanStallError03:
        case FanStallError04:
        case FanStallError05:
        case FanStallError06:
        case FanStallError07:
        case FanStallError08:
        case FanStallError09:
		case FanStallError10:
		case FanStallError11:
		case FanStallError12:
            {
                UINT8 ucIndex = ulIndex&0xFF;
                appGui_SendWarningMessage(eWARNING_MESSAGE_FAN1_SPEED_ERROR + ucIndex - 1);
            }
            break;

        case FanStallWarn01:
        case FanStallWarn02:
        case FanStallWarn03:
        case FanStallWarn04:
        case FanStallWarn05:
        case FanStallWarn06:
        case FanStallWarn07:
        case FanStallWarn08:
        case FanStallWarn09:
		case FanStallWarn10:
		case FanStallWarn11:
		case FanStallWarn12:
            {
                UINT8 ucIndex = ulIndex&0xFF;
                appGui_SendWarningMessage(eWARNING_MESSAGE_FAN1_SPEED_WARN + ucIndex - 1);
            }
            break;
    }
#endif /* CUSTOM_CHRISTIE */

    return;
}

UINT16 utilDataMgr_LoadLastLog(UINT16 ucNum, char pcString[][128])
{
    FILE *pFile;
    UINT16 uiReadCount = 0;
    UINT16 uiStart = 0;
    UINT16 uiEnd = 0;
    UINT16 cCount = 0;
    char cLog[MAX_LOG_NUMBER + 1][MAX_LOG_LENGHT] = {'\0'};
	char cTime[MAX_LOG_LENGHT] = {'\0'};
	char cString[MAX_LOG_LENGHT] = {'\0'};

    if(access(ERROR_LOG_TXT,0)==-1)
    {
        return 0;
    }

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        pFile = fopen(ERROR_LOG_TXT, "r");

        if(pFile != NULL)
        {
            while(uiReadCount < MAX_LOG_NUMBER)
            {
                if(fgets(cLog[uiReadCount], MAX_LOG_LENGHT, pFile))
                {
                	memset(cTime,'\0',MAX_LOG_LENGHT);
                	memset(cString,'\0',MAX_LOG_LENGHT);
					sscanf(cLog[uiReadCount], "%127[^,],%127[^,],%*[^ ]", cTime, cString);  //G100_Simon_0060
					sprintf(cLog[uiReadCount], "%s,%s", cTime, cString);
                    uiReadCount++;
                }
                else
                {
                    break;
                }
            }
            fclose(pFile);

            if(uiReadCount < ucNum)
            {
                uiStart = 0;
                uiEnd = uiReadCount;
            }
            else
            {
                uiStart = uiReadCount - ucNum;
                uiEnd = ucNum;
            }

            for(cCount = 0; cCount < uiEnd; cCount++)
            {
                sprintf(pcString[cCount], "%s", cLog[uiStart + cCount]);
            }
        }
        else
        {
            cCount = 0;
        }

        utilDataMgr_MutexGive(__FUNCTION__);
    }

    return cCount;
}

void utilDataMgr_ClearLog(void)
{
    if(access(ERROR_LOG_TXT,0)==-1)
    {
        return;
    }

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        remove(ERROR_LOG_TXT);

        utilDataMgr_MutexGive(__FUNCTION__);
    }

    return;
}

void utilDataMgr_WriteSSTinfo(char *pcString)   //G100_Julie_0036
{
    FILE *pFile;
    char cStrTemp[128] = {'\0'};
    char cStrInfo[1024] = {'\0'};
    UINT16 uiStrlen = strlen(pcString);
    UINT32 ulTotalProjectorMinute = (UINT32)atol(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue);
    UINT16 wDay = 0, wHour = 0, wMin = 0;

    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        pFile = fopen(SST_INFO_TXT, "a+");

		snprintf(cStrTemp, 127, pcString);

        if(cStrTemp[uiStrlen - 1] == '\r' || cStrTemp[uiStrlen - 1] == '\n')
        {
            cStrTemp[uiStrlen - 1] = '\0';
            uiStrlen = strlen(cStrTemp);
        }

        wDay  = ulTotalProjectorMinute / 1440 ;
        wHour = (ulTotalProjectorMinute / 60) % 24;
        wMin  = ulTotalProjectorMinute % 60;

		snprintf((char*)cStrInfo, 1023, "%04d:%02d:%02d, %s\n", wDay, wHour, wMin, cStrTemp);

        if(pFile != NULL)  //G100_Simon_0092
        {
            fprintf(pFile, "%s", cStrInfo);
            fclose(pFile);
        }
    	else
    	{
            LOG_MSG(db_HAL_EEP, "%s file open fail\n", SST_INFO_TXT);
    	}

        utilDataMgr_MutexGive(__FUNCTION__);
    }
}

#if 0
UINT8 utilDataMgr_Reload123(UINT16 uiIndex)		//G100_Doulas_0002 test
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
	char *pcNull="";	//ProAV_Doulas_0001

    if(uiIndex > MAX_DATA_NODE)
    {
        return 0;
    }

    pFile = fopen(m_sDataNodeCtrl[uiIndex].cNodeFileName, "r");

    fseek(pFile, 0, SEEK_END);
    ulSize = ftell(pFile);
    fclose(pFile);

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(m_sDataNodeCtrl[uiIndex].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = utilDataMgr_ParaTableGet(m_sDataNodeCtrl[uiIndex].uiNode);
    ulFind = utilDataMgr_ParaTableSizeGet(m_sDataNodeCtrl[uiIndex].uiNode);

    if(psPara == NULL)
    {
        return 0;
    }

    pcGetValue = findArgValue("uiCheckSum", conf_argv, FileLine);

    //if(pcGetValue != "")                  //ProAV_Doulas_0001 remove
    if(strcmp(pcGetValue, pcNull) != 0)		//ProAV_Doulas_0001 Modify
    {
        uiCheckSum = (UINT16)atol(pcGetValue);
        uiCheckSum = (~uiCheckSum) + 1;
    }

    //check data check sum
    for(ulCount = 0; ulCount < ulFind; ulCount++)
    {
        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);
		LOG_MSG(db_ALWAYS,"(line=%03d)%s = %s\n",ulCount,psPara[ulCount].cParaName,psPara[ulCount].cParaValue);

        //if(pcGetValue == "")	                //ProAV_Doulas_0001 remove
        if(strcmp(pcGetValue, pcNull) == 0)     //ProAV_Doulas_0001 Modify
        {
            //文件裡找不到，需要寫入文件裡
            //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, psPara[ulCount].cParaName, psPara[ulCount].cParaValue);
        }
        else
        {
            uiStrlen = strlen(pcGetValue);

            if(strcmp(psPara[ulCount].cParaName, "uiCheckSum") != 0)
            {
                for(uiCount = 0; uiCount < uiStrlen; uiCount++)
                {
                    //reference ascii printable characters (without space key)
                    if((pcGetValue[uiCount] > 0x20) && (pcGetValue[uiCount] < 0x7F))
                    {
                        uiCheckSum += pcGetValue[uiCount];
                    }
                }
            }
        }
    }


    free(pcBuffer);

    return 1;
}
#endif
static UINT8 utilDataMgr_Reload_Backup_Check(UINT16 uiIndex,UINT8 ucType)		//G100_Doulas_0004 Modify
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
	sPARA_FORMAT *psParaDefault = NULL;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
	//char *pcNull="";

    if(uiIndex >= eDATA_BACKUP_RESTORE_NUMBER)
    {
        return eEXEC_CODE_FAIL;
    }

	if(ucType == eBACKUP_RESTORE_CHANGE_MAIN_BOARD)				//G100_Doulas_0004 Modify
	{
		psParaDefault = m_sBackupRestoreCheck_Change_Main_Board;
	}
	else if(ucType == eBACKUP_RESTORE_CHANGE_PROJECTOR)
	{
		psParaDefault = m_sBackupRestoreCheck_Change_Projector;
	}
	else
	{
		psParaDefault = m_sBackupRestoreCheck_Default;
	}
	psPara = m_sBackup_Restore_Check;
	ulSize = eBR_NUMBER;
	memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulSize*sizeof(sPARA_FORMAT));

    pFile = fopen(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, "r");

	if(pFile == NULL)
		return eEXEC_CODE_FAIL;

    fseek(pFile, 0, SEEK_END);
    ulSize = ftell(pFile);
    fclose(pFile);

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = m_sBackup_Restore_Check; //utilDataMgr_ParaTableGet(m_sDataNodeCtrl1[uiIndex].uiNode);
    ulFind = eBR_NUMBER; //utilDataMgr_ParaTableSizeGet(m_sDataNodeCtrl1[uiIndex].uiNode);

    if(psPara == NULL)
    {
        return eEXEC_CODE_FAIL;
    }

    for(ulCount = 0; ulCount < ulFind; ulCount++)
    {
        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

		/*if(strcmp(pcGetValue, pcNull) == 0)	//ProAV_Doulas_0001 Modify.//pcGetValue is Null
        {
            //文件裡找不到，需要寫入文件裡
            LOG_MSG(db_HAL_EEP,"%s error (line=%d) value=%s\n",psPara[ulCount].cParaName,ulCount,psPara[ulCount].cParaValue);
            //setArgValue(m_sDataNodeCtrl[uiIndex].cNodeFileName, psPara[ulCount].cParaName, psPara[ulCount].cParaValue);
            m_sDataNodeCtrl[uiIndex].cFlag = 1;
        }
        else*/
        {
            memset(psPara[ulCount].cParaValue,  '\0', DATA_MGR_VALUE_LEN);
            strcpy(psPara[ulCount].cParaValue, pcGetValue);
        }
		LOG_MSG(db_HAL_EEP,"(%02d)%s = %s \n",ulCount,psPara[ulCount].cParaName,psPara[ulCount].cParaValue);
    }

    free(pcBuffer);



    return eEXEC_CODE_PASS;
}

static UINT8 utilDataMgr_Reload_Common_Gui(UINT16 uiIndex,e_BACKUP_RESTORE_TYPE eRestoreType)	//G100_Doulas_0034 Modify //G100_Doulas_0002
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
	sPARA_FORMAT *psParaDefault = NULL;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
	char *pcNull="";

    if(uiIndex >= eDATA_BACKUP_RESTORE_NUMBER)
    {
        return eEXEC_CODE_FAIL;
    }

    pFile = fopen(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, "r");

	if(pFile == NULL)
		return eEXEC_CODE_FAIL;

    fseek(pFile, 0, SEEK_END);
    ulSize = ftell(pFile);
    fclose(pFile);

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = utilDataMgr_ParaTableGet(eDATA_NODE_COMMONGUI);
    ulFind = utilDataMgr_ParaTableSizeGet(eDATA_NODE_COMMONGUI);

    if(psPara == NULL)
    {
        return eEXEC_CODE_FAIL;
    }

    for(ulCount = 0; ulCount < ulFind; ulCount++)
    {
        if(ulCount == (ulFind - 1))  //skip reload checksum    //G100_Simon_0017
        {
            continue;
        }

        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

		if(strcmp(pcGetValue, pcNull) == 0)	//ProAV_Doulas_0001 Modify.//pcGetValue is Null
        {

        }
		else if(((ulCount == eCG_UCDHCP) ||
				 (ulCount == eCG_ULDBMASK) || 						//G100_Doulas_0004
				 (ulCount == eCG_UCLENSMEMORYAPPLY) || 				//G100_Doulas_0004
				 (ulCount == eCG_UCLENSMEMORYSAVE) || 				//G100_Doulas_0004
				 //(ulCount == eCG_UCHSGADJUSTMENTAUTOTESTPATTERN) ||	//G100_Doulas_0057 remove//G100_Doulas_0004
				 (ulCount == eCG_UCFACTORYTESTPATTERN) || 			//G100_Doulas_0004
				 (ulCount == eCG_UCSERVICEMENUTESTPATTERN) || 		//G100_Doulas_0004
				 (ulCount == eCG_UCFACTORYMENUCUSTOMPATTERN) || 	//G100_Doulas_0004
				 (ulCount == eCG_UCOSDTESTPATTERN) || 				//G100_Doulas_0004
				 (ulCount == eCG_UCIMAGEFREEZE) || 					//G100_Doulas_0004
				 (ulCount == eCG_CONSTANT_BRIGHTNESS) || 			//G100_Doulas_0013 Add
				 //(ulCount == eCG_STARTUP_SHUTTER) || 				//G100_Doulas_0054 Remove//G100_Doulas_0013 Add
				 (ulCount == eCG_UCLIGHTCALIBRATIONMODE) || 		//G100_Doulas_0013 Add
				 (ulCount == eCG_UCCHANGEPIN) || 					//G100_Doulas_0013 Add
				 (ulCount == eCG_UCSYSERRCODE) || 					//G100_Doulas_0013 Add
				 (ulCount == eCG_SECURITY_TOTALREMAINMIN) || 		//G100_Doulas_0013 Add
			     (ulCount == eCG_UCBACKUPRESTORESAVE) ||
			     (ulCount == eCG_UCBACKUPRESTORERESTORE) ||
			     (ulCount == eCG_UCCRESTRON_ENABLE) ||
			     (ulCount == eCG_UCLENSPEED)) &&
			     (eRestoreType == eBACKUP_RESTORE_NORMAL))		//G100_Doulas_0034 Modify
		{

		}
		else if(((ulCount == eCG_UCDHCP) ||
				 (ulCount == eCG_ULDBMASK) ||
				 (ulCount == eCG_UCLENSMEMORYAPPLY) ||
				 (ulCount == eCG_UCLENSMEMORYSAVE) ||
				 //(ulCount == eCG_UCHSGADJUSTMENTAUTOTESTPATTERN) ||		//G100_Doulas_0057 remove
				 (ulCount == eCG_UCFACTORYTESTPATTERN) ||
				 (ulCount == eCG_UCSERVICEMENUTESTPATTERN) ||
				 (ulCount == eCG_UCFACTORYMENUCUSTOMPATTERN) ||
				 (ulCount == eCG_UCOSDTESTPATTERN) ||
				 (ulCount == eCG_UCIMAGEFREEZE) ||
				 (ulCount == eCG_CONSTANT_BRIGHTNESS) ||
				 //(ulCount == eCG_STARTUP_SHUTTER) ||					//G100_Doulas_0054 Remove
				 (ulCount == eCG_UCLIGHTCALIBRATIONMODE) ||
				 (ulCount == eCG_UCCHANGEPIN) ||
				 (ulCount == eCG_UCSYSERRCODE) ||
				 (ulCount == eCG_SECURITY_TOTALREMAINMIN) ||
			     (ulCount == eCG_UCBACKUPRESTORESAVE) ||
			     (ulCount == eCG_UCBACKUPRESTORERESTORE) ||
			     (ulCount == eCG_UCCRESTRON_ENABLE) ||
			     (ulCount == eCG_UCLENSPEED)) &&
			     (eRestoreType == eBACKUP_RESTORE_CHANGE_PROJECTOR))		//G100_Doulas_0034
		{

		}
		else if(((ulCount == eCG_UCDHCP) ||
				 (ulCount == eCG_ULDBMASK) ||
				 (ulCount == eCG_UCLENSMEMORYAPPLY) ||
				 (ulCount == eCG_UCLENSMEMORYSAVE) ||
				 //(ulCount == eCG_UCHSGADJUSTMENTAUTOTESTPATTERN) ||		//G100_Doulas_0057 remove
				 (ulCount == eCG_UCFACTORYTESTPATTERN) ||
				 (ulCount == eCG_UCSERVICEMENUTESTPATTERN) ||
				 (ulCount == eCG_UCFACTORYMENUCUSTOMPATTERN) ||
				 (ulCount == eCG_UCOSDTESTPATTERN) ||
				 (ulCount == eCG_UCIMAGEFREEZE) ||
				 //(ulCount == eCG_CONSTANT_BRIGHTNESS) ||
				 //(ulCount == eCG_STARTUP_SHUTTER) ||					//G100_Doulas_0054 Remove
				 (ulCount == eCG_UCLIGHTCALIBRATIONMODE) ||
				 (ulCount == eCG_UCCHANGEPIN) ||
				 (ulCount == eCG_UCSYSERRCODE) ||
				 (ulCount == eCG_SECURITY_TOTALREMAINMIN) ||
			     (ulCount == eCG_UCBACKUPRESTORESAVE) ||
			     (ulCount == eCG_UCBACKUPRESTORERESTORE) ||
			     (ulCount == eCG_UCCRESTRON_ENABLE) ||
			     (ulCount == eCG_UCLENSPEED)) &&
			    (eRestoreType == eBACKUP_RESTORE_CHANGE_MAIN_BOARD))		//G100_Doulas_0034
		{

		}
        else
        {
            memset(psPara[ulCount].cParaValue,  '\0', DATA_MGR_VALUE_LEN);
            strcpy(psPara[ulCount].cParaValue, pcGetValue);
        }
	//	LOG_MSG(db_ALWAYS,"(%03d)%s = %s \n",ulCount,psPara[ulCount].cParaName,psPara[ulCount].cParaValue);
    }

    free(pcBuffer);

	//m_sDataNodeCtrl[eDATA_NODE_COMMONGUI].cFlag = 1;

    return eEXEC_CODE_PASS;
}


static UINT8 utilDataMgr_Reload_Restore(UINT16 uiNode)
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;
    sDATA_NODE_CTRL *psNode = NULL;
    UINT16  uiNodeSize = 0;
    UINT16  ulIndexCount = 0;
    BOOL bCheck = TRUE;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
	char *pcNull="";

    for(UINT16 uiGroup = 0; uiGroup < MAX_NODE_GROUP_NUMBER; uiGroup++)
    {
        psNode = m_sDataNodeGroup[uiGroup].psNode;
        uiNodeSize = m_sDataNodeGroup[uiGroup].uiSize;

        for(ulIndexCount = 0; ulIndexCount < uiNodeSize; ulIndexCount++ )
    	{
    		if(psNode[ulIndexCount].uiNode == uiNode)
    		{
    			bCheck = FALSE;
                uiGroup = MAX_NODE_GROUP_NUMBER;
    			break;
    		}
    	}
    }

    if(bCheck)
    {
        return eEXEC_CODE_FAIL;
    }

    pFile = fopen(psNode[ulIndexCount].cNodeFileName, "r");

    if(pFile == NULL)  //G100_Simon_0092
    {
        return eEXEC_CODE_FAIL;
    }

    fseek(pFile, 0, SEEK_END);
    ulSize = ftell(pFile);
    fclose(pFile);

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(psNode[ulIndexCount].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = utilDataMgr_ParaTableGet(psNode[ulIndexCount].uiNode);
    ulFind = utilDataMgr_ParaTableSizeGet(psNode[ulIndexCount].uiNode);

    if(psPara == NULL || (INT32)FileLine < 0)  //G100_Simon_0092
    {
        return eEXEC_CODE_FAIL;
    }

    for(ulCount = 0; ulCount < ulFind; ulCount++)
    {
        if(ulCount == (ulFind - 1))  //skip reload checksum    //G100_Simon_0017
        {
            continue;
        }

        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

		if(strcmp(pcGetValue, pcNull) == 0)	//ProAV_Doulas_0001 Modify.//pcGetValue is Null
        {
            //文件裡找不到
        }
        else
        {
            memset(psPara[ulCount].cParaValue,  '\0', DATA_MGR_VALUE_LEN);
            strcpy(psPara[ulCount].cParaValue, pcGetValue);
        }
        //strcpy
    }

    free(pcBuffer);
	//m_sDataNodeCtrl[uiIndex].cFlag = 1;
	//LOG_MSG(db_ALWAYS,"Reload_Restore %d\r\n",uiIndex);

    return eEXEC_CODE_PASS;
}

UINT8 utilDataMgr_UserDataSave(UINT8 uiIndex)		//G100_Doulas_0002
{
    sPARA_FORMAT *psParaDefault = NULL;
    sPARA_FORMAT *psPara = NULL;
	UINT32 ulSize = 0;
	char *conf_argv[100][2];
	UINT32 ulCount = 0;
	//UINT8 ucModel[10] = "T123";

	psParaDefault = m_sBackupRestoreCheck_Default;
	psPara = m_sBackup_Restore_Check;
	ulSize = eBR_NUMBER;
	memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulSize*sizeof(sPARA_FORMAT));

	//memcpy((UINT8*)m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue,(UINT8*)ucModel,sizeof(ucModel));
	//m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue[0] = '1';
	for(ulCount = 0; ulCount < ulSize; ulCount++)
    {
       conf_argv[ulCount][0] = psPara[ulCount].cParaName;
       conf_argv[ulCount][1] = psPara[ulCount].cParaValue;
    }

    switch(uiIndex)
	{
		case eUSER_DATA_SAVE0:
			if(access(BACKUP_CONFIG_0_PATH, F_OK) == 0)	//have dir
			{
			    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_0_PATH);
				//LOG_MSG(db_ALWAYS,"OK\r\n");
			}

            if(access(BACKUP_CONFIG_0_PATH, 0) == -1)
            {
                mkdir(BACKUP_CONFIG_0_PATH, 0777);
				mkdir(BACKUP_CONFIG_0_SCALER_PATH, 0777);
            }

            //copy gui config
            SYSTEM_CALL("cp -R %s %s/gui", CONF_SCALER_GUI_PATH, BACKUP_CONFIG_0_SCALER_PATH);
            //copy source config
            SYSTEM_CALL("cp -R %s %s/source", CONF_SCALER_SOURCE_PATH, BACKUP_CONFIG_0_SCALER_PATH);
            if(access(BACKUP_CONFIG_0_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("rm -rf %s", BACKUP_CONFIG_0_SCALER_EDID_PATH);
            }
            if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("cp -R %s %s", CONF_SCALER_EDID_PATH, BACKUP_CONFIG_0_SCALER_PATH);
            }

			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK0].cNodeFileName, conf_argv, ulSize);		//save to file

            //remov warping config
			SYSTEM_CALL("rm %s/gui/Warping.conf 2> /dev/null", BACKUP_CONFIG_0_SCALER_PATH);
			break;

		case eUSER_DATA_SAVE1:
        	if(access(BACKUP_CONFIG_1_PATH, F_OK) == 0)	//have dir
			{
			    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_1_PATH);
			}

            if(access(BACKUP_CONFIG_1_PATH, 0) == -1)
            {
                mkdir(BACKUP_CONFIG_1_PATH, 0777);
				mkdir(BACKUP_CONFIG_1_SCALER_PATH, 0777);
            }

            //copy gui config
            SYSTEM_CALL("cp -R %s %s/gui", CONF_SCALER_GUI_PATH, BACKUP_CONFIG_1_SCALER_PATH);
            //copy source config
            SYSTEM_CALL("cp -R %s %s/source", CONF_SCALER_SOURCE_PATH, BACKUP_CONFIG_1_SCALER_PATH);
            if(access(BACKUP_CONFIG_1_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("rm -rf %s", BACKUP_CONFIG_1_SCALER_EDID_PATH);
            }
            if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("cp -R %s %s", CONF_SCALER_EDID_PATH, BACKUP_CONFIG_1_SCALER_PATH);
            }
			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK1].cNodeFileName, conf_argv, ulSize);		//save to file

            //remov warping config
			SYSTEM_CALL("rm %s/gui/Warping.conf 2> /dev/null", BACKUP_CONFIG_1_SCALER_PATH);
			break;

		case eUSER_DATA_SAVE2:
            if(access(BACKUP_CONFIG_2_PATH, F_OK) == 0) //have dir
            {
                SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_2_PATH);		//G100_Doulas_0060 Modify ,remove error
            }

            if(access(BACKUP_CONFIG_2_PATH, 0) == -1)
            {
                mkdir(BACKUP_CONFIG_2_PATH, 0777);
				mkdir(BACKUP_CONFIG_2_SCALER_PATH, 0777);
            }

            //copy gui config
            SYSTEM_CALL("cp -R %s %s/gui", CONF_SCALER_GUI_PATH, BACKUP_CONFIG_2_SCALER_PATH);
            //copy source config
            SYSTEM_CALL("cp -R %s %s/source", CONF_SCALER_SOURCE_PATH, BACKUP_CONFIG_2_SCALER_PATH);
            if(access(BACKUP_CONFIG_2_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("rm -rf %s", BACKUP_CONFIG_2_SCALER_EDID_PATH);
            }
            if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("cp -R %s %s", CONF_SCALER_EDID_PATH, BACKUP_CONFIG_2_SCALER_PATH);
            }
			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK2].cNodeFileName, conf_argv, ulSize);		//save to file

            //remov warping config
			SYSTEM_CALL("rm %s/gui/Warping.conf 2> /dev/null", BACKUP_CONFIG_2_SCALER_PATH);
			break;

		case eUSER_DATA_SAVE3:
            if(access(BACKUP_CONFIG_3_PATH, F_OK) == 0) //have dir
            {
                SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_3_PATH);
            }

            if(access(BACKUP_CONFIG_3_PATH, 0) == -1)
            {
                mkdir(BACKUP_CONFIG_3_PATH, 0777);
				mkdir(BACKUP_CONFIG_3_SCALER_PATH, 0777);
            }

            //copy gui config
            SYSTEM_CALL("cp -R %s %s/gui", CONF_SCALER_GUI_PATH, BACKUP_CONFIG_3_SCALER_PATH);
            //copy source config
            SYSTEM_CALL("cp -R %s %s/source", CONF_SCALER_SOURCE_PATH, BACKUP_CONFIG_3_SCALER_PATH);
            if(access(BACKUP_CONFIG_3_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("rm -rf %s", BACKUP_CONFIG_3_SCALER_EDID_PATH);
            }
            if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("cp -R %s %s", CONF_SCALER_EDID_PATH, BACKUP_CONFIG_3_SCALER_PATH);
            }
			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK3].cNodeFileName, conf_argv, ulSize);		//save to file

            //remov warping config
			SYSTEM_CALL("rm %s/gui/Warping.conf 2> /dev/null", BACKUP_CONFIG_3_SCALER_PATH);
			break;
		case eUSER_DATA_SAVE4:
            if(access(BACKUP_CONFIG_4_PATH, F_OK) == 0) //have dir
            {
                SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_4_PATH);
            }

            if(access(BACKUP_CONFIG_4_PATH, 0) == -1)
            {
                mkdir(BACKUP_CONFIG_4_PATH, 0777);
				mkdir(BACKUP_CONFIG_4_SCALER_PATH, 0777);
            }

            //copy gui config
            SYSTEM_CALL("cp -R %s %s/gui", CONF_SCALER_GUI_PATH, BACKUP_CONFIG_4_SCALER_PATH);
            //copy source config
            SYSTEM_CALL("cp -R %s %s/source", CONF_SCALER_SOURCE_PATH, BACKUP_CONFIG_4_SCALER_PATH);
            if(access(BACKUP_CONFIG_4_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("rm -rf %s", BACKUP_CONFIG_4_SCALER_EDID_PATH);
            }
            if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
            {
                SYSTEM_CALL("cp -R %s %s", CONF_SCALER_EDID_PATH, BACKUP_CONFIG_4_SCALER_PATH);
            }
			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK4].cNodeFileName, conf_argv, ulSize);		//save to file

            //remov warping config
			SYSTEM_CALL("rm %s/gui/Warping.conf 2> /dev/null", BACKUP_CONFIG_4_SCALER_PATH);
			break;
    }

    return eEXEC_CODE_PASS;
}

UINT8 utilDataMgr_UserDataLoad(UINT8 uiIndex)		//G100_Doulas_0002
{
    UINT8 ucResult = eEXEC_CODE_FAIL;//eEXEC_CODE_PASS;
    UINT16 ucCount = 0;		//G100_Doulas_0030 Modify
	if(uiIndex >= eUSER_DATA_LOAD_MAX_NUMBER)
		return eEXEC_CODE_FAIL;

    switch(uiIndex)
	{
		case eUSER_DATA_LOAD0:
			if(access(BACKUP_CONFIG_0_PATH, F_OK) == 0)	//check backup dir
			{
				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK0,eBACKUP_RESTORE_NORMAL) == eEXEC_CODE_PASS)		//G100_Doulas_0004 Modify
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//LOG_MSG(db_ALWAYS,"OK2\r\n"); //check backup ok
					}
					else
					{
						//LOG_MSG(db_ALWAYS,"Fail2\r\n");
						break;
					}
				}
				else
				{
					//LOG_MSG(db_ALWAYS,"Fail1\r\n");
					break;
				}

                SYSTEM_CALL("cp -R %s/source %s", BACKUP_CONFIG_0_SCALER_PATH, CONF_SCALER_PATH);
                // copy edid folder // x35G2_Bruce_0005
				if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("rm -rf %s", CONF_SCALER_EDID_PATH);
                }
                if(access(BACKUP_CONFIG_0_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("cp -R %s %s", BACKUP_CONFIG_0_SCALER_EDID_PATH, CONF_SCALER_PATH);
                }
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_GUI0,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)	//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
						utilDataMgr_Reload_Restore(ucCount);
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;

		case eUSER_DATA_LOAD1:
			if(access(BACKUP_CONFIG_1_PATH, F_OK) == 0)	//check backup dir
			{
				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK1,eBACKUP_RESTORE_NORMAL) == eEXEC_CODE_PASS)		//G100_Doulas_0004 Modify
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
                SYSTEM_CALL("cp -R %s/source %s", BACKUP_CONFIG_1_SCALER_PATH, CONF_SCALER_PATH);
                // copy edid folder // x35G2_Bruce_0005
				if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("rm -rf %s", CONF_SCALER_EDID_PATH);
                }
                if(access(BACKUP_CONFIG_1_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("cp -R %s %s", BACKUP_CONFIG_1_SCALER_EDID_PATH, CONF_SCALER_PATH);
                }
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_GUI1,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)	//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
						utilDataMgr_Reload_Restore(ucCount);
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;


		case eUSER_DATA_LOAD2:
			if(access(BACKUP_CONFIG_2_PATH, F_OK) == 0)	//check backup dir
			{
				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK2,eBACKUP_RESTORE_NORMAL) == eEXEC_CODE_PASS)		//G100_Doulas_0004 Modify
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}

                SYSTEM_CALL("cp -R %s/source %s", BACKUP_CONFIG_2_SCALER_PATH, CONF_SCALER_PATH);
                // copy edid folder // x35G2_Bruce_0005
				if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("rm -rf %s", CONF_SCALER_EDID_PATH);
                }
                if(access(BACKUP_CONFIG_2_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("cp -R %s %s", BACKUP_CONFIG_2_SCALER_EDID_PATH, CONF_SCALER_PATH);
                }
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_GUI2,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)	//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
						utilDataMgr_Reload_Restore(ucCount);
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;


		case eUSER_DATA_LOAD3:
			if(access(BACKUP_CONFIG_3_PATH, F_OK) == 0)	//check backup dir
			{
				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK3,eBACKUP_RESTORE_NORMAL) == eEXEC_CODE_PASS)		//G100_Doulas_0004 Modify
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
                SYSTEM_CALL("cp -R %s/source %s", BACKUP_CONFIG_3_SCALER_PATH, CONF_SCALER_PATH);
                // copy edid folder // x35G2_Bruce_0005
				if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("rm -rf %s", CONF_SCALER_EDID_PATH);
                }
                if(access(BACKUP_CONFIG_3_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("cp -R %s %s", BACKUP_CONFIG_3_SCALER_EDID_PATH, CONF_SCALER_PATH);
                }
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_GUI3,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)	//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
						utilDataMgr_Reload_Restore(ucCount);
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;


		case eUSER_DATA_LOAD4:
			if(access(BACKUP_CONFIG_4_PATH, F_OK) == 0)		//check backup dir
			{
				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK4,eBACKUP_RESTORE_NORMAL) == eEXEC_CODE_PASS)		//G100_Doulas_0004 Modify
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
                SYSTEM_CALL("cp -R %s/source %s", BACKUP_CONFIG_4_SCALER_PATH, CONF_SCALER_PATH);
                // copy edid folder // x35G2_Bruce_0005
				if(access(CONF_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("rm -rf %s", CONF_SCALER_EDID_PATH);
                }
                if(access(BACKUP_CONFIG_4_SCALER_EDID_PATH, F_OK) == 0)
                {
                    SYSTEM_CALL("cp -R %s %s", BACKUP_CONFIG_4_SCALER_EDID_PATH, CONF_SCALER_PATH);
                }
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_GUI4,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)	//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
						utilDataMgr_Reload_Restore(ucCount);
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;
	}

    return ucResult;
}

static UINT8 utilDataMgr_Reload_ProjectorInfo(UINT16 uiIndex)		//G100_Doulas_0004
{
    FILE *pFile = NULL;
    sPARA_FORMAT *psPara;
	sPARA_FORMAT *psParaDefault = NULL;
    UINT32 ulSize = 0;
    UINT32 FileLine = 0;
    UINT32 ulCount = 0;
    UINT32 ulFind = 0;
    UINT16 uiCheckSum = 0;
    UINT16 uiStrlen = 0;
    UINT16 uiCount = 0;

    char *conf_argv[1024][2];
    char *pcBuffer;
    char *pcGetValue;
	char *pcNull="";

    if(uiIndex >= eDATA_BACKUP_RESTORE_NUMBER)
    {
        return eEXEC_CODE_FAIL;
    }

    pFile = fopen(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, "r");

	if(pFile == NULL)
		return eEXEC_CODE_FAIL;

    fseek(pFile, 0, SEEK_END);
    ulSize = ftell(pFile);
    fclose(pFile);

    pcBuffer = (char*)malloc(ulSize+1);

    FileLine = (uint32)readConf(m_sDataNodeCtrlBackup[uiIndex].cNodeFileName, conf_argv, 1024, pcBuffer, ulSize);
    psPara = utilDataMgr_ParaTableGet(m_sDataNodeCtrl[eDATA_NODE_PROJECTORINFO].uiNode);
    ulFind = utilDataMgr_ParaTableSizeGet(m_sDataNodeCtrl[eDATA_NODE_PROJECTORINFO].uiNode);

    if(psPara == NULL)
    {
        return eEXEC_CODE_FAIL;
    }

    for(ulCount = 0; ulCount < ulFind; ulCount++)
    {
        pcGetValue = findArgValue(psPara[ulCount].cParaName, conf_argv, FileLine);

		if(strcmp(pcGetValue, pcNull) == 0)	//ProAV_Doulas_0001 Modify.//pcGetValue is Null
        {

        }
		else if((ulCount == ePI_UCMAJOR) ||
			    (ulCount == ePI_UCMINOR) ||
			    (ulCount == ePI_UCSUBMINOR))
		{

		}
        else
        {
            memset(psPara[ulCount].cParaValue,  '\0', DATA_MGR_VALUE_LEN);
            strcpy(psPara[ulCount].cParaValue, pcGetValue);
        }
	//	LOG_MSG(db_ALWAYS,"(%03d)%s = %s \n",ulCount,psPara[ulCount].cParaName,psPara[ulCount].cParaValue);
    }

    free(pcBuffer);

	//m_sDataNodeCtrl[eDATA_NODE_COMMONGUI].cFlag = 1;


    return eEXEC_CODE_PASS;
}


UINT8 utilDataMgr_WebBackupSave(UINT8 uiIndex)		//G100_Doulas_0004
{
    sPARA_FORMAT *psParaDefault = NULL;
    sPARA_FORMAT *psPara = NULL;
	UINT32 ulSize = 0;
	char *conf_argv[100][2];
	UINT32 ulCount = 0;
	//UINT8 ucModel[10] = "T123";
	if(uiIndex >= eBACKUP_RESTORE_MAX_NUMBER)
		return eEXEC_CODE_FAIL;

	if(uiIndex == eBACKUP_RESTORE_CHANGE_MAIN_BOARD)
	{
		psParaDefault = m_sBackupRestoreCheck_Change_Main_Board;
	}
	else if(uiIndex == eBACKUP_RESTORE_CHANGE_PROJECTOR)
	{
		psParaDefault = m_sBackupRestoreCheck_Change_Projector;
	}
	else
	{
		psParaDefault = m_sBackupRestoreCheck_Default;
	}
	psPara = m_sBackup_Restore_Check;
	ulSize = eBR_NUMBER;
	memcpy((UINT8*)psPara, (UINT8*)psParaDefault, ulSize*sizeof(sPARA_FORMAT));

	for(ulCount = 0; ulCount < ulSize; ulCount++)
    {
       conf_argv[ulCount][0] = psPara[ulCount].cParaName;
       conf_argv[ulCount][1] = psPara[ulCount].cParaValue;
    }

    switch(uiIndex)
	{
		case eBACKUP_RESTORE_NORMAL:
			if(access(BACKUP_PATH, F_OK) == 0)	//have dir
			{
			    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
			}

            if(access(BACKUP_PATH, 0) == -1)
            {
                mkdir(BACKUP_PATH, 0777);
                mkdir(BACKUP_SCALER_PATH, 0777);
                mkdir(BACKUP_SCALER_LAN_PATH, 0777);
            }

            SYSTEM_CALL("cp -R %s %s", CONF_SCALER_GUI_PATH, BACKUP_SCALER_GUI_PATH);
            SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SOURCE_PATH, BACKUP_SCALER_SOURCE_PATH);
            SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SYSTEM_PATH, BACKUP_SCALER_SYSTEM_PATH);

            SYSTEM_CALL("cp %s/net.conf %s/net.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);
            SYSTEM_CALL("cp %s/wifi.conf %s/wifi.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);

			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK_WEB].cNodeFileName, conf_argv, ulSize);		//save to file

            SYSTEM_CALL("rm %s/Warping.conf 2> /dev/null", BACKUP_SCALER_GUI_PATH);

            SYSTEM_CALL("cd %s/;tar -zcvf - Lan | openssl aes-256-cbc -e -out Lan.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
            SYSTEM_CALL("cd %s/;tar -zcvf - system | openssl aes-256-cbc -e -out system.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
            SYSTEM_CALL("cd %s/;tar -zcvf - BackupRestoreCheck.conf | openssl aes-256-cbc -e -out BackupRestoreCheck.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮

            SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_LAN_PATH);
            SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_SYSTEM_PATH);
            SYSTEM_CALL("rm %s/BackupRestoreCheck.conf 2> /dev/null", BACKUP_SCALER_PATH);

			SYSTEM_CALL("cd %s/;tar -zcvf Backup.tar.gz Backup/ 2> /dev/null", MNT_PATH);	//tar and gzip
			//system("cd /mnt/;tar -zcvf - Backup | openssl aes-256-cbc -e -out Backup.bin -k your_key_passwd 2> /dev/null");
			break;

		case eBACKUP_RESTORE_CHANGE_PROJECTOR:
			if(access(BACKUP_PATH, F_OK) == 0)	//have dir
			{
			    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
			}

            if(access(BACKUP_PATH, 0) == -1)
            {
                mkdir(BACKUP_PATH, 0777);
                mkdir(BACKUP_SCALER_PATH, 0777);
                mkdir(BACKUP_SCALER_LAN_PATH, 0777);
            }

			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_GUI_PATH, BACKUP_SCALER_GUI_PATH);
			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SOURCE_PATH, BACKUP_SCALER_SOURCE_PATH);
			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SYSTEM_PATH, BACKUP_SCALER_SYSTEM_PATH);
			SYSTEM_CALL("cp -R %s %s", ADV_WAPR_PATH, BACKUP_WARP_PATH);

            SYSTEM_CALL("cp %s/net.conf %s/net.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);
            SYSTEM_CALL("cp %s/wifi.conf %s/wifi.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);

			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK_WEB].cNodeFileName, conf_argv, ulSize);		//save to file

			SYSTEM_CALL("cd %s/;tar -zcvf - Lan | openssl aes-256-cbc -e -out Lan.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("cd %s/;tar -zcvf - system | openssl aes-256-cbc -e -out system.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("cd %s/;tar -zcvf - BackupRestoreCheck.conf | openssl aes-256-cbc -e -out BackupRestoreCheck.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_LAN_PATH);
			SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_SYSTEM_PATH);
			SYSTEM_CALL("rm %s/BackupRestoreCheck.conf 2> /dev/null", BACKUP_SCALER_PATH);

			SYSTEM_CALL("cd %s/;tar -zcvf Backup.tar.gz Backup/ 2> /dev/null", MNT_PATH);	//tar and gzip
			//system("cd /mnt/;tar -zcvf - Backup | openssl aes-256-cbc -e -out Backup.bin -k your_key_passwd 2> /dev/null");
			break;

		case eBACKUP_RESTORE_CHANGE_MAIN_BOARD:
        	if(access(BACKUP_PATH, F_OK) == 0)	//have dir
			{
			    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
			}

            if(access(BACKUP_PATH, 0) == -1)
            {
                mkdir(BACKUP_PATH, 0777);
                mkdir(BACKUP_SCALER_PATH, 0777);
                mkdir(BACKUP_SCALER_LAN_PATH, 0777);
            }

			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_GUI_PATH, BACKUP_SCALER_GUI_PATH);			//G100_Doulas_0030
			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SOURCE_PATH, BACKUP_SCALER_SOURCE_PATH);	//G100_Doulas_0030
			SYSTEM_CALL("cp -R %s %s", CONF_SCALER_SYSTEM_PATH, BACKUP_SCALER_SYSTEM_PATH);	//G100_Doulas_0030
			SYSTEM_CALL("cp -R %s %s", ADV_WAPR_PATH, BACKUP_WARP_PATH);								//G100_Doulas_0034

			SYSTEM_CALL("cp %s/net.conf %s/net.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);
			SYSTEM_CALL("cp %s/wifi.conf %s/wifi.conf", CONF_PATH, BACKUP_SCALER_LAN_PATH);
			writeConf(m_sDataNodeCtrlBackup[eDATA_BACKUP_RESTORE_CHECK_WEB].cNodeFileName, conf_argv, ulSize);		//save to file

			SYSTEM_CALL("cd %s/;tar -zcvf - Lan | openssl aes-256-cbc -e -out Lan.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("cd %s/;tar -zcvf - system | openssl aes-256-cbc -e -out system.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("cd %s/;tar -zcvf - BackupRestoreCheck.conf | openssl aes-256-cbc -e -out BackupRestoreCheck.bin -k passwd 2> /dev/null", BACKUP_SCALER_PATH); 	//加密壓縮
			SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_LAN_PATH);
			SYSTEM_CALL("rm -R %s/ 2> /dev/null", BACKUP_SCALER_SYSTEM_PATH);
			SYSTEM_CALL("rm %s/BackupRestoreCheck.conf 2> /dev/null", BACKUP_SCALER_PATH);

			SYSTEM_CALL("cd %s/;tar -zcvf Backup.tar.gz Backup/ 2> /dev/null", MNT_PATH);	//tar and gzip
			//system("cd /mnt/;tar -zcvf - Backup | openssl aes-256-cbc -e -out Backup.bin -k your_key_passwd 2> /dev/null");
			break;

    }

    return eEXEC_CODE_PASS;
}

UINT8 utilDataMgr_WebRestore(UINT8 uiIndex)		//G100_Doulas_0004
{
    UINT8 ucResult = eEXEC_CODE_FAIL;//eEXEC_CODE_PASS;
    UINT16 ucCount = 0;		//G100_Doulas_0030 Modify
	if(uiIndex >= eUSER_DATA_LOAD_MAX_NUMBER)
		return eEXEC_CODE_FAIL;

    switch(uiIndex)
	{
		case eBACKUP_RESTORE_NORMAL:
			if(access(BACKUP_TAR_GZ,F_OK) == 0)	//check backup dir
			{
				if(access(BACKUP_PATH, F_OK) == 0)	//have dir
				{
                    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
				}
				SYSTEM_CALL("tar -xvf %s -C %s/", BACKUP_TAR_GZ, MNT_PATH);
				//system("cd /mnt/;openssl aes-256-cbc -d -in Backup.bin -k your_key_passwd | tar zxf -");
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in Lan.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in system.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in BackupRestoreCheck.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);

				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK_WEB,uiIndex) == eEXEC_CODE_PASS)
				{
					if((strcmp(m_sBackupRestoreCheck_Default[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Default[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
				//LOG_MSG(db_ALWAYS,"OK3\r\n");

				SYSTEM_CALL("cp -R %s %s", BACKUP_SCALER_SOURCE_PATH, CONF_SCALER_PATH);
				//system("cp -R /mnt/configs0/scaler/system /mnt/configs/scaler");
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_WEB_GUI,eBACKUP_RESTORE_NORMAL);		//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount < eDATA_NODE_NUMBER; ucCount++)		////G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
					{
						utilDataMgr_Reload_Restore(ucCount);
					}
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;

		case eBACKUP_RESTORE_CHANGE_PROJECTOR:
			if(access(BACKUP_TAR_GZ,F_OK) == 0)	//check backup dir
			{
				if(access(BACKUP_PATH, F_OK) == 0)	//have dir
				{
                    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
				}
				SYSTEM_CALL("tar -xvf %s -C %s/", BACKUP_TAR_GZ, MNT_PATH);
				//system("cd /mnt/;openssl aes-256-cbc -d -in Backup.bin -k your_key_passwd | tar zxf -");

				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in Lan.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in system.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in BackupRestoreCheck.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);

				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK_WEB,uiIndex) == eEXEC_CODE_PASS)
				{
					if((strcmp(m_sBackupRestoreCheck_Change_Projector[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Change_Projector[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
				//LOG_MSG(db_ALWAYS,"OK3\r\n");
				SYSTEM_CALL("cp -R %s/Warping.conf %s/Warping.conf", BACKUP_SCALER_GUI_PATH, CONF_SCALER_GUI_PATH);
				SYSTEM_CALL("cp -R %s %s", BACKUP_SCALER_SOURCE_PATH, CONF_SCALER_PATH);
				SYSTEM_CALL("cp -R %s %s", BACKUP_WARP_PATH, MNT_PATH);									//G100_Doulas_0078 Modify//G100_Doulas_0030
				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_WEB_GUI,eBACKUP_RESTORE_CHANGE_PROJECTOR);	//G100_Doulas_0034 Modify

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount <= eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED; ucCount++)		//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
					{
						utilDataMgr_Reload_Restore(ucCount);
					}
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;


		case eBACKUP_RESTORE_CHANGE_MAIN_BOARD:
			if(access(BACKUP_TAR_GZ,F_OK) == 0)	//check backup dir
			{
				if(access(BACKUP_PATH, F_OK) == 0)	//have dir
				{
                    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_PATH);
				}
				SYSTEM_CALL("tar -xvf %s -C %s/", BACKUP_TAR_GZ, MNT_PATH);
				//system("cd /mnt/;openssl aes-256-cbc -d -in Backup.bin -k your_key_passwd | tar zxf -");

				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in Lan.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in system.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);
				SYSTEM_CALL("cd %s/;openssl aes-256-cbc -d -in BackupRestoreCheck.bin -k passwd | tar zxf -", BACKUP_SCALER_PATH);

				if(utilDataMgr_Reload_Backup_Check(eDATA_BACKUP_RESTORE_CHECK_WEB,uiIndex) == eEXEC_CODE_PASS)
				{
					if((strcmp(m_sBackupRestoreCheck_Change_Main_Board[eBR_UCMODEL].cParaValue, m_sBackup_Restore_Check[eBR_UCMODEL].cParaValue) == 0) &&
					   (strcmp(m_sBackupRestoreCheck_Change_Main_Board[eBR_UCBACKUP_RESTORE_TYPE].cParaValue, m_sBackup_Restore_Check[eBR_UCBACKUP_RESTORE_TYPE].cParaValue) == 0))
					{
						//check backup ok
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}

				//LOG_MSG(db_ALWAYS,"OK3\r\n");
				//G100_Doulas_0034 Modify start
				SYSTEM_CALL("cp -R %s/Warping.conf %s/Warping.conf", BACKUP_SCALER_GUI_PATH, CONF_SCALER_GUI_PATH);
				SYSTEM_CALL("cp -R %s %s", BACKUP_SCALER_SOURCE_PATH, CONF_SCALER_PATH);
				SYSTEM_CALL("cp -R %s %s", BACKUP_WARP_PATH, MNT_PATH);
				SYSTEM_CALL("cp -R %s/AutoBrightness.conf %s/AutoBrightness.conf", BACKUP_SCALER_SYSTEM_PATH, CONF_SCALER_SYSTEM_PATH);
				SYSTEM_CALL("cp -R %s/Burnin.conf %s/Burnin.conf", BACKUP_SCALER_SYSTEM_PATH, CONF_SCALER_SYSTEM_PATH);
				SYSTEM_CALL("cp -R %s/SystemCal.conf %s/SystemCal.conf", BACKUP_SCALER_SYSTEM_PATH, CONF_SCALER_SYSTEM_PATH);
				SYSTEM_CALL("cp -R %s/SystemHours.conf %s/SystemHours.conf", BACKUP_SCALER_SYSTEM_PATH, CONF_SCALER_SYSTEM_PATH);
				//G100_Doulas_0034 Modify end

				utilDataMgr_Reload_Common_Gui(eDATA_BACKUP_RESTORE_COMMON_WEB_GUI,eBACKUP_RESTORE_CHANGE_MAIN_BOARD);			//G100_Doulas_0034
				utilDataMgr_Reload_ProjectorInfo(eDATA_BACKUP_RESTORE_PROJECTOR_INFO);

				utilDataMgr_Reload_Restore(eDATA_NODE_SYSTEMCAL);							//G100_Doulas_0034
				utilDataMgr_Reload_Restore(eDATA_NODE_SYSTEMHOURS);
				utilDataMgr_Reload_Restore(eDATA_NODE_BURNIN);
				//utilDataMgr_Reload_Restore(eDATA_NODE_STARTUP);					//PIN
				utilDataMgr_Reload_Restore(eDATA_NODE_AUTOBRIGHTNESS);

				for(ucCount = eDATA_NODE_HDMI1_COMMON; ucCount <= eDATA_NODE_HDBASET_HSG_USER_2D_HIGH_SPEED; ucCount++)		//G100_Doulas_0034 Modify//G100_Doulas_0030 Modify
				{
					if((ucCount < eDATA_NODE_WAP_CALIBRATION_TAG) ||
					   (ucCount > eDATA_NODE_WAP_2D_HIGH_SPEED_PWM))
					{
						utilDataMgr_Reload_Restore(ucCount);
					}
				}
				ucResult = eEXEC_CODE_PASS;
			}
			break;
	}

    return ucResult;
}

INT8 utilDataMgr_RangeCheck(UINT16 uiDataCode, INT32 iValue)		//G100_Doulas_0004
{
    eEXEC_CODE eResult = eEXEC_CODE_FAIL;

    if(utilDataMapping_CMValueRangeCheck(uiDataCode, iValue) == DATA_RANGE_CHECK_PASS)
    {
        eResult = eEXEC_CODE_PASS;
    }

	//LOG_MSG(db_ALWAYS, "\r\n Data code %d RangeCheck fail, (%d,%d)(%d)\r\n" ,uiDataCode,iMax, iMin, iValue);
    return eResult;
}

void utilDataMgr_EEPROM_RangeCheck(sEEPROM_SETTINGS *psEEP,sEEPROM_SETTINGS *psEEP_DEF)		//G100_Doulas_0004
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        UINT16 iCount = 0, iCount2 = 0, uiNode = 0;
        sPARA_FORMAT *psPara;
        //System Cal
        //psEEP->sADC_cal_values.uiRGBOffset[0]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_0].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset[0]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_0].cParaValue);
        //psEEP->sADC_cal_values.uiRGBOffset2[0]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset2[0]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_0].cParaValue);
        //psEEP->sADC_cal_values.uiRGBOffset[1]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_1].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset[1]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_1].cParaValue);
        //psEEP->sADC_cal_values.uiRGBOffset2[1]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset2[1]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_1].cParaValue);
        //psEEP->sADC_cal_values.uiRGBOffset[2]   = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET_2].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset[2]   = (UINT16)atol(m_sSystemCal[eSC_UIYUVOFFSET_2].cParaValue);
        //psEEP->sADC_cal_values.uiRGBOffset2[2]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue);
        //psEEP->sADC_cal_values.uiYUVOffset2[2]  = (UINT16)atol(m_sSystemCal[eSC_UIRGBOFFSET2_2].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain[0]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_0].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain[1]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_1].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain[2]     = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN_2].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain[0]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_0].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain[1]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_1].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain[2]     = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN_2].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain2[0]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_0].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain2[1]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_1].cParaValue);
        //psEEP->sADC_cal_values.uiRGBGain2[2]    = (UINT16)atol(m_sSystemCal[eSC_UIRGBGAIN2_2].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain2[0]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_0].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain2[1]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_1].cParaValue);
        //psEEP->sADC_cal_values.uiYUVGain2[2]    = (UINT16)atol(m_sSystemCal[eSC_UIYUVGAIN2_2].cParaValue);

        //Burnin
        //psEEP->sBurin_Information.ucBurnInEnable    = (UINT8)atol(m_sBurnin[eBI_URNINENABLE].cParaValue);
        //psEEP->sBurin_Information.ucLampOn          = (UINT8)atol(m_sBurnin[eBI_UCLAMPON].cParaValue);
        //psEEP->sBurin_Information.ucLampOff         = (UINT8)atol(m_sBurnin[eBI_UCLAMPOFF].cParaValue);
        //psEEP->sBurin_Information.uiBurnInCycle     = (UINT16)atol(m_sBurnin[eBI_UIBURNINCYCLE].cParaValue);
        //psEEP->sBurin_Information.ucBurnInMode      = (UINT8)atol(m_sBurnin[eBI_UCBURNINMODE].cParaValue);
        //psEEP->sBurin_Information.ucBurnInAlwaysOn  = (UINT8)atol(m_sBurnin[eBI_UCBURNINALWAYSON].cParaValue);
		if(utilDataMgr_RangeCheck(edcBURNIN_ENABLE,psEEP->sBurin_Information.ucBurnInEnable) == eEXEC_CODE_FAIL)
			psEEP->sBurin_Information.ucBurnInEnable = psEEP_DEF->sBurin_Information.ucBurnInEnable;
		if(utilDataMgr_RangeCheck(edcBURNIN_ON,psEEP->sBurin_Information.ucLampOn) == eEXEC_CODE_FAIL)
			psEEP->sBurin_Information.ucLampOn = psEEP_DEF->sBurin_Information.ucLampOn;
		if(utilDataMgr_RangeCheck(edcBURNIN_OFF,psEEP->sBurin_Information.ucLampOff) == eEXEC_CODE_FAIL)
			psEEP->sBurin_Information.ucLampOff = psEEP_DEF->sBurin_Information.ucLampOff;
		if(utilDataMgr_RangeCheck(edcBURNIN_CYCLE,psEEP->sBurin_Information.uiBurnInCycle) == eEXEC_CODE_FAIL)
			psEEP->sBurin_Information.uiBurnInCycle = psEEP_DEF->sBurin_Information.uiBurnInCycle;
		//G100_Doulas_0093 Modify start
		if(utilDataMgr_RangeCheck(edcADV_WARP_CONTROL,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl) == eEXEC_CODE_FAIL)						//G100_Doulas_0027
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpControl;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_POINTS,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints;
		if(utilDataMgr_RangeCheck(edcADV_WARP_INNER,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpInner;
		if(utilDataMgr_RangeCheck(edcADV_WARP_SHARPNESS,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_COLOR,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_BACKGROUND,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_OVERLAP_GRID_NUMBER,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_GAMMA,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_LEFT,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_RIGHT,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_TOP,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_BOTTOM,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom;
		//G100_Doulas_0093 end


        //sLayoutVersion
        //psEEP->sLayoutVersion.ucSubminor    = (UINT8)atol(m_sProjectorInfo[ePI_UCSUBMINOR].cParaValue);
        //psEEP->sLayoutVersion.ucMinor       = (UINT8)atol(m_sProjectorInfo[ePI_UCMINOR].cParaValue);
        //psEEP->sLayoutVersion.ucMajor       = (UINT8)atol(m_sProjectorInfo[ePI_UCMAJOR].cParaValue);

		//m_sAutoBrightness   	//G100_Doulas_0010 Add
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_Y].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_R].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_B].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_BLD_G].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[4]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_Y].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[5]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_R].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[6]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_B].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[7]       = (UINT16)atol(m_sAutoBrightness[eAB_UIINTENSITYPWM_RLD_G].cParaValue);

		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_Y].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_R].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_B].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_BLD_G].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_Y].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_R].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_B].cParaValue);
		//psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORINTENSITY_RLD_G].cParaValue);

		//psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_Y].cParaValue);		//G100_Doulas_0023 Add
		//psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_R].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_B].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORFULL_DYNAMIC_RLD_G].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_Y].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_R].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_B].cParaValue);
		//psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTSENSORECO_DYNAMIC_RLD_G].cParaValue);
		//psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_Y].cParaValue);
		//psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_R].cParaValue);
		//psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_B].cParaValue);
		//psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTFULL_PWM_DYNAMIC_RLD_G].cParaValue);
		//psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_Y].cParaValue);
		//psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_R].cParaValue);
		//psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_B].cParaValue);
		//psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G]       = (UINT16)atol(m_sAutoBrightness[eAB_UILIGHTECO_PWM_DYNAMIC_RLD_G].cParaValue);

		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_Y];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_R];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_B];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[eLD_SEQ_G];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[4] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[4] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[4];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[5] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[5] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[5];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[6] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[6] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[6];
		if(psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[7] > DDP_PWM_MAX_VALUE)
			psEEP->sUserSystemSetting.sLightSetting.uiIntensityPWM[7] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiIntensityPWM[7];

		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_Y];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_R];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_B];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_BLD[eLD_SEQ_G];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_Y];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_R];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_B];
		if(psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G] = psEEP_DEF->sUserSystemSetting.sLightSetting.uiLightSensorIntensity_RLD[eLD_SEQ_G];

		//G100_Doulas_0023 Add
		if(psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y] = psEEP_DEF->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_Y];
		if(psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R] = psEEP_DEF->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_R];
		if(psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B] = psEEP_DEF->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_B];
		if(psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G] = psEEP_DEF->sSystemDefault.uiLightSensorFull_Dynamic_RLD[eLD_SEQ_G];
		if(psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y] = psEEP_DEF->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_Y];
		if(psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R] = psEEP_DEF->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_R];
		if(psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B] = psEEP_DEF->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_B];
		if(psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G] = psEEP_DEF->sSystemDefault.uiLightSensorEco_Dynamic_RLD[eLD_SEQ_G];

		if(psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y] = psEEP_DEF->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_Y];
		if(psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R] = psEEP_DEF->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_R];
		if(psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B] = psEEP_DEF->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_B];
		if(psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G] = psEEP_DEF->sSystemDefault.uiLightFull_PWM_Dynamic_RLD[eLD_SEQ_G];
		if(psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y] = psEEP_DEF->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_Y];
		if(psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R] = psEEP_DEF->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_R];
		if(psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B] = psEEP_DEF->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_B];
		if(psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G] > ABC_LIGHT_SENSOR_MAXIMUM)
			psEEP->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G] = psEEP_DEF->sSystemDefault.uiLightEco_PWM_Dynamic_RLD[eLD_SEQ_G];

        //System Default
        //sprintf(psEEP->sSystemDefault.ucSerialNumber, "%s\0", m_sProjectorInfo[ePI_UCSERIALNUMBER].cParaValue);
        //psEEP->sSystemDefault.ucFirstStartupFlag    =   (UINT8)atol(m_sStartup[eSU_UCFIRSTSTARTUPFLAG].cParaValue);
        //psEEP->sSystemDefault.ucPINProtect          =   (UINT8)atol(m_sStartup[eSU_UCPINPROTECT].cParaValue);
		if(utilDataMgr_RangeCheck(edcPIN_PROTECT,psEEP->sSystemDefault.ucPINProtect) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.ucPINProtect = psEEP_DEF->sSystemDefault.ucPINProtect;

        //strncpy(&psEEP->sSystemDefault.ucPassWord[0], m_sStartup[eSU_UCPASSWORD_0].cParaValue, 1);
        //strncpy(&psEEP->sSystemDefault.ucPassWord[1], m_sStartup[eSU_UCPASSWORD_1].cParaValue, 1);
        //strncpy(&psEEP->sSystemDefault.ucPassWord[2], m_sStartup[eSU_UCPASSWORD_2].cParaValue, 1);
        //strncpy(&psEEP->sSystemDefault.ucPassWord[3], m_sStartup[eSU_UCPASSWORD_3].cParaValue, 1);
        //strncpy(&psEEP->sSystemDefault.ucPassWord[4], m_sStartup[eSU_UCPASSWORD_4].cParaValue, 1);
		if ((psEEP->sSystemDefault.ucPassWord[0] < '0') || (psEEP->sSystemDefault.ucPassWord[0] > '9'))
			psEEP->sSystemDefault.ucPassWord[0] = psEEP_DEF->sSystemDefault.ucPassWord[0];
		if ((psEEP->sSystemDefault.ucPassWord[1] < '0') || (psEEP->sSystemDefault.ucPassWord[1] > '9'))
			psEEP->sSystemDefault.ucPassWord[1] = psEEP_DEF->sSystemDefault.ucPassWord[1];
		if ((psEEP->sSystemDefault.ucPassWord[2] < '0') || (psEEP->sSystemDefault.ucPassWord[2] > '9'))
			psEEP->sSystemDefault.ucPassWord[2] = psEEP_DEF->sSystemDefault.ucPassWord[2];
		if ((psEEP->sSystemDefault.ucPassWord[3] < '0') || (psEEP->sSystemDefault.ucPassWord[3] > '9'))
			psEEP->sSystemDefault.ucPassWord[3] = psEEP_DEF->sSystemDefault.ucPassWord[3];
		if ((psEEP->sSystemDefault.ucPassWord[4] < '0') || (psEEP->sSystemDefault.ucPassWord[4] > '9'))
			psEEP->sSystemDefault.ucPassWord[4] = psEEP_DEF->sSystemDefault.ucPassWord[4];

		if(utilDataMgr_RangeCheck(edcREGION_SETTIG,psEEP->sSystemDefault.ucRegion) == eEXEC_CODE_FAIL)		//A65_OPTOMA_Doulas_0027
			psEEP->sSystemDefault.ucRegion = psEEP_DEF->sSystemDefault.ucRegion;
		if(utilDataMgr_RangeCheck(edcCUSTOMER_SPLASH,psEEP->sSystemDefault.ucDefaultLogo) == eEXEC_CODE_FAIL)		//A65_OPTOMA_Doulas_0027
			psEEP->sSystemDefault.ucDefaultLogo = psEEP_DEF->sSystemDefault.ucDefaultLogo;

        //psEEP->sSystemDefault.uiFWIndex[0] = (UINT16)atol(m_sSystemCal[eSC_UIFWINDEX_0].cParaValue);
        //psEEP->sSystemDefault.uiFWIndex[1] = (UINT16)atol(m_sSystemCal[eSC_UIFWINDEX_1].cParaValue);
        //psEEP->sSystemDefault.uiPWIndex[0] = (UINT16)atol(m_sSystemCal[eSC_UIPWINDEX_0].cParaValue);
        //psEEP->sSystemDefault.uiPWIndex[1] = (UINT16)atol(m_sSystemCal[eSC_UIPWINDEX_1].cParaValue);
		if(utilDataMgr_RangeCheck(edcFILTER_WHEEL_INDEX,psEEP->sSystemDefault.uiFWIndex[0]) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.uiFWIndex[0] = psEEP_DEF->sSystemDefault.uiFWIndex[1];
		if(utilDataMgr_RangeCheck(edcFILTER_WHEEL_INDEX,psEEP->sSystemDefault.uiFWIndex[0]) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.uiFWIndex[1] = psEEP_DEF->sSystemDefault.uiFWIndex[1];
		if(utilDataMgr_RangeCheck(edcPHOSPHOR_WHEEL_INDEX,psEEP->sSystemDefault.uiPWIndex[0]) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.uiPWIndex[0] = psEEP_DEF->sSystemDefault.uiPWIndex[0];
		if(utilDataMgr_RangeCheck(edcPHOSPHOR_WHEEL_INDEX,psEEP->sSystemDefault.uiPWIndex[1]) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.uiPWIndex[1] = psEEP_DEF->sSystemDefault.uiPWIndex[1];


        //psEEP->sSystemDefault.ulTotalProjectorMinute = (UINT32)atol(m_sSystemHours[eSH_ULTOTALPROJECTORMINUTE].cParaValue);
		if(utilDataMgr_RangeCheck(edcLAMP_PERIOD,psEEP->sSystemDefault.ulTotalProjectorMinute) == eEXEC_CODE_FAIL)
		{
			psEEP->sSystemDefault.ulTotalProjectorMinute = psEEP_DEF->sSystemDefault.ulTotalProjectorMinute;
		}

		if(utilDataMgr_RangeCheck(edcLD_HOURS,psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_BLD]) == eEXEC_CODE_FAIL)
		{
			psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_BLD] = psEEP_DEF->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_BLD];
		}
		if(utilDataMgr_RangeCheck(edcLD_HOURS,psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_RLD]) == eEXEC_CODE_FAIL)
		{
			psEEP->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_RLD] = psEEP_DEF->sSystemDefault.ulLightSourceMinute[eTIMER_RECORD_RLD];
		}

		if(utilDataMgr_RangeCheck(edcCONSTANT_POWER_OFFSET,psEEP->sSystemDefault.ucPOWER_OFFSET) == eEXEC_CODE_FAIL)
        {
			psEEP->sSystemDefault.ucPOWER_OFFSET = psEEP_DEF->sSystemDefault.ucPOWER_OFFSET;
        }

		if(utilDataMgr_RangeCheck(edcCOLOR_OFFSET,psEEP->sSystemDefault.ucCOLOR_OFFSET) == eEXEC_CODE_FAIL)
        {
			psEEP->sSystemDefault.ucCOLOR_OFFSET = psEEP_DEF->sSystemDefault.ucCOLOR_OFFSET;
        }

        //psEEP->sSystemDefault.ucLensType  = (UINT8)atol(m_sCommonGui[eCG_UCLENSTYPE].cParaValue);
        if(utilDataMgr_RangeCheck(edcLENS_TYPE,psEEP->sSystemDefault.ucLensType) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.ucLensType = psEEP_DEF->sSystemDefault.ucLensType;

        //psEEP->sSystemDefault.ulDbMask  = (UINT64)atoll(m_sCommonGui[eCG_ULDBMASK].cParaValue);


        //psEEP->sSystemDefault.ucPanel = (UINT8)atol(m_sCommonGui[eCG_UCPANEL].cParaValue);

        //psEEP->sSystemDefault.ucABP_CalibrateFlag = (UINT8)atol(m_sSystemCal[eSC_UCABP_CALIBRATEFLAG].cParaValue);
		if(utilDataMgr_RangeCheck(edcLIGHT_SENSOR_CALIBRATION_VALUE,psEEP->sSystemDefault.ucABP_CalibrateFlag) == eEXEC_CODE_FAIL)
			psEEP->sSystemDefault.ucABP_CalibrateFlag = psEEP_DEF->sSystemDefault.ucABP_CalibrateFlag;

        //psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_Y]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_R]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_B]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_BLD[eLD_SEQ_G]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_BLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_Y]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_R]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_B]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_BLD[eLD_SEQ_G]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_BLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_Y]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_R]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_B]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_BLD[eLD_SEQ_G]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_BLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_B]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_BLD[eLD_SEQ_G]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_BLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_Y]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_R]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_B]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorFull_RLD[eLD_SEQ_G]  = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORFULL_RLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_Y]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_R]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_B]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightSensorEco_RLD[eLD_SEQ_G]   = (UINT16)atol(m_sSystemCal[eSC_UILIGHTSENSORECO_RLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_Y]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_R]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_B]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightFull_PWM_RLD[eLD_SEQ_G]    = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMFULL_RLD_G].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_Y]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_Y].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_R]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_R].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_B]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_B].cParaValue);
        //psEEP->sSystemDefault.uiLightEco_PWM_RLD[eLD_SEQ_G]     = (UINT16)atol(m_sSystemCal[eSC_UILIGHTPWMECO_RLD_G].cParaValue);

        //Gui
        //psEEP->sUserSystemSetting.sLightSetting.ucPowerMode             = (UINT8)atol(m_sCommonGui[eCG_UCPOWERMODE].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucWaveformGain          = (UINT8)atol(m_sCommonGui[eCG_UCWAVEFORMGAIN].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucIRWaveformGain        = (UINT8)atol(m_sCommonGui[eCG_UCIRWAVEFORMGAIN].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucIRMode_WaveformGain   = (UINT8)atol(m_sCommonGui[eCG_UCIRMODE_WAVEFORMGAIN].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucIRMode_IRWaveformGain = (UINT8)atol(m_sCommonGui[eCG_UCIRMODE_IRWAVEFORMGAIN].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucIRLD                  = (UINT8)atol(m_sCommonGui[eCG_UCIRLD].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucIRBLD                 = (UINT8)atol(m_sCommonGui[eCG_UCIRBLD].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucLightCalibrationMode  = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTCALIBRATIONMODE].cParaValue);
        //psEEP->sUserSystemSetting.sLightSetting.ucConstantBrightness    = (UINT8)atol(m_sCommonGui[eCG_CONSTANT_BRIGHTNESS].cParaValue);		//G100_Doulas_0008
		if(utilDataMgr_RangeCheck(edcPOWER_MODE,psEEP->sUserSystemSetting.sLightSetting.ucPowerMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sLightSetting.ucPowerMode = psEEP_DEF->sUserSystemSetting.sLightSetting.ucPowerMode;
		if(utilDataMgr_RangeCheck(edcCONSTANT_POWER_NUMBER,psEEP->sUserSystemSetting.sLightSetting.ucWaveformGain) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sLightSetting.ucWaveformGain = psEEP_DEF->sUserSystemSetting.sLightSetting.ucWaveformGain;
		if(utilDataMgr_RangeCheck(edcLIGHT_SENSOR_CALIBRATION,psEEP->sUserSystemSetting.sLightSetting.ucLightCalibrationMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sLightSetting.ucLightCalibrationMode = psEEP_DEF->sUserSystemSetting.sLightSetting.ucLightCalibrationMode;
		if(utilDataMgr_RangeCheck(edcCONSTANT_BRIGHTNESS,psEEP->sUserSystemSetting.sLightSetting.ucConstantBrightness) == eEXEC_CODE_FAIL)		//G100_Doulas_0008
			psEEP->sUserSystemSetting.sLightSetting.ucConstantBrightness = psEEP_DEF->sUserSystemSetting.sLightSetting.ucConstantBrightness;

        //psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLocation       = (UINT8)atol(m_sCommonGui[eCG_UCMENULOCATION].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTranslucency    = (UINT8)atol(m_sCommonGui[eCG_UCOSDTRANSLUCENCY].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTimeout         = (UINT8)atol(m_sCommonGui[eCG_UCOSDTIMEOUT].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucShowMessages       = (UINT8)atol(m_sCommonGui[eCG_UCSHOWMESSAGES].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX        = (UINT8)atol(m_sCommonGui[eCG_UCMENUOFFSETX].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY        = (UINT8)atol(m_sCommonGui[eCG_UCMENUOFFSETY].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLockout        = (UINT8)atol(m_sCommonGui[eCG_UCMENULOCKOUT].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucMenuTransparency   = (UINT8)atol(m_sCommonGui[eCG_UCMENUTRANSPARENCY].cParaValue);
        //psEEP->sUserSystemSetting.sOSD_Setting.ucSearchScreen       = (UINT8)atol(m_sCommonGui[eCG_UCSEARCHSCREEN].cParaValue);
		if(utilDataMgr_RangeCheck(edcMENU_LOCATION,psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLocation) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucMenuLocation = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucMenuLocation;
		if(utilDataMgr_RangeCheck(edcMENU_TIME_OUT,psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTimeout) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucOSDTimeout = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucOSDTimeout;
		if(utilDataMgr_RangeCheck(edcSHOW_MESSAGES,psEEP->sUserSystemSetting.sOSD_Setting.ucShowMessages) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucShowMessages = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucShowMessages;
		if(utilDataMgr_RangeCheck(edcMEMU_HORZ_OFFSET,psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucMenuOffsetX;
		if(utilDataMgr_RangeCheck(edcMEMU_VERT_OFFSET,psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucMenuOffsetY;
		if(utilDataMgr_RangeCheck(edcMENU_TRANSPARENCY,psEEP->sUserSystemSetting.sOSD_Setting.ucMenuTransparency) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sOSD_Setting.ucMenuTransparency = psEEP_DEF->sUserSystemSetting.sOSD_Setting.ucMenuTransparency;

        //psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable   = (UINT8)atol(m_sCommonGui[eCG_UCHSGADJUSTMENTENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern= (UINT8)atol(m_sCommonGui[eCG_UCHSGADJUSTMENTAUTOTESTPATTERN].cParaValue);
		if(utilDataMgr_RangeCheck(edcHSG_ENABLE,psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHSGAdjustmentEnable;
		if(utilDataMgr_RangeCheck(edcHSG_AUTO_TEST_PATTERN,psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern;
        psEEP->sUserSystemSetting.sImageSetting.ucHSGSelected = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHSGSelected;

        //psEEP->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch   = (UINT8)atol(m_sCommonGui[eCG_UCBLANKONSIGNALSWITCH].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucSyncThreshold         = (UINT8)atol(m_sCommonGui[eCG_UCSYNCTHRESHOLD].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucContrastEnhancement   = (UINT8)atol(m_sCommonGui[eCG_UCCONTRASTENHANCEMENT].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucFilm                  = (UINT8)atol(m_sCommonGui[eCG_UCFILM].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucWallColor             = (UINT8)atol(m_sCommonGui[eCG_UCWALLCOLOR].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucImageFreeze           = (UINT8)atol(m_sCommonGui[eCG_UCIMAGEFREEZE].cParaValue);
		if(utilDataMgr_RangeCheck(edcBLANK_SIGNAL_SWITCH,psEEP->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch = psEEP_DEF->sUserSystemSetting.sImageSetting.ucBlankonSignalSwitch;
		if(utilDataMgr_RangeCheck(edcSYNC_THRESHOLD,psEEP->sUserSystemSetting.sImageSetting.ucSyncThreshold) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucSyncThreshold = psEEP_DEF->sUserSystemSetting.sImageSetting.ucSyncThreshold;
		if(utilDataMgr_RangeCheck(edcCONTRAST_ENHANCEMENT,psEEP->sUserSystemSetting.sImageSetting.ucContrastEnhancement) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucContrastEnhancement = psEEP_DEF->sUserSystemSetting.sImageSetting.ucContrastEnhancement;
		if(utilDataMgr_RangeCheck(edcDETECT_FILM,psEEP->sUserSystemSetting.sImageSetting.ucFilm) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucFilm = psEEP_DEF->sUserSystemSetting.sImageSetting.ucFilm;
		if(utilDataMgr_RangeCheck(edcWALL_COLOR,psEEP->sUserSystemSetting.sImageSetting.ucWallColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucWallColor = psEEP_DEF->sUserSystemSetting.sImageSetting.ucWallColor;
		if(utilDataMgr_RangeCheck(edcIMAGE_FREEZE,psEEP->sUserSystemSetting.sImageSetting.ucImageFreeze) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucImageFreeze = psEEP_DEF->sUserSystemSetting.sImageSetting.ucImageFreeze;

        //psEEP->sUserSystemSetting.sImageSetting.ucCeilingMount          = (UINT8)atol(m_sCommonGui[eCG_UCCEILINGMOUNT].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucRearProject           = (UINT8)atol(m_sCommonGui[eCG_UCREARPROJECT].cParaValue);
		if(utilDataMgr_RangeCheck(edcCEILING_MOUNT,psEEP->sUserSystemSetting.sImageSetting.ucCeilingMount) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucCeilingMount = psEEP_DEF->sUserSystemSetting.sImageSetting.ucCeilingMount;
		if(utilDataMgr_RangeCheck(edcREAR_PROJECTION,psEEP->sUserSystemSetting.sImageSetting.ucRearProject) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucRearProject = psEEP_DEF->sUserSystemSetting.sImageSetting.ucRearProject;

		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D];
		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D];
		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120];
        if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER];
        if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER];

		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_MANDATORY_3D_P];
		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_4K3D_P];
		if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_120_P];
        if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_FS_OTHER_P];
        if(utilDataMgr_RangeCheck(edcFRAME_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DFRAME_DELAY_TIMING[e3DFS_OTHER_P];


		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D];
		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D];
		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120];
        if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER];
        if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER];

		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_MANDATORY_3D_P];
		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_4K3D_P];
		if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_120_P];
        if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_FS_OTHER_P];
        if(utilDataMgr_RangeCheck(edc3D_SYNC_DELAY,psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER_P]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER_P] = psEEP_DEF->sUserSystemSetting.sImageSetting.ui3DSYNC_DELAY_TIMING[e3DFS_OTHER_P];


        //psEEP->sUserSystemSetting.sImageSetting.ucLightsOutTimer        = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTSOUTTIMER].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel  = (UINT8)atol(m_sCommonGui[eCG_UCLIGHTSOUTSIGNALLEVEL].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucCompatible_4K         = (UINT8)atol(m_sCommonGui[eCG_UCCOMPATIBLE_4K].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1           = (UINT8)atol(m_sCommonGui[eCG_UCHDMI_EDID_1].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2           = (UINT8)atol(m_sCommonGui[eCG_UCHDMI_EDID_2].cParaValue);

        //psEEP->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID           = (UINT8)atol(m_sCommonGui[eCG_UCHDBaseT_EDID].cParaValue); //G100_Steven_0005
        //psEEP->sUserSystemSetting.sImageSetting.ucHDMI_OUT              = (UINT8)atol(m_sCommonGui[eCG_UCHDMI_OUT].cParaValue);			//G100_Doulas_0057
        if(utilDataMgr_RangeCheck(edcLIGHTS_OUT_TIMER_X05,psEEP->sUserSystemSetting.sImageSetting.ucLightsOutTimer) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucLightsOutTimer = psEEP_DEF->sUserSystemSetting.sImageSetting.ucLightsOutTimer;
		if(utilDataMgr_RangeCheck(edcLIGHTS_OUT_SIGNAL_LEVEL,psEEP->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel = psEEP_DEF->sUserSystemSetting.sImageSetting.ucLightsOutSignalLevel;
		if(utilDataMgr_RangeCheck(edcLIGHTS_ON_THRESHOLD,psEEP->sUserSystemSetting.sImageSetting.ucLightsOnThreshold) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucLightsOnThreshold = psEEP_DEF->sUserSystemSetting.sImageSetting.ucLightsOnThreshold;	//A70Gen2_Doulas_0044
		if(utilDataMgr_RangeCheck(edcCOMPATIBLE_4K,psEEP->sUserSystemSetting.sImageSetting.ucCompatible_4K) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucCompatible_4K = psEEP_DEF->sUserSystemSetting.sImageSetting.ucCompatible_4K;
		if(utilDataMgr_RangeCheck(edcHDMI_EDID_1,psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1 = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDMI_EDID_1;
		if(utilDataMgr_RangeCheck(edcHDMI_EDID_2,psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2 = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDMI_EDID_2;
		if(utilDataMgr_RangeCheck(edcHDBASET_EDID,psEEP->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDBaseT_EDID;
		if(utilDataMgr_RangeCheck(edcHDMI_OUT,psEEP->sUserSystemSetting.sImageSetting.ucHDMI_OUT) == eEXEC_CODE_FAIL)			//G100_Doulas_0057
			psEEP->sUserSystemSetting.sImageSetting.ucHDMI_OUT = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDMI_OUT;

	    if(utilDataMgr_RangeCheck(edcHSG_AUTO_TEST_PATTERN_WHITE,psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern_2) == eEXEC_CODE_FAIL)	//G100_Coda_00109
			psEEP->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern_2 = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHSGAdjustmentAutoTestPattern_2;

        //psEEP->sUserSystemSetting.sImageSetting.ucHDRLevel              = (UINT8)atol(m_sCommonGui[eCG_UCHDRLEVEL].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucHDREnable             = (UINT8)atol(m_sCommonGui[eCG_UCHDRENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucCW_Speed              = (UINT8)atol(m_sCommonGui[eCG_UCCW_SPEED].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucDBSpeed               = (UINT8)atol(m_sCommonGui[eCG_UCDBSPEED].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucDBStrength            = (UINT8)atol(m_sCommonGui[eCG_UCDBSTRENGTH].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucDBLightLevel          = (UINT8)atol(m_sCommonGui[eCG_UCDBLIGHTLEVEL].cParaValue);
        //psEEP->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable     = (UINT8)atol(m_sCommonGui[eCG_UCDBREALBLACKENABLE].cParaValue);
		if(utilDataMgr_RangeCheck(edcHDR_LEVEL,psEEP->sUserSystemSetting.sImageSetting.ucHDRLevel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHDRLevel = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDRLevel;
		if(utilDataMgr_RangeCheck(edcHDR_AUTOENABLE,psEEP->sUserSystemSetting.sImageSetting.ucHDREnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucHDREnable = psEEP_DEF->sUserSystemSetting.sImageSetting.ucHDREnable;
		if(utilDataMgr_RangeCheck(edcCOLOR_WHEEL_SPEED,psEEP->sUserSystemSetting.sImageSetting.ucCW_Speed) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucCW_Speed = psEEP_DEF->sUserSystemSetting.sImageSetting.ucCW_Speed;
		if(utilDataMgr_RangeCheck(edcDB_SPEED,psEEP->sUserSystemSetting.sImageSetting.ucDBSpeed) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucDBSpeed = psEEP_DEF->sUserSystemSetting.sImageSetting.ucDBSpeed;
        if(utilDataMgr_RangeCheck(edcDB_SPEED,psEEP->sUserSystemSetting.sImageSetting.ucDBSpeedControl) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucDBSpeedControl = psEEP_DEF->sUserSystemSetting.sImageSetting.ucDBSpeedControl;
		if(utilDataMgr_RangeCheck(edcDB_STRENGTH,psEEP->sUserSystemSetting.sImageSetting.ucDBStrength) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucDBStrength = psEEP_DEF->sUserSystemSetting.sImageSetting.ucDBStrength;
		if(utilDataMgr_RangeCheck(edcDB_LIGHT_LEVEL,psEEP->sUserSystemSetting.sImageSetting.ucDBLightLevel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sImageSetting.ucDBLightLevel = psEEP_DEF->sUserSystemSetting.sImageSetting.ucDBLightLevel;
		//if(utilDataMgr_RangeCheck(edcDB_REAL_BLACK_ENABLE,psEEP->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable = psEEP_DEF->sUserSystemSetting.sImageSetting.ucDBRealBlackEnable;

		//warping
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpMode                   = (UINT8)atol(m_sWarping[eWI_UCWARPMODE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone           = (UINT8)atol(m_sWarping[eWI_UCWARPHORZKEYSTONE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone           = (UINT8)atol(m_sWarping[eWI_UCWARPVERTKEYSTONE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion         = (UINT8)atol(m_sWarping[eWI_UCWARPHORZPINCUSHION].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion         = (UINT8)atol(m_sWarping[eWI_UCWARPVERTPINCUSHION].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel       = (UINT8)atol(m_sWarping[eWI_UCWARPPINCUSHIONBARREL].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucGeometryPCMode             = (UINT8)atol(m_sWarping[eWI_UCGEOMETRYPCMODE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz         = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPLEFTHORZ].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert         = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPLEFTVERT].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz        = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPRIGHTHORZ].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert        = (UINT16)atol(m_sWarping[eWI_UI4CORNERTOPRIGHTVERT].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz      = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMLEFTHORZ].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert      = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMLEFTVERT].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz     = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTHORZ].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert     = (UINT16)atol(m_sWarping[eWI_UI4CORNERBOTTOMRIGHTVERT].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter             = (UINT8)atol(m_sWarping[eWI_UCWARPAUTOFILTER].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterH                = (UINT8)atol(m_sWarping[eWI_UCWARPFILTERH].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterV                = (UINT8)atol(m_sWarping[eWI_UCWARPFILTERV].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucMovePitchMode              = (UINT8)atol(m_sWarping[eWI_UCMOVEPITCHMODE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable          = (UINT8)atol(m_sWarping[eWI_UCBLENDINGTOPENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel      = (UINT16)atol(m_sWarping[eWI_UIBLENDINGTOPSTARTPIXEL].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth      = (UINT16)atol(m_sWarping[eWI_UIBLENDINGTOPPIXELWIDTH].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable       = (UINT8)atol(m_sWarping[eWI_UCBLENDINGBOTTOMENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel   = (UINT16)atol(m_sWarping[eWI_UIBLENDINGBOTTOMSTARTPIXEL].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth   = (UINT16)atol(m_sWarping[eWI_UIBLENDINGBOTTOMPIXELWIDTH].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable         = (UINT8)atol(m_sWarping[eWI_UCBLENDINGLEFTENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel     = (UINT16)atol(m_sWarping[eWI_UIBLENDINGLEFTSTARTPIXEL].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth     = (UINT16)atol(m_sWarping[eWI_UIBLENDINGLEFTPIXELWIDTH].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable        = (UINT8)atol(m_sWarping[eWI_UCBLENDINGRIGHTENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel    = (UINT16)atol(m_sWarping[eWI_UIBLENDINGRIGHTSTARTPIXEL].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth    = (UINT16)atol(m_sWarping[eWI_UIBLENDINGRIGHTPIXELWIDTH].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode         = (UINT8)atol(m_sWarping[eWI_UCAUTOADJUSTMENTMODE].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting        = (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLYSETTING].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting         = (UINT8)atol(m_sWarping[eWI_UCWARPINGSAVESETTING].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendingGamma              = (UINT8)atol(m_sWarping[eWI_UCBLENDINGGAMMA].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_0].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_0].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_0].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_0].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_1].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_1].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_1].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_1].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_2].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_2].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_2].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_2].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingApply= (UINT8)atol(m_sWarping[eWI_UCWARPINGAPPLY_3].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendApply  = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLY_3].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingName,  24, "%s", m_sWarping[eWI_UCWARPINGNAME_3].cParaValue);
        //snprintf(psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendingName, 24, "%s", m_sWarping[eWI_UCBLENDINGNAME_3].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendApplySetting          = (UINT8)atol(m_sWarping[eWI_UCBLENDAPPLYSETTING].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting           = (UINT8)atol(m_sWarping[eWI_UCBLENDSAVESETTING].cParaValue);
        //psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl           		= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_CONTROL].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDPOINTS].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner           		= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_INNER].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_SHARPNESS].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor           	= (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDCOLOR].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor         = (UINT8)atol(m_sWarping[eWI_UCADV_WARP_GRIDBACKGROUND].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber   = (UINT8)atol(m_sWarping[eWI_UCADV_BLEND_OVERLAP_GRIDNUMBER].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma           	= (UINT8)atol(m_sWarping[eWI_UCADV_BLEND_GAMMA].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft           		= (UINT8)atol(m_sWarping[eWI_UIADV_BLEND_LEFT].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight           	= (UINT8)atol(m_sWarping[eWI_UIADV_BLEND_RIGHT].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop           		= (UINT8)atol(m_sWarping[eWI_UIADV_BLEND_TOP].cParaValue);
		//psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom           	= (UINT8)atol(m_sWarping[eWI_UIADV_BLEND_BOTTOM].cParaValue);
		if(utilDataMgr_RangeCheck(edcWARP_MODE,psEEP->sUserSystemSetting.sWarpSetting.ucWarpMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpMode = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpMode;
		if(utilDataMgr_RangeCheck(edcHORIZONTAL_KEYSTONE,psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpHorzKeystone;
		if(utilDataMgr_RangeCheck(edcVERTICAL_KEYSTONE,psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpVertKeystone;
		if(utilDataMgr_RangeCheck(edcHORZ_PINCUSHION,psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpHorzPincushion;
		if(utilDataMgr_RangeCheck(edcVERT_PINCUSHION,psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpVertPincushion;
		//if(utilDataMgr_RangeCheck(edcVERTICAL_KEYSTONE,psEEP->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpPincushionBarrel;
		if(utilDataMgr_RangeCheck(edcPC_MODE,psEEP->sUserSystemSetting.sWarpSetting.ucGeometryPCMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucGeometryPCMode = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucGeometryPCMode;
		if(utilDataMgr_RangeCheck(edc4CORNER_TOP_LEFT_HORZ,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftHorz;
		if(utilDataMgr_RangeCheck(edc4CORNER_TOP_LEFT_VERT,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerTopLeftVert;
		if(utilDataMgr_RangeCheck(edc4CORNER_TOP_RIGHT_HORZ,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerTopRightHorz;
		if(utilDataMgr_RangeCheck(edc4CORNER_TOP_RIGHT_VERT,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerTopRightVert;
		if(utilDataMgr_RangeCheck(edc4CORNER_BOTTOM_LEFT_HORZ,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftHorz;
		if(utilDataMgr_RangeCheck(edc4CORNER_BOTTOM_LEFT_VERT,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerBottomLeftVert;
		if(utilDataMgr_RangeCheck(edc4CORNER_BOTTOM_RIGHT_HORZ,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightHorz;
		if(utilDataMgr_RangeCheck(edc4CORNER_BOTTOM_RIGHT_VERT,psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert = psEEP_DEF->sUserSystemSetting.sWarpSetting.ui4CornerBottomRightVert;

		if(utilDataMgr_RangeCheck(edcAUTO_WARP_FILTER,psEEP->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpAutoFilter;
		if(utilDataMgr_RangeCheck(edcMANUAL_WARP_HORZ_FILTER,psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterH) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterH = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpFilterH;
		if(utilDataMgr_RangeCheck(edcMANUAL_WARP_VERT_FILTER,psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterV) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpFilterV = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpFilterV;
		if(utilDataMgr_RangeCheck(edcWARP_MOVE_PITCH_MODE,psEEP->sUserSystemSetting.sWarpSetting.ucMovePitchMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucMovePitchMode = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucMovePitchMode;
		if(utilDataMgr_RangeCheck(edcBLENDING_TOP_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendingTopEnable;
		if(utilDataMgr_RangeCheck(edcBLENDING_TOP_START_PIXEL,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingTopStartPixel;
		if(utilDataMgr_RangeCheck(edcBLENDING_TOP_PIXEL_WIDTH,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingTopPixelWidth;
		if(utilDataMgr_RangeCheck(edcBLENDING_BOTTOM_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendingBottomEnable;
		if(utilDataMgr_RangeCheck(edcBLENDING_BOTTOM_START_PIXEL,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingBottomStartPixel;
		if(utilDataMgr_RangeCheck(edcBLENDING_BOTTOM_PIXEL_WIDTH,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingBottomPixelWidth;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendingLeftEnable;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_START_PIXEL,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingLeftStartPixel;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_PIXEL_WIDTH,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingLeftPixelWidth;
		if(utilDataMgr_RangeCheck(edcBLENDING_RIGHT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendingRightEnable;
		if(utilDataMgr_RangeCheck(edcBLENDING_RIGHT_START_PIXEL,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingRightStartPixel;
		if(utilDataMgr_RangeCheck(edcBLENDING_RIGHT_PIXEL_WIDTH,psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth = psEEP_DEF->sUserSystemSetting.sWarpSetting.uiBlendingRightPixelWidth;
		if(utilDataMgr_RangeCheck(edcAUTO_ADJUSTMENT_MODE,psEEP->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAutoAdjustmentMode;
		if(utilDataMgr_RangeCheck(edcWARP_MEMORY_APPLY,psEEP->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpingApplySetting;
		if(utilDataMgr_RangeCheck(edcWARP_MEMORY_SAVE,psEEP->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucWarpingSaveSetting;
		if(utilDataMgr_RangeCheck(edcBLENDING_GAMMA,psEEP->sUserSystemSetting.sWarpSetting.ucBlendingGamma) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendingGamma = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendingGamma;
		if(utilDataMgr_RangeCheck(edcWARP_TOGGLE,psEEP->sUserSystemSetting.sWarpSetting.ucGeometryEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucGeometryEnable = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucGeometryEnable;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucWarpingApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[1].ucBlendApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucWarpingApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[2].ucBlendApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucWarpingApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucWarpingApply;
		if(utilDataMgr_RangeCheck(edcBLENDING_LEFT_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.sWarpMemory[3].ucBlendApply = psEEP_DEF->sUserSystemSetting.sWarpSetting.sWarpMemory[0].ucBlendApply;
		if(utilDataMgr_RangeCheck(edcBLEND_MEMORY_APPLY,psEEP->sUserSystemSetting.sWarpSetting.ucBlendApplySetting) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendApplySetting = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendApplySetting;
		if(utilDataMgr_RangeCheck(edcBLEND_MEMORY_SAVE,psEEP->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucBlendSaveSetting;
		//G100_Doulas_0093 Modify start
		if(utilDataMgr_RangeCheck(edcADV_WARP_CONTROL,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl) == eEXEC_CODE_FAIL)						//G100_Doulas_0027
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpControl = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpControl;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_POINTS,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpGridPoints;
		if(utilDataMgr_RangeCheck(edcADV_WARP_INNER,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpInner;
		if(utilDataMgr_RangeCheck(edcADV_WARP_SHARPNESS,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpSharpness;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_COLOR,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpGridColor;
		if(utilDataMgr_RangeCheck(edcADV_WARP_GRID_BACKGROUND,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpBackgroundColor;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_OVERLAP_GRID_NUMBER,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingOverlapGridNumber;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_GAMMA,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingGamma;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_LEFT,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingLeft;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_RIGHT,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingRight;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_TOP,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingTop;
		if(utilDataMgr_RangeCheck(edcADV_BLEND_BOTTOM,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlendingBottom;
		//G100_Doulas_0093 end
		if(utilDataMgr_RangeCheck(edcADV_WARP_INNER,psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner_LastValue) == eEXEC_CODE_FAIL)    //G100_Tim_0055, add //A35G2_BRC_Casper_0051
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvWarpInner_LastValue= psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvWarpInner_LastValue;   //G100_Tim_0055, add

		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_AREA,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelArea) == eEXEC_CODE_FAIL)		//A65_OPTOMA_Doulas_0020
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelArea = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelArea;
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__TOP]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__TOP] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__TOP];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_ENABLE,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__BOTTOM]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__BOTTOM] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelEnable[BLACKLEVEL_AREA__BOTTOM];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_RED,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__TOP]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__TOP] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__TOP];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_RED,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__BOTTOM]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__BOTTOM] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelRed[BLACKLEVEL_AREA__BOTTOM];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_GREEN,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__TOP]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__TOP] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__TOP];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_GREEN,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__BOTTOM]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__BOTTOM] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelGreen[BLACKLEVEL_AREA__BOTTOM];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_BLUE,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__TOP]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__TOP] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__TOP];
		if(utilDataMgr_RangeCheck(edcADV_BLACK_LEVEL_BLUE,psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__BOTTOM]) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__BOTTOM] = psEEP_DEF->sUserSystemSetting.sWarpSetting.ucAdvBlackLevelBlue[BLACKLEVEL_AREA__BOTTOM];


        //psEEP->sUserSystemSetting.sCommonSetting.ucLanguage                 = (UINT8)atol(m_sCommonGui[eCG_UCLANGUAGE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucACPowerOn                = (UINT8)atol(m_sCommonGui[eCG_UCACPOWERON].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave         = (UINT8)atol(m_sCommonGui[eCG_UCSTANDBYPOWERSAVE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucProjectorAddress         = (UINT8)atol(m_sCommonGui[eCG_UCPROJECTORADDRESS].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucProjectorID              = (UINT8)atol(m_sCommonGui[eCG_UCPROJECTORID].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucKeypadBacklight          = (UINT8)atol(m_sCommonGui[eCG_UCKEYPADBACKLIGHT].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucStatusLED                = (UINT8)atol(m_sCommonGui[eCG_UCSTATUSLED].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucAutoOffTime              = (UINT8)atol(m_sCommonGui[eCG_UCAUTOOFFTIME].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucScreenSaveTime           = (UINT8)atol(m_sCommonGui[eCG_UCSCREENSAVETIME].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSleepTimer               = (UINT8)atol(m_sCommonGui[eCG_UCSLEEPTIMER].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucChangePIN                = (UINT8)atol(m_sCommonGui[eCG_UCCHANGEPIN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate       = (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTBAUDRATE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortEcho           = (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTECHO].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortPath           = (UINT8)atol(m_sCommonGui[eCG_UCSERIALPORTPATH].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Top            = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_TOP].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Front          = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_FRONT].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT        = (UINT8)atol(m_sCommonGui[eCG_UCIRCONTROL_HDBASET].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable            = (UINT8)atol(m_sCommonGui[eCG_UCHDBASETENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSysErrCode               = (UINT8)atol(m_sCommonGui[eCG_UCSYSERRCODE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.uc12VTrigge                = (UINT8)atol(m_sCommonGui[eCG_UC12VTRIGGE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLensAdjust               = (UINT8)atol(m_sCommonGui[eCG_UCLENSADJUST].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLensShift                = (UINT8)atol(m_sCommonGui[eCG_UCLENSSHIFT].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLensMemoryApply          = (UINT8)atol(m_sCommonGui[eCG_UCLENSMEMORYAPPLY].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLensMemorySave           = (UINT8)atol(m_sCommonGui[eCG_UCLENSMEMORYSAVE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucHighAltitude             = (UINT8)atol(m_sCommonGui[eCG_UCHIGHALTITUDE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern       = (UINT8)atol(m_sCommonGui[eCG_UCFACTORYTESTPATTERN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern   = (UINT8)atol(m_sCommonGui[eCG_UCSERVICEMENUTESTPATTERN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern = (UINT8)atol(m_sCommonGui[eCG_UCFACTORYMENUCUSTOMPATTERN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable      = (UINT8)atol(m_sCommonGui[eCG_UCSPLASHSTARTUPENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucActuatorSwitch           = (UINT8)atol(m_sCommonGui[eCG_UCACTUATORSWITCH].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucCoolingDown              = (UINT8)atol(m_sCommonGui[eCG_UCCOOLINGDOWN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucOSDTestPattern           = (UINT8)atol(m_sCommonGui[eCG_UCOSDTESTPATTERN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucUartSwitch               = (UINT8)atol(m_sCommonGui[eCG_UCUARTSWITCH].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave        = (UINT8)atol(m_sCommonGui[eCG_UCBACKUPRESTORESAVE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore     = (UINT8)atol(m_sCommonGui[eCG_UCBACKUPRESTORERESTORE].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLensDetection            = (UINT8)atol(m_sCommonGui[eCG_UCLENSDETECTION].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucLowLatency               = (UINT8)atol(m_sCommonGui[eCG_UCLOWLATENCY].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch         = (UINT8)atol(m_sCommonGui[eCG_BACKUP_INPUT_SWITCH].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput       = (UINT8)atol(m_sCommonGui[eCG_BACKUP_PRIMARY_INPUT].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput     = (UINT8)atol(m_sCommonGui[eCG_BACKUP_SECONDARY_INPUT].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucBackgroundColor          = (UINT8)atol(m_sCommonGui[eCG_BACKGROUND_COLOR].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucSignalPowerOn            = (UINT8)atol(m_sCommonGui[eCG_SIGNAL_POWERON].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin  = (UINT32)atol(m_sCommonGui[eCG_SECURITY_TOTALREMAINMIN].cParaValue);
        //psEEP->sUserSystemSetting.sCommonSetting.ucAutoSourceResync           = (UINT8)atol(m_sCommonGui[eCG_AUTO_SOURCE_RESYNC].cParaValue);	//G100_Doulas_0006
		if(utilDataMgr_RangeCheck(edcLANGUAGE,psEEP->sUserSystemSetting.sCommonSetting.ucLanguage) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLanguage = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLanguage;
		if(utilDataMgr_RangeCheck(edcAC_POWER_ON,psEEP->sUserSystemSetting.sCommonSetting.ucACPowerOn) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucACPowerOn = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucACPowerOn;
		if(utilDataMgr_RangeCheck(edcSTANDBY_MODE,psEEP->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucStandbyPowerSave;
		if(utilDataMgr_RangeCheck(edcPROJECTOR_ADDRESS,psEEP->sUserSystemSetting.sCommonSetting.ucProjectorAddress) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucProjectorAddress = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucProjectorAddress;
		if(utilDataMgr_RangeCheck(edcPROJECTOR_ID,psEEP->sUserSystemSetting.sCommonSetting.ucProjectorID) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucProjectorID = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucProjectorID;
		if(utilDataMgr_RangeCheck(edcKEYPAD_BACKLIGHT,psEEP->sUserSystemSetting.sCommonSetting.ucKeypadBacklight) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucKeypadBacklight = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucKeypadBacklight;
		if(utilDataMgr_RangeCheck(edcSTATUS_LED,psEEP->sUserSystemSetting.sCommonSetting.ucStatusLED) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucStatusLED = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucStatusLED;
		if(utilDataMgr_RangeCheck(edcAUTO_SHUTDOWN,psEEP->sUserSystemSetting.sCommonSetting.ucAutoOffTime) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucAutoOffTime = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucAutoOffTime;
		//if(utilDataMgr_RangeCheck(edcAUTO_SHUTDOWN,psEEP->sUserSystemSetting.sCommonSetting.ucScreenSaveTime) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucScreenSaveTime = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucScreenSaveTime;
		if(utilDataMgr_RangeCheck(edcSLEEP_TIMER,psEEP->sUserSystemSetting.sCommonSetting.ucSleepTimer) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSleepTimer = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSleepTimer;
		//if(utilDataMgr_RangeCheck(edcAUTO_SHUTDOWN,psEEP->sUserSystemSetting.sCommonSetting.ucChangePIN) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucChangePIN = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucChangePIN;
		if(utilDataMgr_RangeCheck(edcSERIAL_PORT_BAUD_RATE,psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSerialPortBaudRate;
		if(utilDataMgr_RangeCheck(edcSERIAL_PORT_ECHO,psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortEcho) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortEcho = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSerialPortEcho;
		if(utilDataMgr_RangeCheck(edcSERIAL_PORT_PATH,psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortPath) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortPath = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSerialPortPath;
		if(utilDataMgr_RangeCheck(edcTOP_IR,psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Top) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Top = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucIRControl_Top;
		if(utilDataMgr_RangeCheck(edcFRONT_IR,psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Front) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_Front = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucIRControl_Front;
		if(utilDataMgr_RangeCheck(edcHDBASET_IR,psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucIRControl_HDBaseT;
		//if(utilDataMgr_RangeCheck(edcHDBASET_IR,psEEP->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucHDBaseTEnable;
		//if(utilDataMgr_RangeCheck(edcHDBASET_IR,psEEP->sUserSystemSetting.sCommonSetting.ucSysErrCode) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucSysErrCode = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSysErrCode;
		if(utilDataMgr_RangeCheck(edc12V_TRIGGER,psEEP->sUserSystemSetting.sCommonSetting.uc12VTrigge) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.uc12VTrigge = psEEP_DEF->sUserSystemSetting.sCommonSetting.uc12VTrigge;
		if(utilDataMgr_RangeCheck(edcLOCK_ALL_LENS_MOTORS,psEEP->sUserSystemSetting.sCommonSetting.ucLensAdjust) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLensAdjust = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLensAdjust;
		//if(utilDataMgr_RangeCheck(edc12V_TRIGGER,psEEP->sUserSystemSetting.sCommonSetting.ucLensShift) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucLensShift = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLensShift;
		if(utilDataMgr_RangeCheck(edcLENS_APPLY_POSITION,psEEP->sUserSystemSetting.sCommonSetting.ucLensMemoryApply) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLensMemoryApply = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLensMemoryApply;
		if(utilDataMgr_RangeCheck(edcLENS_SAVE_CURRENT_POSITION,psEEP->sUserSystemSetting.sCommonSetting.ucLensMemorySave) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLensMemorySave = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLensMemorySave;
		if(utilDataMgr_RangeCheck(edcHIGH_ALTITUDE,psEEP->sUserSystemSetting.sCommonSetting.ucHighAltitude) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucHighAltitude = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucHighAltitude;
		if(utilDataMgr_RangeCheck(edcFACTORY_TEST_PATTERN,psEEP->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucFactoryTestPattern;
		//if(utilDataMgr_RangeCheck(edcLENS_SAVE_CURRENT_POSITION,psEEP->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucServiceMenuTestPattern;
		//if(utilDataMgr_RangeCheck(edcLENS_SAVE_CURRENT_POSITION,psEEP->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucFactoryMenuCustomPattern;

		if(utilDataMgr_RangeCheck(edcSPLASH_STARTUP,psEEP->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSplashStartupEnable;
		if(utilDataMgr_RangeCheck(edcACTUATOR_SWITCH,psEEP->sUserSystemSetting.sCommonSetting.ucActuatorSwitch) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucActuatorSwitch = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucActuatorSwitch;
		if(utilDataMgr_RangeCheck(edcCOOL_DOWN,psEEP->sUserSystemSetting.sCommonSetting.ucCoolingDown) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucCoolingDown = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucCoolingDown;
		if(utilDataMgr_RangeCheck(edcOSDTEST_PATTERN,psEEP->sUserSystemSetting.sCommonSetting.ucOSDTestPattern) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucOSDTestPattern = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucOSDTestPattern;
		if(utilDataMgr_RangeCheck(edcUART_SWITCH,psEEP->sUserSystemSetting.sCommonSetting.ucUartSwitch) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucUartSwitch = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucUartSwitch;
		if(utilDataMgr_RangeCheck(edcBACKUP_RESTORE_SAVE,psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackupRestoreSave;
		if(utilDataMgr_RangeCheck(edcBACKUP_RESTORE_RESTORE,psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackupRestoreRestore;
		if(utilDataMgr_RangeCheck(edcLENS_DETECTION,psEEP->sUserSystemSetting.sCommonSetting.ucLensDetection) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLensDetection = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLensDetection;
		if(utilDataMgr_RangeCheck(edcLOW_LATENCY_MODE,psEEP->sUserSystemSetting.sCommonSetting.ucLowLatency) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucLowLatency = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLowLatency;
		//if(utilDataMgr_RangeCheck(edcBACKUPINPUT_AUTOSWITCH,psEEP->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackupIputSwitch;
		if(utilDataMgr_RangeCheck(edcBACKUPINPUT_PRIMARY_INPUT,psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackupPrimaryInput;
		//if(utilDataMgr_RangeCheck(edcBACKUPINPUT_PRIMARY_INPUT,psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackupSecondaryInput;
		if(utilDataMgr_RangeCheck(edcBACKGROUND_COLOR,psEEP->sUserSystemSetting.sCommonSetting.ucBackgroundColor) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucBackgroundColor = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucBackgroundColor;
		if(utilDataMgr_RangeCheck(edcSIGNAL_POWER_ON,psEEP->sUserSystemSetting.sCommonSetting.ucSignalPowerOn) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucSignalPowerOn = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSignalPowerOn;
		//if(utilDataMgr_RangeCheck(edcSECURITY_TIMER,psEEP->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin = psEEP_DEF->sUserSystemSetting.sCommonSetting.ulSecurity_TotalRemainMin;
		if(utilDataMgr_RangeCheck(edcSTARTUP_SHUTTER,psEEP->sUserSystemSetting.sCommonSetting.ucStartupShutter) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sCommonSetting.ucStartupShutter = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucStartupShutter;
		if(utilDataMgr_RangeCheck(edcAUTO_SOURCE_RESYNC,psEEP->sUserSystemSetting.sCommonSetting.ucAutoSourceResync) == eEXEC_CODE_FAIL)		//G100_Doulas_0006
			psEEP->sUserSystemSetting.sCommonSetting.ucAutoSourceResync = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucAutoSourceResync;
        if(utilDataMgr_RangeCheck(edcSERIAL_PORT_OUT_BAUD_RATE,psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortOut_BaudRate) == eEXEC_CODE_FAIL)
            psEEP->sUserSystemSetting.sCommonSetting.ucSerialPortOut_BaudRate = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucSerialPortOut_BaudRate;
        if(utilDataMgr_RangeCheck(edcFADE_IN,psEEP->sUserSystemSetting.sCommonSetting.ucFadeIn_Time) == eEXEC_CODE_FAIL)
            psEEP->sUserSystemSetting.sCommonSetting.ucFadeIn_Time = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucFadeIn_Time;
        if(utilDataMgr_RangeCheck(edcFADE_OUT,psEEP->sUserSystemSetting.sCommonSetting.ucFadeOut_Time) == eEXEC_CODE_FAIL)
            psEEP->sUserSystemSetting.sCommonSetting.ucFadeOut_Time = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucFadeOut_Time;
        if(utilDataMgr_RangeCheck(edcPWRKEY_BACKLIGHT,psEEP->sUserSystemSetting.sCommonSetting.ucPwrKeyBacklight) == eEXEC_CODE_FAIL)
            psEEP->sUserSystemSetting.sCommonSetting.ucPwrKeyBacklight = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucPwrKeyBacklight;
        if(utilDataMgr_RangeCheck(edcLOGO_CHANGE,psEEP->sUserSystemSetting.sCommonSetting.ucLogoChange) == eEXEC_CODE_FAIL)
            psEEP->sUserSystemSetting.sCommonSetting.ucLogoChange = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucLogoChange;
        if(utilDataMgr_RangeCheck(edcFAST_POWER_ON,psEEP->sUserSystemSetting.sCommonSetting.ucFast_Power_On) == eEXEC_CODE_FAIL)	//G100_Clare_0055
            psEEP->sUserSystemSetting.sCommonSetting.ucFast_Power_On = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucFast_Power_On;	//G100_Clare_0055

 		if(utilDataMgr_RangeCheck(edcAUDIO_VOLUME,psEEP->sUserSystemSetting.sCommonSetting.ucAudioVolume) == eEXEC_CODE_FAIL)// R70K_Bruce_0002
			psEEP->sUserSystemSetting.sCommonSetting.ucAudioVolume = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucAudioVolume;
 		if(utilDataMgr_RangeCheck(edcAUDIO_MUTE,psEEP->sUserSystemSetting.sCommonSetting.ucAudioMute) == eEXEC_CODE_FAIL)// R70K_Bruce_0002
			psEEP->sUserSystemSetting.sCommonSetting.ucAudioMute = psEEP_DEF->sUserSystemSetting.sCommonSetting.ucAudioMute;

		if(utilDataMgr_RangeCheck(edcMODEL_SWITCH_NEUTRAL,psEEP->sSystemDefault.ucModelSwitchAdjust) == eEXEC_CODE_FAIL)  //A65_OPTOMA_Julie_0064
            psEEP->sSystemDefault.ucModelSwitchAdjust = psEEP_DEF->sSystemDefault.ucModelSwitchAdjust;


        //psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceMain          = (UINT8)atol(m_sCommonGui[eCG_UCINPUTSOURCEMAIN].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceSub           = (UINT8)atol(m_sCommonGui[eCG_UCINPUTSOURCESUB].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucPIPEnable                = (UINT8)atol(m_sCommonGui[eCG_UCPIPENABLE].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucMainLayout                = (UINT8)atol(m_sCommonGui[eCG_UCMAINLAYOUT].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucPIPLayout                = (UINT8)atol(m_sCommonGui[eCG_UCPIPLAYOUT].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucPBPLayout                = (UINT8)atol(m_sCommonGui[eCG_UCPBPLAYOUT].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucPIPSize                  = (UINT8)atol(m_sCommonGui[eCG_UCPIPSIZE].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucSourceKeyOption          = (UINT8)atol(m_sCommonGui[eCG_UCSOURCEKEYOPTION].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.uiSourceInfo               = (UINT16)atol(m_sCommonGui[eCG_UISOURCEINFO].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucSourceLock               = (UINT8)atol(m_sCommonGui[eCG_UCSOURCELOCK].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey                = (UINT8)atol(m_sCommonGui[eCG_UCCUSTOMKEY].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucBlankKey                 = (UINT8)atol(m_sCommonGui[eCG_UCBLANKKEY].cParaValue);
        //psEEP->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable       = (UINT8)atol(m_sCommonGui[eCG_UCSOURCEHOTKEYENABLE].cParaValue);
		if(utilDataMgr_RangeCheck(edcMAIN_INPUT,psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceMain) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceMain = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucInputSourceMain;
		if(utilDataMgr_RangeCheck(edcSUB_INPUT,psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceSub) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucInputSourceSub = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucInputSourceSub;
		if(utilDataMgr_RangeCheck(edcPIP_PBP_ENABLE,psEEP->sUserSystemSetting.sSourceSetting.ucPIPEnable) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucPIPEnable = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucPIPEnable;
		if(utilDataMgr_RangeCheck(edcMAIN_LAYOUT,psEEP->sUserSystemSetting.sSourceSetting.ucMainLayout) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucMainLayout = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucMainLayout;
		if(utilDataMgr_RangeCheck(edcSIZE,psEEP->sUserSystemSetting.sSourceSetting.ucPIPSize) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucPIPSize = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucPIPSize;
		if(utilDataMgr_RangeCheck(edcINPUT_KEY,psEEP->sUserSystemSetting.sSourceSetting.ucSourceKeyOption) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucSourceKeyOption = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucSourceKeyOption;
		if(utilDataMgr_RangeCheck(edcSOURCE_INFO,psEEP->sUserSystemSetting.sSourceSetting.uiSourceInfo) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.uiSourceInfo = psEEP_DEF->sUserSystemSetting.sSourceSetting.uiSourceInfo;
		if(utilDataMgr_RangeCheck(edcSOURCE_LOCK,psEEP->sUserSystemSetting.sSourceSetting.ucSourceLock) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucSourceLock = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucSourceLock;
		if(utilDataMgr_RangeCheck(edcHOT_KEY_SETTINGS,psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey) == eEXEC_CODE_FAIL)
			psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucCustomKey;
        if(utilDataMgr_RangeCheck(edcHOT_KEY2_SETTINGS,psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey2) == eEXEC_CODE_FAIL)  //G100_Wilsonj_0053
			psEEP->sUserSystemSetting.sSourceSetting.ucCustomKey2 = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucCustomKey2;
		//if(utilDataMgr_RangeCheck(edcMAIN_INPUT,psEEP->sUserSystemSetting.sSourceSetting.ucBlankKey) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sSourceSetting.ucBlankKey = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucBlankKey;
		//if(utilDataMgr_RangeCheck(edcMAIN_INPUT,psEEP->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable) == eEXEC_CODE_FAIL)
		//	psEEP->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable = psEEP_DEF->sUserSystemSetting.sSourceSetting.ucSourceHotKeyEnable;

        for(iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
        {
        	UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);

            uiNode = utilDataMgr_SourceCommonTablerGet(iCount);

            if(uiNode != eDATA_NODE_NUMBER)
            {
				if(utilDataMgr_RangeCheck(edcSIZE_PRESETS,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAspectRatio;
				if(utilDataMgr_RangeCheck(edcOVERSCAN,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucOverScan) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucOverScan = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucOverScan;
				if(utilDataMgr_RangeCheck(edcPIXEL_PHASE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPhase) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPhase = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPhase;
				if(utilDataMgr_RangeCheck(edcPIXEL_TRACK,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucTracking) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucTracking = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucTracking;
				if(utilDataMgr_RangeCheck(edcHORZ_POSITION,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucHorzPosition) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucHorzPosition = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucHorzPosition;
				if(utilDataMgr_RangeCheck(edcVERT_POSITION,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucVertPosition) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucVertPosition = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucVertPosition;
				if(utilDataMgr_RangeCheck(edcDIGITAL_HORZ_ZOOM,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzZoom) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzZoom = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzZoom;
				if(utilDataMgr_RangeCheck(edcDIGITAL_VERT_ZOOM,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertZoom) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertZoom = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertZoom;
				if(utilDataMgr_RangeCheck(edcDIGITAL_HORZ_SHIFT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzShift) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzShift = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalHorzShift;
				if(utilDataMgr_RangeCheck(edcDIGITAL_VERT_SHIFT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertShift) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertShift = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiDigitalVertShift;
				if(utilDataMgr_RangeCheck(edcDIGITAL_HORZ_ZOOM,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzZoom) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzZoom = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzZoom;
				if(utilDataMgr_RangeCheck(edcDIGITAL_VERT_ZOOM,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertZoom) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertZoom = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertZoom;
				if(utilDataMgr_RangeCheck(edcDIGITAL_HORZ_SHIFT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzShift) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzShift = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalHorzShift;
				if(utilDataMgr_RangeCheck(edcDIGITAL_VERT_SHIFT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertShift) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertShift = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uiCustomDigitalVertShift;

				if(utilDataMgr_RangeCheck(edcPICTURE_SETTINGS,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPresetMode) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPresetMode = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPresetMode;
				//if(utilDataMgr_RangeCheck(edcPICTURE_SETTINGS,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucBackupPreset) == eEXEC_CODE_FAIL)
				//	psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucBackupPreset = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucBackupPreset;
				//if(utilDataMgr_RangeCheck(edcSIZE_PRESETS,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucSavePreset) == eEXEC_CODE_FAIL)
				//	psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucSavePreset = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucSavePreset;
				#ifdef CUSTOM_BARCO		//G100_Doulas_0066 Modify
				if(utilDataMgr_RangeCheck(edcUSER_COLOR_MODE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode;
				#else
				if(utilDataMgr_RangeCheck(edcPRE_USER_MODE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucPreUserMode;
				#endif

				if(utilDataMgr_RangeCheck(edc3D_ENABLE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Enable) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Enable = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Enable;
				if(utilDataMgr_RangeCheck(edc3D_INVERT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Invert) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Invert = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Invert;
				if(utilDataMgr_RangeCheck(edc3D_SYNC_OUT,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncOut) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncOut = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncOut;
				if(utilDataMgr_RangeCheck(edc3D_SYNC_TYPE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncIn) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncIn = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_SyncIn;
				if(utilDataMgr_RangeCheck(edc3D_LR_REFERENCE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Reference) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Reference = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Reference;
				//if(utilDataMgr_RangeCheck(edcSIZE_PRESETS,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_2D_View) == eEXEC_CODE_FAIL)
				//	psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_2D_View = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_2D_View;
				if(utilDataMgr_RangeCheck(edcEDGE_MASK,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucEdgeMask) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucEdgeMask = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucEdgeMask;
				if(utilDataMgr_RangeCheck(edc3D_MODE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Mode) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Mode = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Mode;
				if(utilDataMgr_RangeCheck(edcDLPLink_ON,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Tech) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Tech = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].uc3D_Tech;
				if(utilDataMgr_RangeCheck(edcAUTO_IMAGE,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAutoImage) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAutoImage = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucAutoImage;
				if(utilDataMgr_RangeCheck(edcDIGITAL_ZOOM_PROPORTIONAL,psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucDigitalZoomProp) == eEXEC_CODE_FAIL)
					psEEP->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucDigitalZoomProp = psEEP_DEF->sUserSystemSetting.sSourceDependSetting[uiSrcIndex].ucDigitalZoomProp;

            }
        }

        for(iCount = 0; iCount < eGUI_SOURCE_ID_NUMBER; iCount++)
        {
        	UINT16 uiSrcIndex = (UINT16)GUI2CM(edcMAIN_INPUT, iCount);  //for  psEEP->sUserSystemSetting  source index
            for(iCount2 = 0; iCount2 < eGUI_PICTURE_SETTINGS_NUMBER; iCount2++)
            {
            	UINT16 uiPresetModeIndex = (UINT16)GUI2CM(edcPICTURE_SETTINGS, iCount2);
                if(m_cSourceTableMtached[eSOURCE_TYPE_COLOR][iCount][iCount2] != eDATA_NODE_NUMBER)
                {
                    //psPara = utilDataMgr_ParaTableGet(m_cSourceTableMtached[eSOURCE_TYPE_COLOR][iCount][iCount2]);

                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS            = (UINT8)atol(psPara[eSCR_UCCS].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT            = (UINT8)atol(psPara[eSCR_UCCT].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma         = (UINT8)atol(psPara[eSCR_UCGAMMA].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled = (UINT8)atol(psPara[eSCR_UCBRILLIENTCOLORENABLE].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking  = (UINT8)atol(psPara[eSCR_UCWHITEPEAKING].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement = (UINT8)atol(psPara[eSCR_UCCOLORENHANCEMENT].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor     = (UINT8)atol(psPara[eSCR_UCSKINCOLOR].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness     = (UINT8)atol(psPara[eSCR_UCSHARPNESS].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness    = (UINT8)atol(psPara[eSCR_UCBRIGHTNESS].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast      = (UINT8)atol(psPara[eSCR_UCCONTRAST].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint          = (UINT8)atol(psPara[eSCR_UCTINT].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation    = (UINT8)atol(psPara[eSCR_UCSATURATION].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain       = (UINT8)atol(psPara[eSCR_UCREDGAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain     = (UINT8)atol(psPara[eSCR_UCGREENGAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain      = (UINT8)atol(psPara[eSCR_UCBLUEGAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset     = (UINT8)atol(psPara[eSCR_UCREDOFFSET].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset   = (UINT8)atol(psPara[eSCR_UCGREENOFFSET].cParaValue);
                    //psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset    = (UINT8)atol(psPara[eSCR_UCBLUEOFFSET].cParaValue);
					if(utilDataMgr_RangeCheck(edcCOLOR_SPACE,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS;
					if(utilDataMgr_RangeCheck(edcCOLOR_TEMPERATURE,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT;
					if(utilDataMgr_RangeCheck(edcGAMMA,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma;
					//if(utilDataMgr_RangeCheck(edcCOLOR_SPACE,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled) == eEXEC_CODE_FAIL)
					//	psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrillientColorEnabled;
					if(utilDataMgr_RangeCheck(edcWHITE_PEAKING,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking;
					if(utilDataMgr_RangeCheck(edcCOLOR_ENHANCEMENT,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement;

					if(utilDataMgr_RangeCheck(edcSKIN_COLOR,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor;
					if(utilDataMgr_RangeCheck(edcDETAIL,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness;
					if(utilDataMgr_RangeCheck(edcBRIGHTNESS,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness;
					if(utilDataMgr_RangeCheck(edcCONTRAST,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast;
					if(utilDataMgr_RangeCheck(edcTINT,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint;
					if(utilDataMgr_RangeCheck(edcCOLOR,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation;

					if(utilDataMgr_RangeCheck(edcRED_GAIN,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain;
					if(utilDataMgr_RangeCheck(edcGREEN_GAIN,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain;
					if(utilDataMgr_RangeCheck(edcBLUE_GAIN,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain;
					if(utilDataMgr_RangeCheck(edcRED_OFFSET,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset;
					if(utilDataMgr_RangeCheck(edcGREEN_OFFSET,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset;
					if(utilDataMgr_RangeCheck(edcBLUE_OFFSET,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset;

					if(utilDataMgr_RangeCheck(edcWALL_COLOR,psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet) == eEXEC_CODE_FAIL)  //G100_Steven_0047
						psEEP->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet = psEEP_DEF->sUserSystemSetting.sColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet;
					/////////////////////////////////////////
					if(utilDataMgr_RangeCheck(edcCOLOR_SPACE,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCS;

					if(utilDataMgr_RangeCheck(edcCOLOR_TEMPERATURE,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucCT;

					if(utilDataMgr_RangeCheck(edcGAMMA,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGamma;

					if(utilDataMgr_RangeCheck(edcWHITE_PEAKING,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWhitePeaking;

					if(utilDataMgr_RangeCheck(edcCOLOR_ENHANCEMENT,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucColorEnhancement;

					if(utilDataMgr_RangeCheck(edcSKIN_COLOR,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSkinColor;  //G100_Steven_0047

					if(utilDataMgr_RangeCheck(edcDETAIL,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSharpness;

					if(utilDataMgr_RangeCheck(edcBRIGHTNESS,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBrightness;

					if(utilDataMgr_RangeCheck(edcCONTRAST,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucContrast;

					if(utilDataMgr_RangeCheck(edcTINT,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucTint;

					if(utilDataMgr_RangeCheck(edcCOLOR,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucSaturation;

					if(utilDataMgr_RangeCheck(edcRED_GAIN,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedGain;

					if(utilDataMgr_RangeCheck(edcGREEN_GAIN,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenGain;

					if(utilDataMgr_RangeCheck(edcBLUE_GAIN,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueGain;

					if(utilDataMgr_RangeCheck(edcRED_OFFSET,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucRedOffset;

					if(utilDataMgr_RangeCheck(edcGREEN_OFFSET,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucGreenOffset;

					if(utilDataMgr_RangeCheck(edcBLUE_OFFSET,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucBlueOffset;
					//G100_Steven_0016 end

					if(utilDataMgr_RangeCheck(edcWALL_COLOR,psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet) == eEXEC_CODE_FAIL)   //G100_Steven_0047
						psEEP->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet = psEEP_DEF->sUserSystemSetting.sUserColorSetting[uiSrcIndex][uiPresetModeIndex][0].ucWallColorSet;

                }

                if(m_cSourceTableMtached[eSOURCE_TYPE_HSG][iCount][iCount2] != eDATA_NODE_NUMBER)
                {
                    //psPara = utilDataMgr_ParaTableGet(m_cSourceTableMtached[eSOURCE_TYPE_HSG][iCount][iCount2]);

                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE       = (UINT8)atol(psPara[eHSG_R_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT       = (UINT8)atol(psPara[eHSG_R_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN      = (UINT8)atol(psPara[eHSG_R_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE       = (UINT8)atol(psPara[eHSG_G_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT       = (UINT8)atol(psPara[eHSG_G_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN      = (UINT8)atol(psPara[eHSG_G_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE       = (UINT8)atol(psPara[eHSG_B_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT       = (UINT8)atol(psPara[eHSG_B_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN      = (UINT8)atol(psPara[eHSG_B_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE       = (UINT8)atol(psPara[eHSG_C_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT       = (UINT8)atol(psPara[eHSG_C_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN      = (UINT8)atol(psPara[eHSG_C_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE       = (UINT8)atol(psPara[eHSG_M_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT       = (UINT8)atol(psPara[eHSG_M_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN      = (UINT8)atol(psPara[eHSG_M_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE       = (UINT8)atol(psPara[eHSG_Y_HUE].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT       = (UINT8)atol(psPara[eHSG_Y_SAT].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN      = (UINT8)atol(psPara[eHSG_Y_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN    = (UINT8)atol(psPara[eHSG_W_R_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN    = (UINT8)atol(psPara[eHSG_W_G_GAIN].cParaValue);
                    //psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN    = (UINT8)atol(psPara[eHSG_W_B_GAIN].cParaValue);
					if(utilDataMgr_RangeCheck(edcHSG_RED_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_RED_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_RED_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_GREEN_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_GREEN_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_GREEN_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_BLUE_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_BLUE_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_BLUE_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_CYAN_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_CYAN_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_CYAN_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_HUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_SATURATION,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_GAIN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_RED,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN;
					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_GREEN,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN;
					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_BLUE,psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN = psEEP_DEF->sUserSystemSetting.sHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN;
 //G100_Steven_0020 start
					if(utilDataMgr_RangeCheck(edcHSG_RED_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_RED_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_RED_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_R_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_GREEN_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_GREEN_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_GREEN_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_G_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_BLUE_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_BLUE_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_BLUE_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_B_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_CYAN_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_CYAN_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_CYAN_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_C_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_MAGENTA_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_M_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_HUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_HUE;
					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_SATURATION,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_SAT;
					if(utilDataMgr_RangeCheck(edcHSG_YELLOW_GAIN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_Y_GAIN;

					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_RED,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_R_GAIN;
					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_GREEN,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_G_GAIN;
					if(utilDataMgr_RangeCheck(edcHSG_WHITE_GAIN_BLUE,psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN) == eEXEC_CODE_FAIL)
						psEEP->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN = psEEP_DEF->sUserSystemSetting.sUserHSG_setting[uiSrcIndex][uiPresetModeIndex].HSG_W_B_GAIN;
                }  //G100_Steven_0020 end
            }
        }
		utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_CCT_StorageGet(uCCT_TABLE *psEEP)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        UINT16 iCount = 0, iCount2 = 0;
        sPARA_FORMAT *psPara;

        psEEP->sDataStruct.ulCCT_Tag = (UINT32)atol(m_sWAP_Calibration_Tag[eWAP_CALIBRATION_TAG].cParaValue);
        //psEEP->sDataStruct.uiCCT_CRC = (UINT16)atol(m_sWAP_Calibration_Tag[eWAP_CRC].cParaValue);

        for(iCount = 0; iCount < eWAP_UICHECKSUM; iCount++)
        {
            for(iCount2 = 0; iCount2 < eIFC_WAP_NUMBER; iCount2++)
            {
                psEEP->sDataStruct.ucRatioData[iCount2][iCount+1] = (UINT8)atol(m_sWAP_RatioData[iCount2].sPresetMode[iCount].cParaValue);
                psEEP->sDataStruct.ucOffsetData[iCount2][iCount+1] = (UINT8)atol(m_sWAP_OffsetData[iCount2].sPresetMode[iCount].cParaValue);
                psEEP->sDataStruct.uiPWMData[iCount2][iCount] = (UINT16)atol(m_sWAP_PWMData[iCount2].sPresetMode[iCount].cParaValue);
            }
        }

		utilDataMgr_MutexGive(__FUNCTION__);
    }
}

void utilDataMgr_CCT_StorageSet(uCCT_TABLE *psEEP)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        UINT16 iCount = 0, iCount2 = 0;
        sPARA_FORMAT *psPara;

        sprintf(m_sWAP_Calibration_Tag[eWAP_CALIBRATION_TAG].cParaValue,  "%d", psEEP->sDataStruct.ulCCT_Tag);
        sprintf(m_sWAP_Calibration_Tag[eWAP_CRC].cParaValue,  "%d", psEEP->sDataStruct.uiCCT_CRC);

        //System Cal
        for(iCount = 0; iCount < eWAP_UICHECKSUM; iCount++)
        {
            for(iCount2 = 0; iCount2 < eIFC_WAP_NUMBER; iCount2++)
            {
            	sprintf(m_sWAP_RatioData[iCount2].sPresetMode[iCount].cParaValue,  "%d", psEEP->sDataStruct.ucRatioData[iCount2][iCount+1]);
                sprintf(m_sWAP_OffsetData[iCount2].sPresetMode[iCount].cParaValue,  "%d", psEEP->sDataStruct.ucOffsetData[iCount2][iCount+1]);
        	    sprintf(m_sWAP_PWMData[iCount2].sPresetMode[iCount].cParaValue,  "%d", psEEP->sDataStruct.uiPWMData[iCount2][iCount]);
            }
        }

        for(UINT16 uiCount = eDATA_NODE_WAP_CALIBRATION_TAG; uiCount <= eDATA_NODE_WAP_SUPER_BRIGHT_PWM; uiCount++)
        {
            utilDataMgr_Update(uiCount);
        }
		utilDataMgr_MutexGive(__FUNCTION__);
    }

}  //G100_Steven_0011
///////////////////

void utilDataMgr_TECGATING_StorageSet(sTEC_GATING_INFO *psEEP)
{
    if(utilDataMgr_MutexTake(__FUNCTION__) == TRUE)
    {
        sPARA_FORMAT *psPara;

        UINT16 uiCount = eDATA_NODE_TEC_GATING_INFO;

        sprintf(m_sTEC_GATING[eTEC_GATING_CNT].cParaValue,  "%d", psEEP->ucTEC_GATING_CNT);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE0].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[0]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE1].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[1]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE2].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[2]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE3].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[3]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE4].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[4]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE5].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[5]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE6].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[6]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE7].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[7]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE8].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[8]);
        sprintf(m_sTEC_GATING[eTEC_GATING_CYCLE9].cParaValue,  "%d", psEEP->ucTEC_GATING_CYCLE[9]);

        utilDataMgr_Update(uiCount);

		utilDataMgr_MutexGive(__FUNCTION__);
    }

} //G100_Steven_0084 end

#if 0
BOOL utilDataMgr_UserDataLoadItemAvailable(UINT8 uiIndex)		//G100_Doulas_0075
{
    BOOL ucResult = FALSE;

    switch(uiIndex)
	{
		case eUSER_DATA_LOAD0:
			if(access(BACKUP_CONFIG_0_PATH, F_OK) == 0)	//check backup dir
			{
				ucResult = TRUE;
			}
			break;

		case eUSER_DATA_LOAD1:
			if(access(BACKUP_CONFIG_1_PATH, F_OK) == 0)	//check backup dir
			{
				ucResult = TRUE;
			}
			break;


		case eUSER_DATA_LOAD2:
			if(access(BACKUP_CONFIG_2_PATH, F_OK) == 0)	//check backup dir
			{
				ucResult = TRUE;
			}
			break;


		case eUSER_DATA_LOAD3:
			if(access(BACKUP_CONFIG_3_PATH, F_OK) == 0)	//check backup dir
			{
				ucResult = TRUE;
			}
			break;


		case eUSER_DATA_LOAD4:
			if(access(BACKUP_CONFIG_4_PATH, F_OK) == 0)		//check backup dir
			{
				ucResult = TRUE;
			}
			break;
	}

    return ucResult;
}
#endif

void utilDataMgr_UserDataReset(void)		//G100_Doulas_0075
{
	if(access(BACKUP_CONFIG_0_PATH, F_OK) == 0)	//have dir
	{
	    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_0_PATH);
	}

	if(access(BACKUP_CONFIG_1_PATH, F_OK) == 0)	//have dir
	{
	    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_1_PATH);
	}

	if(access(BACKUP_CONFIG_2_PATH, F_OK) == 0) //have dir
	{
	    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_2_PATH);
	}

	if(access(BACKUP_CONFIG_3_PATH, F_OK) == 0) //have dir
	{
	    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_3_PATH);
	}

	if(access(BACKUP_CONFIG_4_PATH, F_OK) == 0) //have dir
	{
	    SYSTEM_CALL("rm -R %s 2> /dev/null", BACKUP_CONFIG_4_PATH);
	}
}

int utilDataMgr_ReadFile_USBtest_periphery(BYTE *cimx, BYTE *cext, BYTE *cddp, BYTE *cksz) //A70Gen2_Julie_0048
{
	FILE *pFile = NULL;
    char cTemp[64] = {'\0'};
    char cStrTemp[64] = {'\0'}, cType[64] = {'\0'}, cString[64] = {'\0'};
	BYTE cData;

	sprintf(cTemp, "/tmp/test_periphery.conf\0");

	if(access(cTemp,0)==-1)
	{
		return 1;
	}

	pFile = fopen(cTemp, "r");

	if(pFile == NULL)
	{
		return 1;
	}

	while (!feof(pFile))
	{
		fgets(cStrTemp,63,pFile);

		if(feof(pFile))
		{
			break;//return 1;
		}

		sscanf(cStrTemp, "%63[^=]=%63[^\n]", cType, cString); //A70LK_Casper_0001

		if((strncmp(cType, "usb_imx", 7) == 0))
		{
			cData = atoi(cString);
			*cimx = cData;
		}
		else if((strncmp(cType, "usb_ext", 7) == 0))
		{
			cData = atoi(cString);
			*cext = cData;
		}
		else if((strncmp(cType, "usb_ddp", 7) == 0))
		{
			cData = atoi(cString);
			*cddp = cData;
		}
		else if((strncmp(cType, "net_ksz", 7) == 0))
		{
			cData = atoi(cString);
			*cksz = cData;
		}
	}

	fclose(pFile);

	return 0;
}




UINT8 utilDataMgr_CommonSet_CM(UINT16 uiIndex, UINT8 *pcData)		//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_CommonSet(uiIndex,pcData);
	//utilDataMgr_CommonSet_ToGUI(uiIndex,pcData);	//HICC2_Doulas_0004 HICC1

	return 0;
}

UINT8 utilDataMgr_SourceColorSet_CM(UINT16 uiIndex, UINT8 cSource, UINT8 cPictureMode, UINT8 *pcData)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_SourceColorSet(uiIndex,cSource,cPictureMode,pcData);
	//utilDataMgr_SourceColorSet_ToGUI(uiIndex,cSource,cPictureMode,pcData);	//HICC2_Doulas_0004 HICC1
	return 0;
}

UINT8 utilDataMgr_SourceColorUserModeSet_CM(UINT16 uiIndex, UINT8 cSource, UINT8 cPictureMode, UINT8 cPreUserMode, UINT8 *pcData)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_SourceColorUserModeSet(uiIndex,cSource,cPictureMode,cPreUserMode,pcData);
	//utilDataMgr_SourceColorUserModeSet_ToGUI(uiIndex,cSource,cPictureMode,cPreUserMode,pcData); //HICC2_Doulas_0004 HICC1
	return 0;
}

void utilDataMgr_Initialization_CM(void) //HICC2_Doulas_0003
{
	//utilDataMgr_Initialization();
	//utilDataMgr_HICC2_Initialization();
}

void utilDataMgr_ResetToDefault_CM(eNVRAM_EVENT eEvent) //HICC2_Doulas_0003
{
	//utilDataMgr_ResetToDefault(eEvent);
	//utilDataMgr_HICC2_ResetToDefault(eEvent);
}

void utilDataMgr_RAMToFileAll_CM(sEEPROM_SETTINGS *psEEP) //HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileAll(psEEP);
	//utilDataMgr_HICC2_RAMToFileAll(psEEP);
}

void utilDataMgr_LanInit_CM(sLAN_INFO_VALUES *psLanInfo)	//HICC2_Doulas_0003
{
	//utilDataMgr_LanInit(psLanInfo);
}

void utilDataMgr_FileToRAM_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_FileToRAM(psEEP);
	//utilDataMgr_HICC2_FileToRAM(psEEP);
}

void utilDataMgr_UpdateProcuss_CM(void)	//HICC2_Doulas_0003
{
	//utilDataMgr_UpdateProcuss();
	//utilDataMgr_HICC2_UpdateProcuss();
}

void utilDataMgr_RAMToFileSystemCal_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSystemCal(psEEP);
	//utilDataMgr_HICC2_RAMToFileSystemCal(psEEP);
}

void utilDataMgr_RAMToFileBurnin_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileBurnin(psEEP);
	//utilDataMgr_HICC2_RAMToFileBurnin(psEEP);
}

void utilDataMgr_RAMToFileProjectorInfo_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileProjectorInfo(psEEP);
	//utilDataMgr_HICC2_RAMToFileProjectorInfo(psEEP);
}

void utilDataMgr_RAMToFileAutoBrightness_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileAutoBrightness(psEEP);
	//utilDataMgr_HICC2_RAMToFileAutoBrightness(psEEP);
}

void utilDataMgr_RAMToFileStartup_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileStartup(psEEP);
	//utilDataMgr_HICC2_RAMToFileStartup(psEEP);
}

void utilDataMgr_RAMToFileSystemHours_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSystemHours(psEEP);
	//utilDataMgr_HICC2_RAMToFileSystemHours(psEEP);
}

void utilDataMgr_RAMToFileCommonGui_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileCommonGui(psEEP);
	//utilDataMgr_HICC2_RAMToFileCommonGui(psEEP);
}

void utilDataMgr_RAMToFileWarping_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileWarping(psEEP);
	//utilDataMgr_HICC2_RAMToFileWarping(psEEP);
}

void utilDataMgr_RAMToFileSourceTableCommon_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSourceTableCommon(psEEP);
	//utilDataMgr_HICC2_RAMToFileSourceTableCommon(psEEP);
}

void utilDataMgr_RAMToFileSourceTableColor_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSourceTableColor(psEEP);
	//utilDataMgr_HICC2_RAMToFileSourceTableColor(psEEP);
}

void utilDataMgr_RAMToFileSourceTableHSG_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSourceTableHSG(psEEP);
	//utilDataMgr_HICC2_RAMToFileSourceTableHSG(psEEP);
}

void utilDataMgr_RAMToFileSourceTableHSGUser_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSourceTableHSGUser(psEEP);
	//utilDataMgr_HICC2_RAMToFileSourceTableHSGUser(psEEP);
}

void utilDataMgr_RAMToFileSourceTableColorUser_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileSourceTableColorUser(psEEP);
	//utilDataMgr_HICC2_RAMToFileSourceTableColorUser(psEEP);
}

void utilDataMgr_RAMToFileACU_CM(sEEPROM_SETTINGS *psEEP)	//HICC2_Doulas_0003
{
	//utilDataMgr_RAMToFileACU(psEEP);
	//utilDataMgr_HICC2_RAMToFileACU(psEEP);
}

void utilOPD_TotalProjectorHour_CM(void)	//HICC2_Doulas_0003
{
	//utilOPD_HICC2_TotalProjectorHour();
}

void utilDataMgr_WriteGecLog_CM(UINT32 ulIndex)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_WriteGecLog(ulIndex);
}

UINT16 utilDataMgr_LoadLastLog_CM(UINT16 ucNum, char pcString[][128])	//HICC2_Doulas_0003
{
	//return CommonAPI_LoadErrorLog(ucNum,pcString);//utilDataMgr_HICC2_LoadLastLog(ucNum,pcString); //HICC2_Doulas_0031
    return 0;
}

void utilDataMgr_ClearLog_CM(void)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_ClearLog();
}

void utilDataMgr_WriteSSTinfo_CM(char *pcString)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_WriteSSTinfo(pcString);
}

UINT8 utilDataMgr_UserDataSave_CM(UINT8 uiIndex)	//HICC2_Doulas_0003
{
	//return utilDataMgr_HICC2_UserDataSave(uiIndex);

	return 0;
}

UINT8 utilDataMgr_UserDataLoad_CM(UINT8 uiIndex)	//HICC2_Doulas_0003
{
	//return utilDataMgr_HICC2_UserDataLoad(uiIndex);
	return 0;
}

UINT8 utilDataMgr_WebBackupSave_CM(UINT8 uiIndex)	//HICC2_Doulas_0003
{
	//return utilDataMgr_HICC2_WebBackupSave(uiIndex);
	return 0;
}

UINT8 utilDataMgr_WebRestore_CM(UINT8 uiIndex)				//HICC2_Doulas_0003
{
	//return utilDataMgr_HICC2_WebRestore(uiIndex);
	return 0;
}

void utilDataMgr_EEPROM_RangeCheck_CM(sEEPROM_SETTINGS *psEEP,sEEPROM_SETTINGS *psEEP_DEF)	//HICC2_Doulas_0003
{
	//utilDataMgr_HICC2_EEPROM_RangeCheck(psEEP,psEEP_DEF);
}

void palIapProc_CCT_StorageGet_CM(uCCT_TABLE *psEEP)	//HICC2_Doulas_0003
{
	//palIapProc_HICC2_CCT_StorageGet(psEEP);
}

void palIapProc_CCT_StorageSet_CM(uCCT_TABLE *psEEP)	//HICC2_Doulas_0003
{
	//palIapProc_HICC2_CCT_StorageSet(psEEP);
}

void palIapProc_TECGATING_StorageGet_CM(sTEC_GATING_INFO *psEEP)	//HICC2_Doulas_0003
{
	//appIapProc_HICC2_TECGATING_StorageGet(psEEP);
}

void palIapProc_TECGATING_StorageSet_CM(sTEC_GATING_INFO *psEEP)	//HICC2_Doulas_0003
{
	//appIapProc_HICC2_TECGATING_StorageSet(psEEP);
}

BOOL utilDataMgr_UserDataLoadItemAvailable_CM(UINT8 uiIndex)	//HICC2_Doulas_0003
{
	//return utilDataMgr_HICC2_UserDataLoadItemAvailable(uiIndex);
	return 0;
}

void utilDataMgr_UserDataReset_CM(void)	//HICC2_Doulas_0003
{
	//utilDataMgr_UserDataReset();
	//utilDataMgr_HICC2_UserDataReset();
}

void utilDataMgr_RAMToFileCommonGui(sEEPROM_SETTINGS *psEEP, eDATA_NODE eNode)
{
}

